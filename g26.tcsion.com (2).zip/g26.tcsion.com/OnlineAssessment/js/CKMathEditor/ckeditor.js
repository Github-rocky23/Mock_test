if (window.CKEDITOR || (window.CKEDITOR = function() {
        var t = /(^|.*[\\\/])ckeditor\.js(?:\?.*|;.*)?$/i,
            e = {
                timestamp: "",
                version: "%VERSION%",
                revision: "%REV%",
                rnd: Math.floor(900 * Math.random()) + 100,
                _: {
                    pending: [],
                    basePathSrcPattern: t
                },
                status: "unloaded",
                basePath: function() {
                    var e = window.CKEDITOR_BASEPATH || "";
                    if (!e)
                        for (var n = document.getElementsByTagName("script"), o = 0; o < n.length; o++) {
                            var a = n[o].src.match(t);
                            if (a) {
                                e = a[1];
                                break
                            }
                        }
                    if (-1 == e.indexOf(":/") && "//" != e.slice(0, 2) && (e = 0 === e.indexOf("/") ? location.href.match(/^.*?:\/\/[^\/]*/)[0] + e : location.href.match(/^[^\?]*\/(?:)/)[0] + e), !e) throw 'The CKEditor installation path could not be automatically detected. Please set the global variable "CKEDITOR_BASEPATH" before creating editor instances.';
                    return e
                }(),
                getUrl: function(t) {
                    return -1 == t.indexOf(":/") && 0 !== t.indexOf("/") && (t = this.basePath + t), this.timestamp && "/" != t.charAt(t.length - 1) && !/[&?]t=/.test(t) && (t += (0 <= t.indexOf("?") ? "&" : "?") + "t=" + this.timestamp), t
                },
                domReady: function() {
                    function t() {
                        try {
                            document.addEventListener ? (document.removeEventListener("DOMContentLoaded", t, !1), e()) : document.attachEvent && "complete" === document.readyState && (document.detachEvent("onreadystatechange", t), e())
                        } catch (t) {}
                    }

                    function e() {
                        for (var t; t = n.shift();) t()
                    }
                    var n = [];
                    return function(e) {
                        if (n.push(e), "complete" === document.readyState && setTimeout(t, 1), 1 == n.length)
                            if (document.addEventListener) document.addEventListener("DOMContentLoaded", t, !1), window.addEventListener("load", t, !1);
                            else if (document.attachEvent) {
                            document.attachEvent("onreadystatechange", t), window.attachEvent("onload", t), e = !1;
                            try {
                                e = !window.frameElement
                            } catch (t) {}
                            if (document.documentElement.doScroll && e) {
                                var o = function() {
                                    try {
                                        document.documentElement.doScroll("left")
                                    } catch (t) {
                                        return void setTimeout(o, 1)
                                    }
                                    t()
                                };
                                o()
                            }
                        }
                    }
                }()
            },
            n = window.CKEDITOR_GETURL;
        if (n) {
            var o = e.getUrl;
            e.getUrl = function(t) {
                return n.call(e, t) || o.call(e, t)
            }
        }
        return e
    }()), console.log("ckEditor" + CKEDITOR.loader), CKEDITOR.loader) CKEDITOR.loader.load("ckeditor");
else if (CKEDITOR._autoLoad = "ckeditor", !document.body || document.readyState && "complete" != document.readyState) console.log("document write " + CKEDITOR.getUrl("core/loader.js")), document.write('<script type="text/javascript" src="' + CKEDITOR.getUrl("core/loader.js?" + sessionStorage.jsVersion) + '"><\/script>');
else {
    console.log("ready");
    var script = document.createElement("script");
    script.type = "text/javascript", script.src = CKEDITOR.getUrl("core/loader.js"), document.body.appendChild(script)
}
CKEDITOR.skinName = "moono-lisa";