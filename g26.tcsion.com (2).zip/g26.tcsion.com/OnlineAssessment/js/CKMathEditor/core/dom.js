/**
 * @fileOverview Defines the {@link CKEDITOR.dom} object, which contains DOM
 *		manipulation objects and function.
 */

CKEDITOR.dom = {};

// PACKAGER_RENAME( CKEDITOR.dom )