CKEDITOR.inline = function(e, t) {
    if (!CKEDITOR.env.isCompatible) return null;
    e = CKEDITOR.dom.element.get(e);
    try {
        if (e.getEditor()) throw 'The editor instance "' + e.getEditor().name + '" is already attached to the provided element.'
    } catch (e) {
        return console.log(e), null
    }
    var n = new CKEDITOR.editor(t, e, CKEDITOR.ELEMENT_MODE_INLINE),
        i = e.is("textarea") ? e : null;
    return i ? (n.setData(i.getValue(), null, !0), (e = CKEDITOR.dom.element.createFromHtml('<div contenteditable="' + !!n.readOnly + '" class="cke_textarea_inline">' + i.getValue() + "</div>", CKEDITOR.document)).insertAfter(i), i.hide(), i.$.form && n._attachToForm()) : n.setData(e.getHtml(), null, !0), n.on("loaded", function() {
        n.fire("uiReady"), n.editable(e), n.container = e, n.ui.contentsElement = e, n.setData(n.getData(1)), n.resetDirty(), n.fire("contentDom"), n.mode = "wysiwyg", n.fire("mode"), n.status = "ready", n.fireOnce("instanceReady"), CKEDITOR.fire("instanceReady", null, n)
    }, null, null, 1e4), n.on("destroy", function() {
        i && (n.container.clearCustomData(), n.container.remove(), i.show()), n.element.clearCustomData(), delete n.element
    }), n
}, CKEDITOR.inlineAll = function() {
    var e, t;
    for (var n in CKEDITOR.dtd.$editable)
        for (var i = CKEDITOR.document.getElementsByTag(n), a = 0, l = i.count(); a < l; a++) "true" == (e = i.getItem(a)).getAttribute("contenteditable") && (t = {
            element: e,
            config: {}
        }, !1 !== CKEDITOR.fire("inline", t) && CKEDITOR.inline(e, t.config))
}, CKEDITOR.domReady(function() {
    !CKEDITOR.disableAutoInline && CKEDITOR.inlineAll()
});