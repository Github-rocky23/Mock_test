CKEDITOR.replaceClass = "ckeditor",
    function() {
        function e(e, i, o, n) {
            if (!CKEDITOR.env.isCompatible) return null;
            e = CKEDITOR.dom.element.get(e);
            try {
                if (e.getEditor()) throw 'The editor instance "' + e.getEditor().name + '" is already attached to the provided element.'
            } catch (e) {
                return console.log(e), null
            }
            var a = new CKEDITOR.editor(i, e, n);
            return n == CKEDITOR.ELEMENT_MODE_REPLACE && (e.setStyle("visibility", "hidden"), a._.required = e.hasAttribute("required"), e.removeAttribute("required")), o && a.setData(o, null, !0), a.on("loaded", function() {
                ! function(e) {
                    var t = e.name,
                        i = e.element,
                        o = e.elementMode,
                        n = e.fire("uiSpace", {
                            space: "top",
                            html: ""
                        }).html,
                        a = e.fire("uiSpace", {
                            space: "bottom",
                            html: ""
                        }).html,
                        s = new CKEDITOR.template('<{outerEl} id="cke_{name}" class="{id} cke cke_reset cke_chrome cke_editor_{name} cke_{langDir} ' + CKEDITOR.env.cssClass + '"  dir="{langDir}" lang="{langCode}" role="application"' + (e.title ? ' aria-labelledby="cke_{name}_arialbl"' : "") + ">" + (e.title ? '<span id="cke_{name}_arialbl" class="cke_voice_label">{voiceLabel}</span>' : "") + '<{outerEl} class="cke_inner cke_reset" role="presentation">{topHtml}<{outerEl} id="{contentId}" class="cke_contents cke_reset" role="presentation"></{outerEl}>{bottomHtml}</{outerEl}></{outerEl}>'),
                        r = CKEDITOR.dom.element.createFromHtml(s.output({
                            id: e.id,
                            name: t,
                            langDir: e.lang.dir,
                            langCode: e.langCode,
                            voiceLabel: e.title,
                            topHtml: n ? '<span id="' + e.ui.spaceId("top") + '" class="cke_top cke_reset_all" role="presentation" style="height:auto">' + n + "</span>" : "",
                            contentId: e.ui.spaceId("contents"),
                            bottomHtml: a ? '<span id="' + e.ui.spaceId("bottom") + '" class="cke_bottom cke_reset_all" role="presentation">' + a + "</span>" : "",
                            outerEl: CKEDITOR.env.ie ? "span" : "div"
                        }));
                    o == CKEDITOR.ELEMENT_MODE_REPLACE ? (i.hide(), r.insertAfter(i)) : i.append(r);
                    e.container = r, e.ui.contentsElement = e.ui.space("contents"), n && e.ui.space("top").unselectable(), a && e.ui.space("bottom").unselectable();
                    var l = e.config.width,
                        c = e.config.height;
                    l && r.setStyle("width", CKEDITOR.tools.cssLength(l));
                    c && e.ui.space("contents").setStyle("height", CKEDITOR.tools.cssLength(c));
                    r.disableContextMenu(), CKEDITOR.env.webkit && r.on("focus", function() {
                        e.focus()
                    }), e.fireOnce("uiReady")
                }(a), n == CKEDITOR.ELEMENT_MODE_REPLACE && a.config.autoUpdateElement && e.$.form && a._attachToForm(), a.setMode(a.config.startupMode, function() {
                    a.resetDirty(), a.status = "ready", a.fireOnce("instanceReady"), CKEDITOR.fire("instanceReady", null, a)
                })
            }), a.on("destroy", t), a
        }

        function t() {
            var e = this.container,
                t = this.element;
            e && (e.clearCustomData(), e.remove()), t && (t.clearCustomData(), this.elementMode == CKEDITOR.ELEMENT_MODE_REPLACE && (t.show(), this._.required && t.setAttribute("required", "required")), delete this.element)
        }
        CKEDITOR.replace = function(t, i) {
            return e(t, i, null, CKEDITOR.ELEMENT_MODE_REPLACE)
        }, CKEDITOR.appendTo = function(t, i, o) {
            return e(t, i, o, CKEDITOR.ELEMENT_MODE_APPENDTO)
        }, CKEDITOR.replaceAll = function() {
            for (var e = document.getElementsByTagName("textarea"), t = 0; t < e.length; t++) {
                var i = null,
                    o = e[t];
                if (o.name || o.id) {
                    if ("string" == typeof arguments[0]) {
                        if (!new RegExp("(?:^|\\s)" + arguments[0] + "(?:$|\\s)").test(o.className)) continue
                    } else if ("function" == typeof arguments[0] && (i = {}, !1 === arguments[0](o, i))) continue;
                    this.replace(o, i)
                }
            }
        }, CKEDITOR.editor.prototype.addMode = function(e, t) {
            (this._.modes || (this._.modes = {}))[e] = t
        }, CKEDITOR.editor.prototype.setMode = function(e, t) {
            var i = this,
                o = this._.modes;
            if (e != i.mode && o && o[e]) {
                if (i.fire("beforeSetMode", e), i.mode) {
                    var n, a = i.checkDirty(),
                        s = i._.previousModeData,
                        r = 0;
                    i.fire("beforeModeUnload"), i.editable(0), i._.previousMode = i.mode, i._.previousModeData = n = i.getData(1), "source" == i.mode && s == n && (i.fire("lockSnapshot", {
                        forceUpdate: !0
                    }), r = 1), i.ui.space("contents").setHtml(""), i.mode = ""
                } else i._.previousModeData = i.getData(1);
                this._.modes[e](function() {
                    i.mode = e, void 0 !== a && !a && i.resetDirty(), r ? i.fire("unlockSnapshot") : "wysiwyg" == e && i.fire("saveSnapshot"), setTimeout(function() {
                        i.fire("mode"), t && t.call(i)
                    }, 0)
                })
            }
        }, CKEDITOR.editor.prototype.resize = function(e, t, i, o) {
            var n, a = this.container,
                s = this.ui.space("contents"),
                r = CKEDITOR.env.webkit && this.document && this.document.getWindow().$.frameElement;
            (n = o ? this.container.getFirst(function(e) {
                return e.type == CKEDITOR.NODE_ELEMENT && e.hasClass("cke_inner")
            }) : a).setSize("width", e, !0), r && (r.style.width = "1%");
            var l = (n.$.offsetHeight || 0) - (s.$.clientHeight || 0),
                c = Math.max(t - (i ? 0 : l), 0),
                d = i ? t + l : t;
            s.setStyle("height", c + "px"), r && (r.style.width = "100%"), this.fire("resize", {
                outerHeight: d,
                contentsHeight: c,
                outerWidth: e || n.getSize("width")
            })
        }, CKEDITOR.editor.prototype.getResizable = function(e) {
            return e ? this.ui.space("contents") : this.container
        }, CKEDITOR.domReady(function() {
            CKEDITOR.replaceClass && CKEDITOR.replaceAll(CKEDITOR.replaceClass)
        })
    }(), CKEDITOR.config.startupMode = "wysiwyg";