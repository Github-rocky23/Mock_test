CKEDITOR.event || (CKEDITOR.event = function() {}, CKEDITOR.event.implementOn = function(e) {
    var t = CKEDITOR.event.prototype;
    for (var n in t) null == e[n] && (e[n] = t[n])
}, CKEDITOR.event.prototype = function() {
    var e, t, n, r, i = function(e) {
            var t = e.getPrivate && e.getPrivate() || e._ || (e._ = {});
            return t.events || (t.events = {})
        },
        s = function(e) {
            this.name = e, this.listeners = []
        };

    function o(e) {
        var t = i(this);
        return t[e] || (t[e] = new s(e))
    }
    return s.prototype = {
        getListenerIndex: function(e) {
            for (var t = 0, n = this.listeners; t < n.length; t++)
                if (n[t].fn == e) return t;
            return -1
        }
    }, {
        define: function(e, t) {
            var n = o.call(this, e);
            CKEDITOR.tools.extend(n, t, !0)
        },
        on: function(e, t, n, r, i) {
            function s(i, s, o, v) {
                var f = {
                    name: e,
                    sender: this,
                    editor: i,
                    data: s,
                    listenerData: r,
                    stop: o,
                    cancel: v,
                    removeListener: a
                };
                return !1 !== t.call(n, f) && f.data
            }

            function a() {
                u.removeListener(e, t)
            }
            var v = o.call(this, e);
            if (v.getListenerIndex(t) < 0) {
                var f = v.listeners;
                n || (n = this), isNaN(i) && (i = 10);
                var u = this;
                s.fn = t, s.priority = i;
                for (var l = f.length - 1; l >= 0; l--)
                    if (f[l].priority <= i) return f.splice(l + 1, 0, s), {
                        removeListener: a
                    };
                f.unshift(s)
            }
            return {
                removeListener: a
            }
        },
        once: function() {
            var e = Array.prototype.slice.call(arguments),
                t = e[1];
            return e[1] = function(e) {
                return e.removeListener(), t.apply(this, arguments)
            }, this.on.apply(this, e)
        },
        capture: function() {
            CKEDITOR.event.useCapture = 1;
            var e = this.on.apply(this, arguments);
            return CKEDITOR.event.useCapture = 0, e
        },
        fire: (e = 0, t = function() {
            e = 1
        }, n = 0, r = function() {
            n = 1
        }, function(s, o, a) {
            var v = i(this)[s],
                f = e,
                u = n;
            if (e = n = 0, v) {
                var l = v.listeners;
                if (l.length) {
                    var c;
                    l = l.slice(0);
                    for (var h = 0; h < l.length; h++) {
                        if (v.errorProof) try {
                            c = l[h].call(this, a, o, t, r)
                        } catch (e) {} else c = l[h].call(this, a, o, t, r);
                        if (!1 === c ? n = 1 : void 0 !== c && (o = c), e || n) break
                    }
                }
            }
            var p = !n && (void 0 === o || o);
            return e = f, n = u, p
        }),
        fireOnce: function(e, t, n) {
            var r = this.fire(e, t, n);
            return delete i(this)[e], r
        },
        removeListener: function(e, t) {
            var n = i(this)[e];
            if (n) {
                var r = n.getListenerIndex(t);
                r >= 0 && n.listeners.splice(r, 1)
            }
        },
        removeAllListeners: function() {
            var e = i(this);
            for (var t in e) delete e[t]
        },
        hasListeners: function(e) {
            var t = i(this)[e];
            return t && t.listeners.length > 0
        }
    }
}());