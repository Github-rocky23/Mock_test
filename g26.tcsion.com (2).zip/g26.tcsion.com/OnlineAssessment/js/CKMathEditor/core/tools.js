! function() {
    var e, t, r, n, o, i, a, l = [],
        s = CKEDITOR.env.gecko ? "-moz-" : CKEDITOR.env.webkit ? "-webkit-" : CKEDITOR.env.ie ? "-ms-" : "",
        u = /&/g,
        c = />/g,
        f = /</g,
        p = /"/g,
        d = "abcdefghijklmnopqrstuvwxyz0123456789",
        h = /&(lt|gt|amp|quot|nbsp|shy|#\d{1,5});/g,
        g = {
            lt: "<",
            gt: ">",
            amp: "&",
            quot: '"',
            nbsp: "�",
            shy: "�"
        },
        F = function(e, t) {
            return "#" == t[0] ? String.fromCharCode(parseInt(t.slice(1), 10)) : g[t]
        };

    function y(e, t, r) {
        this._minInterval = e, this._context = r, this._scheduledTimer = 0, this._lastOutput = 0, this._output = CKEDITOR.tools.bind(t, r || {});
        var n = this;
        this.input = function() {
            if (!n._scheduledTimer || !1 !== n._reschedule()) {
                var e = (new Date).getTime() - n._lastOutput;
                e < n._minInterval ? n._scheduledTimer = setTimeout(t, n._minInterval - e) : t()
            }

            function t() {
                n._lastOutput = (new Date).getTime(), n._scheduledTimer = 0, n._call()
            }
        }
    }

    function m(e, t, r) {
        y.call(this, e, t, r), this._args = [];
        var n = this;
        this.input = CKEDITOR.tools.override(this.input, function(e) {
            return function() {
                n._args = Array.prototype.slice.call(arguments), e.call(this)
            }
        })
    }
    CKEDITOR.on("reset", function() {
        l = []
    }), CKEDITOR.tools = {
        arrayCompare: function(e, t) {
            if (!e && !t) return !0;
            if (!e || !t || e.length != t.length) return !1;
            for (var r = 0; r < e.length; r++)
                if (e[r] != t[r]) return !1;
            return !0
        },
        getIndex: function(e, t) {
            for (var r = 0; r < e.length; ++r)
                if (t(e[r])) return r;
            return -1
        },
        clone: function(e) {
            var t;
            if (e && e instanceof Array) {
                t = [];
                for (var r = 0; r < e.length; r++) t[r] = CKEDITOR.tools.clone(e[r]);
                return t
            }
            if (null === e || "object" != typeof e || e instanceof String || e instanceof Number || e instanceof Boolean || e instanceof Date || e instanceof RegExp) return e;
            if (e.nodeType || e.window === e) return e;
            for (var n in t = new e.constructor, e) {
                var o = e[n];
                t[n] = CKEDITOR.tools.clone(o)
            }
            return t
        },
        capitalize: function(e, t) {
            return e.charAt(0).toUpperCase() + (t ? e.slice(1) : e.slice(1).toLowerCase())
        },
        extend: function(e) {
            var t, r, n = arguments.length;
            "boolean" == typeof(t = arguments[n - 1]) ? n-- : "boolean" == typeof(t = arguments[n - 2]) && (r = arguments[n - 1], n -= 2);
            for (var o = 1; o < n; o++) {
                var i = arguments[o];
                for (var a in i) !0 !== t && null != e[a] || (!r || a in r) && (e[a] = i[a])
            }
            return e
        },
        prototypedCopy: function(e) {
            var t = function() {};
            return t.prototype = e, new t
        },
        copy: function(e) {
            var t, r = {};
            for (t in e) r[t] = e[t];
            return r
        },
        isArray: function(e) {
            return "[object Array]" == Object.prototype.toString.call(e)
        },
        isEmpty: function(e) {
            for (var t in e)
                if (e.hasOwnProperty(t)) return !1;
            return !0
        },
        cssVendorPrefix: function(e, t, r) {
            if (r) return s + e + ":" + t + ";" + e + ":" + t;
            var n = {};
            return n[e] = t, n[s + e] = t, n
        },
        cssStyleToDomStyle: (i = document.createElement("div").style, a = void 0 !== i.cssFloat ? "cssFloat" : void 0 !== i.styleFloat ? "styleFloat" : "float", function(e) {
            return "float" == e ? a : e.replace(/-./g, function(e) {
                return e.substr(1).toUpperCase()
            })
        }),
        buildStyleHtml: function(e) {
            e = [].concat(e);
            for (var t, r = [], n = 0; n < e.length; n++)(t = e[n]) && (/@import|[{}]/.test(t) ? r.push("<style>" + t + "</style>") : r.push('<link type="text/css" rel=stylesheet href="' + t + '">'));
            return r.join("")
        },
        htmlEncode: function(e) {
            return null == e ? "" : String(e).replace(u, "&amp;").replace(c, "&gt;").replace(f, "&lt;")
        },
        htmlDecode: function(e) {
            return e.replace(h, F)
        },
        htmlEncodeAttr: function(e) {
            return CKEDITOR.tools.htmlEncode(e).replace(p, "&quot;")
        },
        htmlDecodeAttr: function(e) {
            return CKEDITOR.tools.htmlDecode(e)
        },
        transformPlainTextToHtml: function(e, t) {
            var r = t == CKEDITOR.ENTER_BR,
                n = this.htmlEncode(e.replace(/\r\n/g, "\n"));
            n = n.replace(/\t/g, "&nbsp;&nbsp; &nbsp;");
            var o = t == CKEDITOR.ENTER_P ? "p" : "div";
            if (!r) {
                var i = /\n{2}/g;
                if (i.test(n)) {
                    var a = "<" + o + ">",
                        l = "</" + o + ">";
                    n = a + n.replace(i, function() {
                        return l + a
                    }) + l
                }
            }
            return n = n.replace(/\n/g, "<br>"), r || (n = n.replace(new RegExp("<br>(?=</" + o + ">)"), function(e) {
                return CKEDITOR.tools.repeat(e, 2)
            })), n = (n = n.replace(/^ | $/g, "&nbsp;")).replace(/(>|\s) /g, function(e, t) {
                return t + "&nbsp;"
            }).replace(/ (?=<)/g, "&nbsp;")
        },
        getNextNumber: (o = 0, function() {
            return ++o
        }),
        getNextId: function() {
            return "cke_" + this.getNextNumber()
        },
        getUniqueId: function() {
            for (var e = "e", t = 0; t < 8; t++) e += Math.floor(65536 * (1 + Math.random())).toString(16).substring(1);
            return e
        },
        override: function(e, t) {
            var r = t(e);
            return r.prototype = e.prototype, r
        },
        setTimeout: function(e, t, r, n, o) {
            return o || (o = window), r || (r = o), o.setTimeout(function() {
                n ? e.apply(r, [].concat(n)) : e.apply(r)
            }, t || 0)
        },
        throttle: function(e, t, r) {
            return new this.buffers.throttle(e, t, r)
        },
        trim: (n = /(?:^[ \t\n\r]+)|(?:[ \t\n\r]+$)/g, function(e) {
            return e.replace(n, "")
        }),
        ltrim: function() {
            var e = /^[ \t\n\r]+/g;
            return function(t) {
                return t.replace(e, "")
            }
        }(),
        rtrim: function() {
            var e = /[ \t\n\r]+$/g;
            return function(t) {
                return t.replace(e, "")
            }
        }(),
        indexOf: function(e, t) {
            if ("function" == typeof t) {
                for (var r = 0, n = e.length; r < n; r++)
                    if (t(e[r])) return r
            } else {
                if (e.indexOf) return e.indexOf(t);
                for (r = 0, n = e.length; r < n; r++)
                    if (e[r] === t) return r
            }
            return -1
        },
        search: function(e, t) {
            var r = CKEDITOR.tools.indexOf(e, t);
            return r >= 0 ? e[r] : null
        },
        bind: function(e, t) {
            return function() {
                return e.apply(t, arguments)
            }
        },
        createClass: function(e) {
            var t = e.$,
                r = e.base,
                n = e.privates || e._,
                o = e.proto,
                i = e.statics;
            if (!t && (t = function() {
                    r && this.base.apply(this, arguments)
                }), n) {
                var a = t;
                t = function() {
                    var e = this._ || (this._ = {});
                    for (var t in n) {
                        var r = n[t];
                        e[t] = "function" == typeof r ? CKEDITOR.tools.bind(r, this) : r
                    }
                    a.apply(this, arguments)
                }
            }
            return r && (t.prototype = this.prototypedCopy(r.prototype), t.prototype.constructor = t, t.base = r, t.baseProto = r.prototype, t.prototype.base = function() {
                this.base = r.prototype.base, r.apply(this, arguments), this.base = arguments.callee
            }), o && this.extend(t.prototype, o, !0), i && this.extend(t, i, !0), t
        },
        addFunction: function(e, t) {
            return l.push(function() {
                return e.apply(t || this, arguments)
            }) - 1
        },
        removeFunction: function(e) {
            l[e] = null
        },
        callFunction: function(e) {
            var t = l[e];
            return t && t.apply(window, Array.prototype.slice.call(arguments, 1))
        },
        cssLength: (r = /^-?\d+\.?\d*px$/, function(e) {
            return t = CKEDITOR.tools.trim(e + "") + "px", r.test(t) ? t : e || ""
        }),
        convertToPx: function(t) {
            if (e || (e = CKEDITOR.dom.element.createFromHtml('<div style="position:absolute;left:-9999px;top:-9999px;margin:0px;padding:0px;border:0px;"></div>', CKEDITOR.document), CKEDITOR.document.getBody().append(e)), !/%$/.test(t)) {
                var r, n = parseFloat(t) < 0;
                return n && (t = t.replace("-", "")), e.setStyle("width", t), r = e.$.clientWidth, n ? -r : r
            }
            return t
        },
        repeat: function(e, t) {
            return new Array(t + 1).join(e)
        },
        tryThese: function() {
            for (var e, t = 0, r = arguments.length; t < r; t++) {
                var n = arguments[t];
                try {
                    e = n();
                    break
                } catch (e) {}
            }
            return e
        },
        genKey: function() {
            return Array.prototype.slice.call(arguments).join("-")
        },
        defer: function(e) {
            return function() {
                var t = arguments,
                    r = this;
                window.setTimeout(function() {
                    e.apply(r, t)
                }, 0)
            }
        },
        normalizeCssText: function(e, t) {
            var r, n = [],
                o = CKEDITOR.tools.parseCssText(e, !0, t);
            for (r in o) n.push(r + ":" + o[r]);
            return n.sort(), n.length ? n.join(";") + ";" : ""
        },
        convertRgbToHex: function(e) {
            return e.replace(/(?:rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\))/gi, function(e, t, r, n) {
                for (var o = [t, r, n], i = 0; i < 3; i++) o[i] = ("0" + parseInt(o[i], 10).toString(16)).slice(-2);
                return "#" + o.join("")
            })
        },
        normalizeHex: function(e) {
            return e.replace(/#(([0-9a-f]{3}){1,2})($|;|\s+)/gi, function(e, t, r, n) {
                var o = t.toLowerCase();
                if (3 == o.length) {
                    var i = o.split("");
                    o = [i[0], i[0], i[1], i[1], i[2], i[2]].join("")
                }
                return "#" + o + n
            })
        },
        parseCssText: function(e, t, r) {
            var n = {};
            r && (e = new CKEDITOR.dom.element("span").setAttribute("style", e).getAttribute("style") || "");
            return e && (e = CKEDITOR.tools.normalizeHex(CKEDITOR.tools.convertRgbToHex(e))), e && ";" != e ? (e.replace(/&quot;/g, '"').replace(/\s*([^:;\s]+)\s*:\s*([^;]+)\s*(?=;|$)/g, function(e, r, o) {
                t && ("font-family" == (r = r.toLowerCase()) && (o = o.replace(/\s*,\s*/g, ",")), o = CKEDITOR.tools.trim(o)), n[r] = o
            }), n) : n
        },
        writeCssText: function(e, t) {
            var r, n = [];
            for (r in e) n.push(r + ":" + e[r]);
            return t && n.sort(), n.join("; ")
        },
        objectCompare: function(e, t, r) {
            var n;
            if (!e && !t) return !0;
            if (!e || !t) return !1;
            for (n in e)
                if (e[n] != t[n]) return !1;
            if (!r)
                for (n in t)
                    if (e[n] != t[n]) return !1;
            return !0
        },
        objectKeys: function(e) {
            var t = [];
            for (var r in e) t.push(r);
            return t
        },
        convertArrayToObject: function(e, t) {
            var r = {};
            1 == arguments.length && (t = !0);
            for (var n = 0, o = e.length; n < o; ++n) r[e[n]] = t;
            return r
        },
        fixDomain: function() {
            for (var e;;) try {
                e = window.parent.document.domain;
                break
            } catch (t) {
                if (!(e = e ? e.replace(/.+?(?:\.|$)/, "") : document.domain)) break;
                document.domain = e
            }
            return !!e
        },
        eventsBuffer: function(e, t, r) {
            return new this.buffers.event(e, t, r)
        },
        enableHtml5Elements: function(e, t) {
            for (var r, n = "abbr,article,aside,audio,bdi,canvas,data,datalist,details,figcaption,figure,footer,header,hgroup,main,mark,meter,nav,output,progress,section,summary,time,video".split(","), o = n.length; o--;) r = e.createElement(n[o]), t && e.appendChild(r)
        },
        checkIfAnyArrayItemMatches: function(e, t) {
            for (var r = 0, n = e.length; r < n; ++r)
                if (e[r].match(t)) return !0;
            return !1
        },
        checkIfAnyObjectPropertyMatches: function(e, t) {
            for (var r in e)
                if (r.match(t)) return !0;
            return !1
        },
        keystrokeToString: function(e, t) {
            var r = this.keystrokeToArray(e, t);
            return r.display = r.display.join("+"), r.aria = r.aria.join("+"), r
        },
        keystrokeToArray: function(e, t) {
            var r = 16711680 & t,
                n = 65535 & t,
                o = CKEDITOR.env.mac,
                i = [],
                a = [];
            return r & CKEDITOR.CTRL && (i.push(o ? "âŒ˜" : e[17]), a.push(o ? e[224] : e[17])), r & CKEDITOR.ALT && (i.push(o ? "âŒ¥" : e[18]), a.push(e[18])), r & CKEDITOR.SHIFT && (i.push(o ? "â‡§" : e[16]), a.push(e[16])), n && (e[n] ? (i.push(e[n]), a.push(e[n])) : (i.push(String.fromCharCode(n)), a.push(String.fromCharCode(n)))), {
                display: i,
                aria: a
            }
        },
        transparentImageData: "data:image/gif;base64,R0lGODlhAQABAPABAP///wAAACH5BAEKAAAALAAAAAABAAEAAAICRAEAOw==",
        getCookie: function(e) {
            e = e.toLowerCase();
            for (var t, r = document.cookie.split(";"), n = 0; n < r.length; n++)
                if (t = r[n].split("="), decodeURIComponent(CKEDITOR.tools.trim(t[0]).toLowerCase()) === e) return decodeURIComponent(t.length > 1 ? t[1] : "");
            return null
        },
        setCookie: function(e, t) {
            document.cookie = encodeURIComponent(e) + "=" + encodeURIComponent(t) + ";path=/"
        },
        getCsrfToken: function() {
            var e = CKEDITOR.tools.getCookie("ckCsrfToken");
            return e && 40 == e.length || (e = function(e) {
                var t = [],
                    r = "";
                if (window.crypto && window.crypto.getRandomValues) t = new Uint8Array(e), window.crypto.getRandomValues(t);
                else
                    for (var n = 0; n < e; n++) t.push(Math.floor(256 * Math.random()));
                for (var o = 0; o < t.length; o++) {
                    var i = d.charAt(t[o] % d.length);
                    r += Math.random() > .5 ? i.toUpperCase() : i
                }
                return r
            }(40), CKEDITOR.tools.setCookie("ckCsrfToken", e)), e
        },
        escapeCss: function(e) {
            return e ? window.CSS && CSS.escape ? CSS.escape(e) : isNaN(parseInt(e.charAt(0), 10)) ? e : "\\3" + e.charAt(0) + " " + e.substring(1, e.length) : ""
        },
        getMouseButton: function(e) {
            var t = e.data,
                r = t && t.$;
            return !(!t || !r) && (CKEDITOR.env.ie && CKEDITOR.env.version < 9 ? 4 === r.button ? CKEDITOR.MOUSE_BUTTON_MIDDLE : 1 === r.button ? CKEDITOR.MOUSE_BUTTON_LEFT : CKEDITOR.MOUSE_BUTTON_RIGHT : r.button)
        },
        convertHexStringToBytes: function(e) {
            var t, r = [],
                n = e.length / 2;
            for (t = 0; t < n; t++) r.push(parseInt(e.substr(2 * t, 2), 16));
            return r
        },
        convertBytesToBase64: function(e) {
            var t, r = "",
                n = e.length;
            for (t = 0; t < n; t += 3) {
                var o, i = e.slice(t, t + 3),
                    a = i.length,
                    l = [];
                if (a < 3)
                    for (o = a; o < 3; o++) i[o] = 0;
                for (l[0] = (252 & i[0]) >> 2, l[1] = (3 & i[0]) << 4 | i[1] >> 4, l[2] = (15 & i[1]) << 2 | (192 & i[2]) >> 6, l[3] = 63 & i[2], o = 0; o < 4; o++) r += o <= a ? "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".charAt(l[o]) : "="
            }
            return r
        },
        style: {
            parse: {
                _colors: {
                    aliceblue: "#F0F8FF",
                    antiquewhite: "#FAEBD7",
                    aqua: "#00FFFF",
                    aquamarine: "#7FFFD4",
                    azure: "#F0FFFF",
                    beige: "#F5F5DC",
                    bisque: "#FFE4C4",
                    black: "#000000",
                    blanchedalmond: "#FFEBCD",
                    blue: "#0000FF",
                    blueviolet: "#8A2BE2",
                    brown: "#A52A2A",
                    burlywood: "#DEB887",
                    cadetblue: "#5F9EA0",
                    chartreuse: "#7FFF00",
                    chocolate: "#D2691E",
                    coral: "#FF7F50",
                    cornflowerblue: "#6495ED",
                    cornsilk: "#FFF8DC",
                    crimson: "#DC143C",
                    cyan: "#00FFFF",
                    darkblue: "#00008B",
                    darkcyan: "#008B8B",
                    darkgoldenrod: "#B8860B",
                    darkgray: "#A9A9A9",
                    darkgreen: "#006400",
                    darkgrey: "#A9A9A9",
                    darkkhaki: "#BDB76B",
                    darkmagenta: "#8B008B",
                    darkolivegreen: "#556B2F",
                    darkorange: "#FF8C00",
                    darkorchid: "#9932CC",
                    darkred: "#8B0000",
                    darksalmon: "#E9967A",
                    darkseagreen: "#8FBC8F",
                    darkslateblue: "#483D8B",
                    darkslategray: "#2F4F4F",
                    darkslategrey: "#2F4F4F",
                    darkturquoise: "#00CED1",
                    darkviolet: "#9400D3",
                    deeppink: "#FF1493",
                    deepskyblue: "#00BFFF",
                    dimgray: "#696969",
                    dimgrey: "#696969",
                    dodgerblue: "#1E90FF",
                    firebrick: "#B22222",
                    floralwhite: "#FFFAF0",
                    forestgreen: "#228B22",
                    fuchsia: "#FF00FF",
                    gainsboro: "#DCDCDC",
                    ghostwhite: "#F8F8FF",
                    gold: "#FFD700",
                    goldenrod: "#DAA520",
                    gray: "#808080",
                    green: "#008000",
                    greenyellow: "#ADFF2F",
                    grey: "#808080",
                    honeydew: "#F0FFF0",
                    hotpink: "#FF69B4",
                    indianred: "#CD5C5C",
                    indigo: "#4B0082",
                    ivory: "#FFFFF0",
                    khaki: "#F0E68C",
                    lavender: "#E6E6FA",
                    lavenderblush: "#FFF0F5",
                    lawngreen: "#7CFC00",
                    lemonchiffon: "#FFFACD",
                    lightblue: "#ADD8E6",
                    lightcoral: "#F08080",
                    lightcyan: "#E0FFFF",
                    lightgoldenrodyellow: "#FAFAD2",
                    lightgray: "#D3D3D3",
                    lightgreen: "#90EE90",
                    lightgrey: "#D3D3D3",
                    lightpink: "#FFB6C1",
                    lightsalmon: "#FFA07A",
                    lightseagreen: "#20B2AA",
                    lightskyblue: "#87CEFA",
                    lightslategray: "#778899",
                    lightslategrey: "#778899",
                    lightsteelblue: "#B0C4DE",
                    lightyellow: "#FFFFE0",
                    lime: "#00FF00",
                    limegreen: "#32CD32",
                    linen: "#FAF0E6",
                    magenta: "#FF00FF",
                    maroon: "#800000",
                    mediumaquamarine: "#66CDAA",
                    mediumblue: "#0000CD",
                    mediumorchid: "#BA55D3",
                    mediumpurple: "#9370DB",
                    mediumseagreen: "#3CB371",
                    mediumslateblue: "#7B68EE",
                    mediumspringgreen: "#00FA9A",
                    mediumturquoise: "#48D1CC",
                    mediumvioletred: "#C71585",
                    midnightblue: "#191970",
                    mintcream: "#F5FFFA",
                    mistyrose: "#FFE4E1",
                    moccasin: "#FFE4B5",
                    navajowhite: "#FFDEAD",
                    navy: "#000080",
                    oldlace: "#FDF5E6",
                    olive: "#808000",
                    olivedrab: "#6B8E23",
                    orange: "#FFA500",
                    orangered: "#FF4500",
                    orchid: "#DA70D6",
                    palegoldenrod: "#EEE8AA",
                    palegreen: "#98FB98",
                    paleturquoise: "#AFEEEE",
                    palevioletred: "#DB7093",
                    papayawhip: "#FFEFD5",
                    peachpuff: "#FFDAB9",
                    peru: "#CD853F",
                    pink: "#FFC0CB",
                    plum: "#DDA0DD",
                    powderblue: "#B0E0E6",
                    purple: "#800080",
                    rebeccapurple: "#663399",
                    red: "#FF0000",
                    rosybrown: "#BC8F8F",
                    royalblue: "#4169E1",
                    saddlebrown: "#8B4513",
                    salmon: "#FA8072",
                    sandybrown: "#F4A460",
                    seagreen: "#2E8B57",
                    seashell: "#FFF5EE",
                    sienna: "#A0522D",
                    silver: "#C0C0C0",
                    skyblue: "#87CEEB",
                    slateblue: "#6A5ACD",
                    slategray: "#708090",
                    slategrey: "#708090",
                    snow: "#FFFAFA",
                    springgreen: "#00FF7F",
                    steelblue: "#4682B4",
                    tan: "#D2B48C",
                    teal: "#008080",
                    thistle: "#D8BFD8",
                    tomato: "#FF6347",
                    turquoise: "#40E0D0",
                    violet: "#EE82EE",
                    wheat: "#F5DEB3",
                    white: "#FFFFFF",
                    whitesmoke: "#F5F5F5",
                    yellow: "#FFFF00",
                    yellowgreen: "#9ACD32"
                },
                _borderStyle: ["none", "hidden", "dotted", "dashed", "solid", "double", "groove", "ridge", "inset", "outset"],
                _widthRegExp: /^(thin|medium|thick|[\+-]?\d+(\.\d+)?[a-z%]+|[\+-]?0+(\.0+)?|\.\d+[a-z%]+)$/,
                _rgbaRegExp: /rgba?\(\s*\d+%?\s*,\s*\d+%?\s*,\s*\d+%?\s*(?:,\s*[0-9.]+\s*)?\)/gi,
                _hslaRegExp: /hsla?\(\s*[0-9.]+\s*,\s*\d+%\s*,\s*\d+%\s*(?:,\s*[0-9.]+\s*)?\)/gi,
                background: function(e) {
                    var t = {},
                        r = this._findColor(e);
                    return r.length && (t.color = r[0], CKEDITOR.tools.array.forEach(r, function(t) {
                        e = e.replace(t, "")
                    })), (e = CKEDITOR.tools.trim(e)) && (t.unprocessed = e), t
                },
                margin: function(e) {
                    var t = {},
                        r = e.match(/(?:\-?[\.\d]+(?:%|\w*)|auto|inherit|initial|unset)/g) || ["0px"];
                    switch (r.length) {
                        case 1:
                            n([0, 0, 0, 0]);
                            break;
                        case 2:
                            n([0, 1, 0, 1]);
                            break;
                        case 3:
                            n([0, 1, 2, 1]);
                            break;
                        case 4:
                            n([0, 1, 2, 3])
                    }

                    function n(e) {
                        t.top = r[e[0]], t.right = r[e[1]], t.bottom = r[e[2]], t.left = r[e[3]]
                    }
                    return t
                },
                border: function(e) {
                    var t = {},
                        r = e.split(/\s+/g),
                        n = CKEDITOR.tools.style.parse._findColor(e);
                    return n.length && (t.color = n[0]), CKEDITOR.tools.array.forEach(r, function(e) {
                        t.style || -1 === CKEDITOR.tools.indexOf(CKEDITOR.tools.style.parse._borderStyle, e) ? t.width || !CKEDITOR.tools.style.parse._widthRegExp.test(e) || (t.width = e) : t.style = e
                    }), t
                },
                _findColor: function(e) {
                    var t = [],
                        r = CKEDITOR.tools.array;
                    return t = (t = (t = t.concat(e.match(this._rgbaRegExp) || [])).concat(e.match(this._hslaRegExp) || [])).concat(r.filter(e.split(/\s+/), function(e) {
                        return !!e.match(/^\#[a-f0-9]{3}(?:[a-f0-9]{3})?$/gi) || e.toLowerCase() in CKEDITOR.tools.style.parse._colors
                    }))
                }
            }
        },
        array: {
            filter: function(e, t, r) {
                var n = [];
                return this.forEach(e, function(o, i) {
                    t.call(r, o, i, e) && n.push(o)
                }), n
            },
            forEach: function(e, t, r) {
                var n, o = e.length;
                for (n = 0; n < o; n++) t.call(r, e[n], n, e)
            },
            map: function(e, t, r) {
                for (var n = [], o = 0; o < e.length; o++) n.push(t.call(r, e[o], o, e));
                return n
            },
            reduce: function(e, t, r, n) {
                for (var o = r, i = 0; i < e.length; i++) o = t.call(n, o, e[i], i, e);
                return o
            },
            every: function(e, t, r) {
                if (!e.length) return !0;
                var n = this.filter(e, t, r);
                return e.length === n.length
            }
        },
        object: {
            findKey: function(e, t) {
                if ("object" != typeof e) return null;
                var r;
                for (r in e)
                    if (e[r] === t) return r;
                return null
            },
            merge: function(e, t) {
                var r = CKEDITOR.tools,
                    n = r.clone(e),
                    o = r.clone(t);
                return r.array.forEach(r.objectKeys(o), function(e) {
                    "object" == typeof o[e] && "object" == typeof n[e] ? n[e] = r.object.merge(n[e], o[e]) : n[e] = o[e]
                }), n
            }
        },
        getAbsoluteRectPosition: function(e, t) {
            var r = CKEDITOR.tools.copy(t);
            ! function e(t) {
                if (!t) return;
                var n = t.getClientRect();
                r.top += n.top;
                r.left += n.left;
                "x" in r && "y" in r && (r.x += n.x, r.y += n.y);
                e(t.getWindow().getFrame())
            }(e.getFrame());
            var n = CKEDITOR.document.getWindow().getScrollPosition();
            return r.top += n.y, r.left += n.x, "x" in r && "y" in r && (r.y += n.y, r.x += n.x), r.right = r.left + r.width, r.bottom = r.top + r.height, r
        }
    }, y.prototype = {
        reset: function() {
            this._lastOutput = 0, this._clearTimer()
        },
        _reschedule: function() {
            return !1
        },
        _call: function() {
            this._output()
        },
        _clearTimer: function() {
            this._scheduledTimer && clearTimeout(this._scheduledTimer), this._scheduledTimer = 0
        }
    }, m.prototype = CKEDITOR.tools.prototypedCopy(y.prototype), m.prototype._reschedule = function() {
        this._scheduledTimer && this._clearTimer()
    }, m.prototype._call = function() {
        this._output.apply(this._context, this._args)
    }, CKEDITOR.tools.buffers = {}, CKEDITOR.tools.buffers.event = y, CKEDITOR.tools.buffers.throttle = m, CKEDITOR.tools.array.indexOf = CKEDITOR.tools.indexOf, CKEDITOR.tools.array.isArray = CKEDITOR.tools.isArray, CKEDITOR.MOUSE_BUTTON_LEFT = 0, CKEDITOR.MOUSE_BUTTON_MIDDLE = 1, CKEDITOR.MOUSE_BUTTON_RIGHT = 2
}();