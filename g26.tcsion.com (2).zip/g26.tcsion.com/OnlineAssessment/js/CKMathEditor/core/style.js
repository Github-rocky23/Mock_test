"use strict";
CKEDITOR.STYLE_BLOCK = 1, CKEDITOR.STYLE_INLINE = 2, CKEDITOR.STYLE_OBJECT = 3,
    function() {
        var e = {
                address: 1,
                div: 1,
                h1: 1,
                h2: 1,
                h3: 1,
                h4: 1,
                h5: 1,
                h6: 1,
                p: 1,
                pre: 1,
                section: 1,
                header: 1,
                footer: 1,
                nav: 1,
                article: 1,
                aside: 1,
                figure: 1,
                dialog: 1,
                hgroup: 1,
                time: 1,
                meter: 1,
                menu: 1,
                command: 1,
                keygen: 1,
                output: 1,
                progress: 1,
                details: 1,
                datagrid: 1,
                datalist: 1
            },
            t = {
                a: 1,
                blockquote: 1,
                embed: 1,
                hr: 1,
                img: 1,
                li: 1,
                object: 1,
                ol: 1,
                table: 1,
                td: 1,
                tr: 1,
                th: 1,
                ul: 1,
                dl: 1,
                dt: 1,
                dd: 1,
                form: 1,
                audio: 1,
                video: 1
            },
            n = /\s*(?:;\s*|$)/,
            r = /#\((.+?)\)/g,
            i = CKEDITOR.dom.walker.bookmark(0, 1),
            o = CKEDITOR.dom.walker.whitespaces(1);

        function s(e, t) {
            for (var n, r;
                (e = e.getParent()) && !e.equals(t);)
                if (e.getAttribute("data-nostyle")) n = e;
                else if (!r) {
                var i = e.getAttribute("contentEditable");
                "false" == i ? n = e : "true" == i && (r = 1)
            }
            return n
        }
        CKEDITOR.style = function(n, r) {
            if ("string" == typeof n.type) return new CKEDITOR.style.customHandlers[n.type](n);
            var i = n.attributes;
            i && i.style && (n.styles = CKEDITOR.tools.extend({}, n.styles, CKEDITOR.tools.parseCssText(i.style)), delete i.style), r && (k((n = CKEDITOR.tools.clone(n)).attributes, r), k(n.styles, r));
            var o = this.element = n.element ? "string" == typeof n.element ? n.element.toLowerCase() : n.element : "*";
            this.type = n.type || (e[o] ? CKEDITOR.STYLE_BLOCK : t[o] ? CKEDITOR.STYLE_OBJECT : CKEDITOR.STYLE_INLINE), "object" == typeof this.element && (this.type = CKEDITOR.STYLE_OBJECT), this._ = {
                definition: n
            }
        }, CKEDITOR.style.prototype = {
            apply: function(e) {
                if (e instanceof CKEDITOR.dom.document) return P.call(this, e.getSelection());
                if (this.checkApplicable(e.elementPath(), e)) {
                    var t = this._.enterMode;
                    t || (this._.enterMode = e.activeEnterMode), P.call(this, e.getSelection(), 0, e), this._.enterMode = t
                }
            },
            remove: function(e) {
                if (e instanceof CKEDITOR.dom.document) return P.call(this, e.getSelection(), 1);
                if (this.checkApplicable(e.elementPath(), e)) {
                    var t = this._.enterMode;
                    t || (this._.enterMode = e.activeEnterMode), P.call(this, e.getSelection(), 1, e), this._.enterMode = t
                }
            },
            applyToRange: function(e) {
                return this.applyToRange = this.type == CKEDITOR.STYLE_INLINE ? m : this.type == CKEDITOR.STYLE_BLOCK ? I : this.type == CKEDITOR.STYLE_OBJECT ? C : null, this.applyToRange(e)
            },
            removeFromRange: function(e) {
                return this.removeFromRange = this.type == CKEDITOR.STYLE_INLINE ? h : this.type == CKEDITOR.STYLE_BLOCK ? p : this.type == CKEDITOR.STYLE_OBJECT ? R : null, this.removeFromRange(e)
            },
            applyToObject: function(e) {
                S(e, this)
            },
            checkActive: function(e, t) {
                switch (this.type) {
                    case CKEDITOR.STYLE_BLOCK:
                        return this.checkElementRemovable(e.block || e.blockLimit, !0, t);
                    case CKEDITOR.STYLE_OBJECT:
                    case CKEDITOR.STYLE_INLINE:
                        for (var n, r = e.elements, i = 0; i < r.length; i++)
                            if (n = r[i], this.type != CKEDITOR.STYLE_INLINE || n != e.block && n != e.blockLimit) {
                                if (this.type == CKEDITOR.STYLE_OBJECT) {
                                    var o = n.getName();
                                    if (!("string" == typeof this.element ? o == this.element : o in this.element)) continue
                                }
                                if (this.checkElementRemovable(n, !0, t)) return !0
                            }
                }
                return !1
            },
            checkApplicable: function(e, t, n) {
                if (t && t instanceof CKEDITOR.filter && (n = t), n && !n.check(this)) return !1;
                switch (this.type) {
                    case CKEDITOR.STYLE_OBJECT:
                        return !!e.contains(this.element);
                    case CKEDITOR.STYLE_BLOCK:
                        return !!e.blockLimit.getDtd()[this.element]
                }
                return !0
            },
            checkElementMatch: function(e, t) {
                var n = this._.definition;
                if (!e || !n.ignoreReadonly && e.isReadOnly()) return !1;
                var r, i = e.getName();
                if ("string" == typeof this.element ? i == this.element : i in this.element) {
                    if (!t && !e.hasAttributes()) return !0;
                    if (!(r = function(e) {
                            var t = e._AC;
                            if (t) return t;
                            t = {};
                            var n = 0,
                                r = e.attributes;
                            if (r)
                                for (var i in r) n++, t[i] = r[i];
                            var o = CKEDITOR.style.getStyleText(e);
                            o && (t.style || n++, t.style = o);
                            return t._length = n, e._AC = t
                        }(n))._length) return !0;
                    for (var o in r)
                        if ("_length" != o) {
                            var s = e.getAttribute(o) || "";
                            if ("style" == o ? B(r[o], s) : r[o] == s) {
                                if (!t) return !0
                            } else if (t) return !1
                        }
                    if (t) return !0
                }
                return !1
            },
            checkElementRemovable: function(e, t, n) {
                if (this.checkElementMatch(e, t, n)) return !0;
                var r = L(this)[e.getName()];
                if (r) {
                    var i, o;
                    if (!(i = r.attributes)) return !0;
                    for (var s = 0; s < i.length; s++) {
                        o = i[s][0];
                        var a = e.getAttribute(o);
                        if (a) {
                            var l = i[s][1];
                            if (null === l) return !0;
                            if ("string" == typeof l) {
                                if (a == l) return !0
                            } else if (l.test(a)) return !0
                        }
                    }
                }
                return !1
            },
            buildPreview: function(e) {
                var t = this._.definition,
                    n = [],
                    r = t.element;
                "bdo" == r && (r = "span"), n = ["<", r];
                var i = t.attributes;
                if (i)
                    for (var o in i) n.push(" ", o, '="', i[o], '"');
                var s = CKEDITOR.style.getStyleText(t);
                return s && n.push(' style="', s, '"'), n.push(">", e || t.name, "</", r, ">"), n.join("")
            },
            getDefinition: function() {
                return this._.definition
            }
        }, CKEDITOR.style.getStyleText = function(e) {
            var t = e._ST;
            if (t) return t;
            t = e.styles;
            var r = e.attributes && e.attributes.style || "",
                i = "";
            for (var o in r.length && (r = r.replace(n, ";")), t) {
                var s = t[o],
                    a = (o + ":" + s).replace(n, ";");
                "inherit" == s ? i += a : r += a
            }
            return r.length && (r = CKEDITOR.tools.normalizeCssText(r, !0)), r += i, e._ST = r
        }, CKEDITOR.style.customHandlers = {}, CKEDITOR.style.addCustomHandler = function(e) {
            var t = function(e) {
                this._ = {
                    definition: e
                }, this.setup && this.setup(e)
            };
            return t.prototype = CKEDITOR.tools.extend(CKEDITOR.tools.prototypedCopy(CKEDITOR.style.prototype), {
                assignedTo: CKEDITOR.STYLE_OBJECT
            }, e, !0), this.customHandlers[e.type] = t, t
        };
        var a = CKEDITOR.POSITION_PRECEDING | CKEDITOR.POSITION_IDENTICAL | CKEDITOR.POSITION_IS_CONTAINED,
            l = CKEDITOR.POSITION_FOLLOWING | CKEDITOR.POSITION_IDENTICAL | CKEDITOR.POSITION_IS_CONTAINED;

        function c(e, t, n, r, i, o, s, l) {
            return r ? !i[r] || o ? 0 : s && !l ? 0 : T(t, n, e, a) : 1
        }

        function E(e, t, n, r) {
            return t && ((t.getDtd() || CKEDITOR.dtd.span)[n] || r) && (!e.parentRule || e.parentRule(t))
        }

        function u(e, t, n) {
            return !e || !CKEDITOR.dtd.$removeEmpty[e] || (t.getPosition(n) | a) == a
        }

        function f(e, t) {
            var n = e.type;
            return n == CKEDITOR.NODE_TEXT || t || n == CKEDITOR.NODE_ELEMENT && !e.getChildCount()
        }

        function T(e, t, n, r) {
            return (e.getPosition(t) | r) == r && (!n.childRule || n.childRule(e))
        }

        function m(e) {
            var t = e.document;
            if (e.collapsed) {
                var n = N(this, t);
                return e.insertNode(n), void e.moveToPosition(n, CKEDITOR.POSITION_BEFORE_END)
            }
            var r, o = this.element,
                a = this._.definition,
                m = a.ignoreReadonly,
                h = m || a.includeReadonly;
            null == h && (h = e.root.getCustomData("cke_includeReadonly"));
            var O = CKEDITOR.dtd[o];
            O || (r = !0, O = CKEDITOR.dtd.span), e.enlarge(CKEDITOR.ENLARGE_INLINE, 1), e.trim();
            var g, C = e.createBookmark(),
                R = C.startNode,
                I = C.endNode,
                p = R;
            if (!m) {
                var v = e.getCommonAncestor(),
                    y = s(R, v),
                    D = s(I, v);
                y && (p = y.getNextSourceNode(!0)), D && (I = D)
            }
            for (p.getPosition(I) == CKEDITOR.POSITION_FOLLOWING && (p = 0); p;) {
                var b = !1;
                if (p.equals(I)) p = null, b = !0;
                else {
                    var _ = p.type == CKEDITOR.NODE_ELEMENT ? p.getName() : null,
                        S = _ && "false" == p.getAttribute("contentEditable"),
                        k = _ && p.getAttribute("data-nostyle");
                    if (_ && p.data("cke-bookmark") || p.type === CKEDITOR.NODE_COMMENT) {
                        p = p.getNextSourceNode(!0);
                        continue
                    }
                    if (S && h && CKEDITOR.dtd.$block[_] && d.call(this, p), c(a, p, I, _, O, k, S, h))
                        if (E(a, p.getParent(), o, r)) {
                            if (!g && u(_, p, I) && (g = e.clone()).setStartBefore(p), f(p, S)) {
                                for (var L, A = p;
                                    (b = !A.getNext(i)) && O[(L = A.getParent()).getName()] && T(L, R, a, l);) A = L;
                                g.setEndAfter(A)
                            }
                        } else b = !0;
                    else b = !0;
                    p = p.getNextSourceNode(k || S)
                }
                if (b && g && !g.collapsed) {
                    for (var B, P, M, w = N(this, t), x = w.hasAttributes(), Y = g.getCommonAncestor(), F = {
                            styles: {},
                            attrs: {},
                            blockedStyles: {},
                            blockedAttrs: {}
                        }; w && Y;) {
                        if (Y.getName() == o) {
                            for (B in a.attributes) !F.blockedAttrs[B] && (M = Y.getAttribute(P)) && (w.getAttribute(B) == M ? F.attrs[B] = 1 : F.blockedAttrs[B] = 1);
                            for (P in a.styles) !F.blockedStyles[P] && (M = Y.getStyle(P)) && (w.getStyle(P) == M ? F.styles[P] = 1 : F.blockedStyles[P] = 1)
                        }
                        Y = Y.getParent()
                    }
                    for (B in F.attrs) w.removeAttribute(B);
                    for (P in F.styles) w.removeStyle(P);
                    x && !w.hasAttributes() && (w = null), w ? (g.extractContents().appendTo(w), g.insertNode(w), K.call(this, w), w.mergeSiblings(), CKEDITOR.env.ie || w.$.normalize()) : (w = new CKEDITOR.dom.element("span"), g.extractContents().appendTo(w), g.insertNode(w), K.call(this, w), w.remove(!0)), g = null
                }
            }
            e.moveToBookmark(C), e.shrink(CKEDITOR.SHRINK_TEXT), e.shrink(CKEDITOR.NODE_ELEMENT, !0)
        }

        function h(e) {
            e.enlarge(CKEDITOR.ENLARGE_INLINE, 1);
            var t = e.createBookmark(),
                n = t.startNode,
                r = this._.definition.alwaysRemoveElement;
            if (e.collapsed) {
                for (var i, o, s = new CKEDITOR.dom.elementPath(n.getParent(), e.root), a = 0; a < s.elements.length && (o = s.elements[a]) && (o != s.block && o != s.blockLimit); a++) {
                    var l;
                    this.checkElementRemovable(o) && (!r && e.collapsed && (e.checkBoundaryOfElement(o, CKEDITOR.END) || (l = e.checkBoundaryOfElement(o, CKEDITOR.START))) ? (i = o).match = l ? "start" : "end" : (o.mergeSiblings(), o.is(this.element) ? D.call(this, o) : b(o, L(this)[o.getName()])))
                }
                if (i) {
                    var c = n;
                    for (a = 0;; a++) {
                        var E = s.elements[a];
                        if (E.equals(i)) break;
                        E.match || ((E = E.clone()).append(c), c = E)
                    }
                    c["start" == i.match ? "insertBefore" : "insertAfter"](i)
                }
            } else {
                var u = t.endNode,
                    f = this;
                h();
                for (var T = n; !T.equals(u);) {
                    var m = T.getNextSourceNode();
                    T.type == CKEDITOR.NODE_ELEMENT && this.checkElementRemovable(T) && (T.getName() == this.element ? D.call(this, T) : b(T, L(this)[T.getName()]), m.type == CKEDITOR.NODE_ELEMENT && m.contains(n) && (h(), m = n.getNext())), T = m
                }
            }

            function h() {
                for (var e = new CKEDITOR.dom.elementPath(n.getParent()), t = new CKEDITOR.dom.elementPath(u.getParent()), r = null, i = null, o = 0; o < e.elements.length; o++) {
                    var s = e.elements[o];
                    if (s == e.block || s == e.blockLimit) break;
                    f.checkElementRemovable(s, !0) && (r = s)
                }
                for (o = 0; o < t.elements.length && ((s = t.elements[o]) != t.block && s != t.blockLimit); o++) f.checkElementRemovable(s, !0) && (i = s);
                i && u.breakParent(i), r && n.breakParent(r)
            }
            e.moveToBookmark(t), e.shrink(CKEDITOR.NODE_ELEMENT, !0)
        }

        function d(e) {
            for (var t, n = function(e) {
                    var t = [];
                    return e.forEach(function(e) {
                        if ("true" == e.getAttribute("contenteditable")) return t.push(e), !1
                    }, CKEDITOR.NODE_ELEMENT, !0), t
                }(e), r = n.length, i = 0, o = r && new CKEDITOR.dom.range(e.getDocument()); i < r; ++i) O(t = n[i], this) && (o.selectNodeContents(t), m.call(this, o))
        }

        function O(e, t) {
            var n = CKEDITOR.filter.instances[e.data("cke-filter")];
            return n ? n.check(t) : 1
        }

        function g(e, t) {
            return e.activeFilter ? e.activeFilter.check(t) : 1
        }

        function C(e) {
            var t = e.getEnclosedNode() || e.getCommonAncestor(!1, !0),
                n = new CKEDITOR.dom.elementPath(t, e.root).contains(this.element, 1);
            n && !n.isReadOnly() && S(n, this)
        }

        function R(e) {
            var t = e.getCommonAncestor(!0, !0),
                n = new CKEDITOR.dom.elementPath(t, e.root).contains(this.element, 1);
            if (n) {
                var r = this._.definition,
                    i = r.attributes;
                if (i)
                    for (var o in i) n.removeAttribute(o, i[o]);
                if (r.styles)
                    for (var s in r.styles) r.styles.hasOwnProperty(s) && n.removeStyle(s)
            }
        }

        function I(e) {
            var t = e.createBookmark(!0),
                n = e.createIterator();
            n.enforceRealBlocks = !0, this._.enterMode && (n.enlargeBr = this._.enterMode != CKEDITOR.ENTER_BR);
            for (var r, i = e.document; r = n.getNextParagraph();) !r.isReadOnly() && g(n, this) && v(r, N(this, i, r));
            e.moveToBookmark(t)
        }

        function p(e) {
            var t, n, r = e.createBookmark(1),
                i = e.createIterator();
            for (i.enforceRealBlocks = !0, i.enlargeBr = this._.enterMode != CKEDITOR.ENTER_BR; t = i.getNextParagraph();) this.checkElementRemovable(t) && (t.is("pre") ? ((n = this._.enterMode == CKEDITOR.ENTER_BR ? null : e.document.createElement(this._.enterMode == CKEDITOR.ENTER_P ? "p" : "div")) && t.copyAttributes(n), v(t, n)) : D.call(this, t));
            e.moveToBookmark(r)
        }

        function v(e, t) {
            var n = !t;
            n && (t = e.getDocument().createElement("div"), e.copyAttributes(t));
            var r, i = t && t.is("pre"),
                s = e.is("pre"),
                a = !i && s;
            i && !s ? t = function(e, t) {
                var n = e.getBogus();
                n && n.remove();
                var r = e.getHtml();
                if (r = (r = (r = (r = y(r, /(?:^[ \t\n\r]+)|(?:[ \t\n\r]+$)/g, "")).replace(/[ \t\r\n]*(<br[^>]*>)[ \t\r\n]*/gi, "$1")).replace(/([ \t\n\r]+|&nbsp;)/g, " ")).replace(/<br\b[^>]*>/gi, "\n"), CKEDITOR.env.ie) {
                    var i = e.getDocument().createElement("div");
                    i.append(t), t.$.outerHTML = "<pre>" + r + "</pre>", t.copyAttributes(i.getFirst()), t = i.getFirst().remove()
                } else t.setHtml(r);
                return t
            }(e, t) : a ? t = function(e, t) {
                var n;
                e.length > 1 && (n = new CKEDITOR.dom.documentFragment(t.getDocument()));
                for (var r = 0; r < e.length; r++) {
                    var i = e[r];
                    if (i = y(i = i.replace(/(\r\n|\r)/g, "\n"), /^[ \t]*\n/, ""), i = y(i, /\n$/, ""), i = (i = (i = y(i, /^[ \t]+|[ \t]+$/g, function(e, t) {
                            return 1 == e.length ? "&nbsp;" : t ? " " + CKEDITOR.tools.repeat("&nbsp;", e.length - 1) : CKEDITOR.tools.repeat("&nbsp;", e.length - 1) + " "
                        })).replace(/\n/g, "<br>")).replace(/[ \t]{2,}/g, function(e) {
                            return CKEDITOR.tools.repeat("&nbsp;", e.length - 1) + " "
                        }), n) {
                        var o = t.clone();
                        o.setHtml(i), n.append(o)
                    } else t.setHtml(i)
                }
                return n || t
            }(n ? [e.getHtml()] : (r = [], y(e.getOuterHtml(), /(\S\s*)\n(?:\s|(<span[^>]+data-cke-bookmark.*?\/span>))*\n(?!$)/gi, function(e, t, n) {
                return t + "</pre>" + n + "<pre>"
            }).replace(/<pre\b.*?>([\s\S]*?)<\/pre>/gi, function(e, t) {
                r.push(t)
            }), r), t) : e.moveChildren(t), t.replace(e), i ? function(e) {
                var t;
                if (!(t = e.getPrevious(o)) || t.type != CKEDITOR.NODE_ELEMENT || !t.is("pre")) return;
                var n = y(t.getHtml(), /\n$/, "") + "\n\n" + y(e.getHtml(), /^\n/, "");
                CKEDITOR.env.ie ? e.$.outerHTML = "<pre>" + n + "</pre>" : e.setHtml(n);
                t.remove()
            }(t) : n && _(t)
        }

        function y(e, t, n) {
            var r = "",
                i = "";
            return e = e.replace(/(^<span[^>]+data-cke-bookmark.*?\/span>)|(<span[^>]+data-cke-bookmark.*?\/span>$)/gi, function(e, t, n) {
                return t && (r = t), n && (i = n), ""
            }), r + e.replace(t, n) + i
        }

        function D(t, n) {
            var r = this._.definition,
                i = r.attributes,
                o = r.styles,
                s = L(this)[t.getName()],
                a = CKEDITOR.tools.isEmpty(i) && CKEDITOR.tools.isEmpty(o);
            for (var l in i)("class" != l && !this._.definition.fullMatch || t.getAttribute(l) == A(l, i[l])) && (n && "data-" == l.slice(0, 5) || (a = t.hasAttribute(l), t.removeAttribute(l)));
            for (var c in o) this._.definition.fullMatch && t.getStyle(c) != A(c, o[c], !0) || (a = a || !!t.getStyle(c), t.removeStyle(c));
            b(t, s, e[t.getName()]), a && (this._.definition.alwaysRemoveElement ? _(t, 1) : !CKEDITOR.dtd.$block[t.getName()] || this._.enterMode == CKEDITOR.ENTER_BR && !t.hasAttributes() ? _(t) : t.renameNode(this._.enterMode == CKEDITOR.ENTER_P ? "p" : "div"))
        }

        function K(e) {
            for (var t, n = L(this), r = e.getElementsByTag(this.element), i = r.count(); --i >= 0;)(t = r.getItem(i)).isReadOnly() || D.call(this, t, !0);
            for (var o in n)
                if (o != this.element)
                    for (i = (r = e.getElementsByTag(o)).count() - 1; i >= 0; i--)(t = r.getItem(i)).isReadOnly() || b(t, n[o])
        }

        function b(e, t, n) {
            var r = t && t.attributes;
            if (r)
                for (var i = 0; i < r.length; i++) {
                    var o, s = r[i][0];
                    if (o = e.getAttribute(s)) {
                        var a = r[i][1];
                        (null === a || a.test && a.test(o) || "string" == typeof a && o == a) && e.removeAttribute(s)
                    }
                }
            n || _(e)
        }

        function _(e, t) {
            if (!e.hasAttributes() || t)
                if (CKEDITOR.dtd.$block[e.getName()]) {
                    var n = e.getPrevious(o),
                        r = e.getNext(o);
                    !n || n.type != CKEDITOR.NODE_TEXT && n.isBlockBoundary({
                        br: 1
                    }) || e.append("br", 1), !r || r.type != CKEDITOR.NODE_TEXT && r.isBlockBoundary({
                        br: 1
                    }) || e.append("br"), e.remove(!0)
                } else {
                    var i = e.getFirst(),
                        s = e.getLast();
                    e.remove(!0), i && (i.type == CKEDITOR.NODE_ELEMENT && i.mergeSiblings(), s && !i.equals(s) && s.type == CKEDITOR.NODE_ELEMENT && s.mergeSiblings())
                }
        }

        function N(e, t, n) {
            var r, i = e.element;
            return "*" == i && (i = "span"), r = new CKEDITOR.dom.element(i, t), n && n.copyAttributes(r), r = S(r, e), t.getCustomData("doc_processing_style") && r.hasAttribute("id") ? r.removeAttribute("id") : t.setCustomData("doc_processing_style", 1), r
        }

        function S(e, t) {
            var n = t._.definition,
                r = n.attributes,
                i = CKEDITOR.style.getStyleText(n);
            if (r)
                for (var o in r) e.setAttribute(o, r[o]);
            return i && e.setAttribute("style", i), e.getDocument().removeCustomData("doc_processing_style"), e
        }

        function k(e, t) {
            for (var n in e) e[n] = e[n].replace(r, function(e, n) {
                return t[n]
            })
        }

        function L(e) {
            if (e._.overrides) return e._.overrides;
            var t = e._.overrides = {},
                n = e._.definition.overrides;
            if (n) {
                CKEDITOR.tools.isArray(n) || (n = [n]);
                for (var r = 0; r < n.length; r++) {
                    var i, o, s, a = n[r];
                    if ("string" == typeof a ? i = a.toLowerCase() : (i = a.element ? a.element.toLowerCase() : e.element, s = a.attributes), o = t[i] || (t[i] = {}), s) {
                        var l = o.attributes = o.attributes || [];
                        for (var c in s) l.push([c.toLowerCase(), s[c]])
                    }
                }
            }
            return t
        }

        function A(e, t, n) {
            var r = new CKEDITOR.dom.element("span");
            return r[n ? "setStyle" : "setAttribute"](e, t), r[n ? "getStyle" : "getAttribute"](e)
        }

        function B(e, t) {
            function n(e, t) {
                return "font-family" == t.toLowerCase() ? e.replace(/["']/g, "") : e
            }
            for (var r in "string" == typeof e && (e = CKEDITOR.tools.parseCssText(e)), "string" == typeof t && (t = CKEDITOR.tools.parseCssText(t, !0)), e) {
                if (!(r in t)) return !1;
                if (n(t[r], r) != n(e[r], r) && "inherit" != e[r] && "inherit" != t[r]) return !1
            }
            return !0
        }

        function P(e, t, n) {
            var r, i, o, s = e.getRanges(),
                a = t ? this.removeFromRange : this.applyToRange;
            if (e.isFake && e.isInTable())
                for (r = [], o = 0; o < s.length; o++) r.push(s[o].clone());
            for (var l = s.createIterator(); i = l.getNextRange();) a.call(this, i, n);
            e.selectRanges(r || s)
        }
    }(), CKEDITOR.styleCommand = function(e, t) {
        this.style = e, this.allowedContent = e, this.requiredContent = e, CKEDITOR.tools.extend(this, t, !0)
    }, CKEDITOR.styleCommand.prototype.exec = function(e) {
        e.focus(), this.state == CKEDITOR.TRISTATE_OFF ? e.applyStyle(this.style) : this.state == CKEDITOR.TRISTATE_ON && e.removeStyle(this.style)
    }, CKEDITOR.stylesSet = new CKEDITOR.resourceManager("", "stylesSet"), CKEDITOR.addStylesSet = CKEDITOR.tools.bind(CKEDITOR.stylesSet.add, CKEDITOR.stylesSet), CKEDITOR.loadStylesSet = function(e, t, n) {
        CKEDITOR.stylesSet.addExternal(e, t, ""), CKEDITOR.stylesSet.load(e, n)
    }, CKEDITOR.tools.extend(CKEDITOR.editor.prototype, {
        attachStyleStateChange: function(e, t) {
            var n = this._.styleStateChangeCallbacks;
            n || (n = this._.styleStateChangeCallbacks = [], this.on("selectionChange", function(e) {
                for (var t = 0; t < n.length; t++) {
                    var r = n[t],
                        i = r.style.checkActive(e.data.path, this) ? CKEDITOR.TRISTATE_ON : CKEDITOR.TRISTATE_OFF;
                    r.fn.call(this, i)
                }
            })), n.push({
                style: e,
                fn: t
            })
        },
        applyStyle: function(e) {
            e.apply(this)
        },
        removeStyle: function(e) {
            e.remove(this)
        },
        getStylesSet: function(e) {
            if (this._.stylesDefinitions) e(this._.stylesDefinitions);
            else {
                var t = this,
                    n = t.config.stylesCombo_stylesSet || t.config.stylesSet;
                if (!1 === n) return void e(null);
                if (n instanceof Array) return t._.stylesDefinitions = n, void e(n);
                n || (n = "default");
                var r = n.split(":"),
                    i = r[0],
                    o = r[1];
                CKEDITOR.stylesSet.addExternal(i, o ? r.slice(1).join(":") : CKEDITOR.getUrl("styles.js"), ""), CKEDITOR.stylesSet.load(i, function(n) {
                    t._.stylesDefinitions = n[i], e(t._.stylesDefinitions)
                })
            }
        }
    });