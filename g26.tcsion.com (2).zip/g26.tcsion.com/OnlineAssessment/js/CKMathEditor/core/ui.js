CKEDITOR.ui = function(t) {
    return t.ui ? t.ui : (this.items = {}, this.instances = {}, this.editor = t, this._ = {
        handlers: {}
    }, this)
}, CKEDITOR.ui.prototype = {
    add: function(t, e, n) {
        n.name = t.toLowerCase();
        var i = this.items[t] = {
            type: e,
            command: n.command || null,
            args: Array.prototype.slice.call(arguments, 2)
        };
        CKEDITOR.tools.extend(i, n)
    },
    get: function(t) {
        return this.instances[t]
    },
    create: function(t) {
        var e = this.items[t],
            n = e && this._.handlers[e.type],
            i = e && e.command && this.editor.getCommand(e.command),
            s = n && n.create.apply(this, e.args);
        return this.instances[t] = s, i && i.uiItems.push(s), s && !s.type && (s.type = e.type), s
    },
    addHandler: function(t, e) {
        this._.handlers[t] = e
    },
    space: function(t) {
        return CKEDITOR.document.getById(this.spaceId(t))
    },
    spaceId: function(t) {
        return this.editor.id + "_" + t
    }
}, CKEDITOR.event.implementOn(CKEDITOR.ui);