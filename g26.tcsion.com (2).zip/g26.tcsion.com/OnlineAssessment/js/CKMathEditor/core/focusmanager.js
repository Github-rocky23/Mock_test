! function() {
    CKEDITOR.focusManager = function(t) {
        return t.focusManager ? t.focusManager : (this.hasFocus = !1, this.currentActive = null, this._ = {
            editor: t
        }, this)
    };
    CKEDITOR.focusManager._ = {
        blurDelay: 200
    }, CKEDITOR.focusManager.prototype = {
        focus: function(t) {
            if (this._.timer && clearTimeout(this._.timer), t && (this.currentActive = t), !this.hasFocus && !this._.locked) {
                var e = CKEDITOR.currentInstance;
                e && e.focusManager.blur(1), this.hasFocus = !0;
                var s = this._.editor.container;
                s && s.addClass("cke_focus"), this._.editor.fire("focus")
            }
        },
        lock: function() {
            this._.locked = 1
        },
        unlock: function() {
            delete this._.locked
        },
        blur: function(t) {
            if (!this._.locked) {
                this._.timer && clearTimeout(this._.timer);
                var e = CKEDITOR.focusManager._.blurDelay;
                t || !e ? s.call(this) : this._.timer = CKEDITOR.tools.setTimeout(function() {
                    delete this._.timer, s.call(this)
                }, e, this)
            }

            function s() {
                if (this.hasFocus) {
                    this.hasFocus = !1;
                    var t = this._.editor.container;
                    t && t.removeClass("cke_focus"), this._.editor.fire("blur")
                }
            }
        },
        add: function(t, e) {
            var s = t.getCustomData("focusmanager");
            if (!s || s != this) {
                s && s.remove(t);
                var o = "focus",
                    i = "blur";
                e && (CKEDITOR.env.ie ? (o = "focusin", i = "focusout") : CKEDITOR.event.useCapture = 1);
                var u = {
                    blur: function() {
                        t.equals(this.currentActive) && this.blur()
                    },
                    focus: function() {
                        this.focus(t)
                    }
                };
                t.on(o, u.focus, this), t.on(i, u.blur, this), e && (CKEDITOR.event.useCapture = 0), t.setCustomData("focusmanager", this), t.setCustomData("focusmanager_handlers", u)
            }
        },
        remove: function(t) {
            t.removeCustomData("focusmanager");
            var e = t.removeCustomData("focusmanager_handlers");
            t.removeListener("blur", e.blur), t.removeListener("focus", e.focus)
        }
    }
}();