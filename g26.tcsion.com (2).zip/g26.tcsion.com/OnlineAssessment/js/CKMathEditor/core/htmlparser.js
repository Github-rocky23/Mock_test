CKEDITOR.htmlParser = function() {
        this._ = {
            htmlPartsRegex: /<(?:(?:\/([^>]+)>)|(?:!--([\S|\s]*?)-->)|(?:([^\/\s>]+)((?:\s+[\w\-:.]+(?:\s*=\s*?(?:(?:"[^"]*")|(?:'[^']*')|[^\s"'\/>]+))?)*)[\S\s]*?(\/?)>))/g
        }
    },
    function() {
        var e = /([\w\-:.]+)(?:(?:\s*=\s*(?:(?:"([^"]*)")|(?:'([^']*)')|([^\s>]+)))|(?=\s|$))/g,
            t = {
                checked: 1,
                compact: 1,
                declare: 1,
                defer: 1,
                disabled: 1,
                ismap: 1,
                multiple: 1,
                nohref: 1,
                noresize: 1,
                noshade: 1,
                nowrap: 1,
                readonly: 1,
                selected: 1
            };
        CKEDITOR.htmlParser.prototype = {
            onTagOpen: function() {},
            onTagClose: function() {},
            onText: function() {},
            onCDATA: function() {},
            onComment: function() {},
            parse: function(s) {
                for (var n, o, i, a = 0; n = this._.htmlPartsRegex.exec(s);) {
                    var r = n.index;
                    if (r > a) {
                        var l = s.substring(a, r);
                        i ? i.push(l) : this.onText(l)
                    }
                    if (a = this._.htmlPartsRegex.lastIndex, !(o = n[1]) || (o = o.toLowerCase(), i && CKEDITOR.dtd.$cdata[o] && (this.onCDATA(i.join("")), i = null), i))
                        if (i) i.push(n[0]);
                        else if (o = n[3]) {
                        if (o = o.toLowerCase(), /="/.test(o)) continue;
                        var h, c = {},
                            f = n[4],
                            d = !!n[5];
                        if (f)
                            for (; h = e.exec(f);) {
                                var u = h[1].toLowerCase(),
                                    C = h[2] || h[3] || h[4] || "";
                                c[u] = !C && t[u] ? u : CKEDITOR.tools.htmlDecodeAttr(C)
                            }
                        this.onTagOpen(o, c, d), !i && CKEDITOR.dtd.$cdata[o] && (i = [])
                    } else(o = n[2]) && this.onComment(o);
                    else this.onTagClose(o)
                }
                s.length > a && this.onText(s.substring(a, s.length))
            }
        }
    }();