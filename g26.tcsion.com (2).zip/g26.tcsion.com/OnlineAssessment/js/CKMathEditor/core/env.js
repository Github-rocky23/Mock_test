CKEDITOR.env || (CKEDITOR.env = function() {
    var e = navigator.userAgent.toLowerCase(),
        i = e.match(/edge[ \/](\d+.?\d*)/),
        o = e.indexOf("trident/") > -1,
        s = !(!i && !o),
        t = {
            ie: s,
            edge: !!i,
            webkit: !s && e.indexOf(" applewebkit/") > -1,
            air: e.indexOf(" adobeair/") > -1,
            mac: e.indexOf("macintosh") > -1,
            quirks: "BackCompat" == document.compatMode && (!document.documentMode || document.documentMode < 10),
            mobile: e.indexOf("mobile") > -1,
            iOS: /(ipad|iphone|ipod)/.test(e),
            isCustomDomain: function() {
                if (!this.ie) return !1;
                var e = document.domain,
                    i = window.location.hostname;
                return e != i && e != "[" + i + "]"
            },
            secure: "https:" == location.protocol
        };
    t.gecko = "Gecko" == navigator.product && !t.webkit && !t.ie, t.webkit && (e.indexOf("chrome") > -1 ? t.chrome = !0 : t.safari = !0);
    var a = 0;
    if (t.ie && (a = i ? parseFloat(i[1]) : t.quirks || !document.documentMode ? parseFloat(e.match(/msie (\d+)/)[1]) : document.documentMode, t.ie9Compat = 9 == a, t.ie8Compat = 8 == a, t.ie7Compat = 7 == a, t.ie6Compat = a < 7 || t.quirks), t.gecko) {
        var r = e.match(/rv:([\d\.]+)/);
        r && (a = 1e4 * (r = r[1].split("."))[0] + 100 * (r[1] || 0) + 1 * (r[2] || 0))
    }
    return t.air && (a = parseFloat(e.match(/ adobeair\/(\d+)/)[1])), t.webkit && (a = parseFloat(e.match(/ applewebkit\/(\d+)/)[1])), t.version = a, t.isCompatible = !(t.ie && a < 7 || t.gecko && a < 4e4 || t.webkit && a < 534), t.hidpi = window.devicePixelRatio >= 2, t.needsBrFiller = t.gecko || t.webkit || t.ie && a > 10, t.needsNbspFiller = t.ie && a < 11, t.cssClass = "cke_browser_" + (t.ie ? "ie" : t.gecko ? "gecko" : t.webkit ? "webkit" : "unknown"), t.quirks && (t.cssClass += " cke_browser_quirks"), t.ie && (t.cssClass += " cke_browser_ie" + (t.quirks ? "6 cke_browser_iequirks" : t.version)), t.air && (t.cssClass += " cke_browser_air"), t.iOS && (t.cssClass += " cke_browser_ios"), t.hidpi && (t.cssClass += " cke_hidpi"), t
}());