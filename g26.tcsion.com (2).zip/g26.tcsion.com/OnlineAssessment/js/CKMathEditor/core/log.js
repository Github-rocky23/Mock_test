"use strict";
CKEDITOR.VERBOSITY_WARN = 1, CKEDITOR.VERBOSITY_ERROR = 2, CKEDITOR.verbosity = CKEDITOR.VERBOSITY_WARN | CKEDITOR.VERBOSITY_ERROR, CKEDITOR.warn = function(o, r) {
    CKEDITOR.verbosity & CKEDITOR.VERBOSITY_WARN && CKEDITOR.fire("log", {
        type: "warn",
        errorCode: o,
        additionalData: r
    })
}, CKEDITOR.error = function(o, r) {
    CKEDITOR.verbosity & CKEDITOR.VERBOSITY_ERROR && CKEDITOR.fire("log", {
        type: "error",
        errorCode: o,
        additionalData: r
    })
}, CKEDITOR.on("log", function(o) {
    if (window.console && window.console.log) {
        var r = console[o.data.type] ? o.data.type : "log",
            R = o.data.errorCode,
            e = o.data.additionalData;
        e ? console[r]("[CKEDITOR] Error code: " + R + ".", e) : console[r]("[CKEDITOR] Error code: " + R + "."), console[r]("[CKEDITOR] For more information about this error go to https://ckeditor.com/docs/ckeditor4/latest/guide/dev_errors.html#" + R)
    }
}, null, null, 999);