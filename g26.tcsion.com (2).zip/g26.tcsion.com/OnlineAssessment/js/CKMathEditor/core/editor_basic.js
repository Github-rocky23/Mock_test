CKEDITOR.editor || (CKEDITOR.editor = function() {
    CKEDITOR._.pending.push([this, arguments]), CKEDITOR.event.call(this)
}, CKEDITOR.editor.prototype.fire = function(e, t) {
    return e in {
        instanceReady: 1,
        loaded: 1
    } && (this[e] = !0), CKEDITOR.event.prototype.fire.call(this, e, t, this)
}, CKEDITOR.editor.prototype.fireOnce = function(e, t) {
    return e in {
        instanceReady: 1,
        loaded: 1
    } && (this[e] = !0), CKEDITOR.event.prototype.fireOnce.call(this, e, t, this)
}, CKEDITOR.event.implementOn(CKEDITOR.editor.prototype));