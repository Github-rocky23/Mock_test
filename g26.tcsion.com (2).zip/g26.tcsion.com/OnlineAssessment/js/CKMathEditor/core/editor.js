! function() {
    function e(e, i, s) {
        if (CKEDITOR.event.call(this), e = e && CKEDITOR.tools.clone(e), void 0 !== i) {
            if (!(i instanceof CKEDITOR.dom.element)) throw new Error("Expect element of type CKEDITOR.dom.element.");
            if (!s) throw new Error("One of the element modes must be specified.");
            if (CKEDITOR.env.ie && CKEDITOR.env.quirks && s == CKEDITOR.ELEMENT_MODE_INLINE) throw new Error("Inline element mode is not supported on IE quirks.");
            if (! function(e, t) {
                    if (t == CKEDITOR.ELEMENT_MODE_INLINE) return e.is(CKEDITOR.dtd.$editable) || e.is("textarea");
                    if (t == CKEDITOR.ELEMENT_MODE_REPLACE) return !e.is(CKEDITOR.dtd.$nonBodyContent);
                    return 1
                }(i, s)) throw new Error('The specified element mode is not supported on element: "' + i.getName() + '".');
            this.element = i, this.elementMode = s, this.name = this.elementMode != CKEDITOR.ELEMENT_MODE_APPENDTO && (i.getId() || i.getNameAtt())
        } else this.elementMode = CKEDITOR.ELEMENT_MODE_NONE;
        this._ = {}, this.commands = {}, this.templates = {}, this.name = this.name || function() {
            do {
                var e = "editor" + ++t
            } while (CKEDITOR.instances[e]);
            return e
        }(), this.id = CKEDITOR.tools.getNextId(), this.status = "unloaded", this.config = CKEDITOR.tools.prototypedCopy(CKEDITOR.config), this.ui = new CKEDITOR.ui(this), this.focusManager = new CKEDITOR.focusManager(this), this.keystrokeHandler = new CKEDITOR.keystrokeHandler(this), this.on("readOnly", n), this.on("selectionChange", function(e) {
            o(this, e.data.path)
        }), this.on("activeFilterChange", function() {
            o(this, this.elementPath(), !0)
        }), this.on("mode", n), this.on("instanceReady", function() {
            if (this.config.startupFocus) {
                if ("end" === this.config.startupFocus) {
                    var e = this.createRange();
                    e.selectNodeContents(this.editable()), e.shrink(CKEDITOR.SHRINK_ELEMENT, !0), e.collapse(), this.getSelection().selectRanges([e])
                }
                this.focus()
            }
        }), CKEDITOR.fire("instanceCreated", null, this), CKEDITOR.add(this), CKEDITOR.tools.setTimeout(function() {
            "destroyed" !== this.status ? function(e, t) {
                e.on("customConfigLoaded", function() {
                    if (t) {
                        if (t.on)
                            for (var n in t.on) e.on(n, t.on[n]);
                        CKEDITOR.tools.extend(e.config, t, !0), delete e.config.on
                    }! function(e) {
                        var t = e.config;
                        e.readOnly = !!t.readOnly || (e.elementMode == CKEDITOR.ELEMENT_MODE_INLINE ? e.element.is("textarea") ? e.element.hasAttribute("disabled") || e.element.hasAttribute("readonly") : e.element.isReadOnly() : e.elementMode == CKEDITOR.ELEMENT_MODE_REPLACE && (e.element.hasAttribute("disabled") || e.element.hasAttribute("readonly"))), e.blockless = e.elementMode == CKEDITOR.ELEMENT_MODE_INLINE && !(e.element.is("textarea") || CKEDITOR.dtd[e.element.getName()].p), e.tabIndex = t.tabIndex || e.element && e.element.getAttribute("tabindex") || 0, e.activeEnterMode = e.enterMode = a(e, t.enterMode), e.activeShiftEnterMode = e.shiftEnterMode = a(e, t.shiftEnterMode), t.skin && (CKEDITOR.skinName = t.skin), e.fireOnce("configLoaded"),
                            function(e) {
                                e.dataProcessor = new CKEDITOR.htmlDataProcessor(e), e.filter = e.activeFilter = new CKEDITOR.filter(e),
                                    function(e) {
                                        CKEDITOR.skin.loadPart("editor", function() {
                                            ! function(e) {
                                                CKEDITOR.lang.load(e.config.language, e.config.defaultLanguage, function(t, n) {
                                                    var i = e.config.title;
                                                    e.langCode = t, e.lang = CKEDITOR.tools.prototypedCopy(n), e.title = "string" == typeof i || !1 === i ? i : [e.lang.editor, e.name].join(", "), e.config.contentsLangDirection || (e.config.contentsLangDirection = e.elementMode == CKEDITOR.ELEMENT_MODE_INLINE ? e.element.getDirection(1) : e.lang.dir), e.fire("langLoaded"),
                                                        function(e) {
                                                            e.getStylesSet(function(t) {
                                                                e.once("loaded", function() {
                                                                        e.fire("stylesSet", {
                                                                            styles: t
                                                                        })
                                                                    }, null, null, 1),
                                                                    function(e) {
                                                                        var t = e.config,
                                                                            n = a(t.plugins),
                                                                            i = a(t.extraPlugins),
                                                                            o = a(t.removePlugins);
                                                                        if (i) {
                                                                            var r = new RegExp("(?:^|,)(?:" + i.replace(/,/g, "|") + ")(?=,|$)", "g");
                                                                            n = n.replace(r, ""), n += "," + i
                                                                        }
                                                                        if (o) {
                                                                            var s = new RegExp("(?:^|,)(?:" + o.replace(/,/g, "|") + ")(?=,|$)", "g");
                                                                            n = n.replace(s, "")
                                                                        }

                                                                        function a(e) {
                                                                            return e ? (CKEDITOR.tools.isArray(e) && (e = e.join(",")), e.replace(/\s/g, "")) : ""
                                                                        }
                                                                        CKEDITOR.env.air && (n += ",adobeair"), CKEDITOR.plugins.load(n.split(","), function(n) {
                                                                            var i = [],
                                                                                o = [],
                                                                                r = [];
                                                                            for (var a in e.plugins = CKEDITOR.tools.extend({}, e.plugins, n), n) {
                                                                                var l, d, c = n[a],
                                                                                    f = c.lang,
                                                                                    E = null,
                                                                                    u = c.requires;
                                                                                if (CKEDITOR.tools.isArray(u) && (u = u.join(",")), u && (l = u.match(s)))
                                                                                    for (; d = l.pop();) CKEDITOR.error("editor-plugin-required", {
                                                                                        plugin: d.replace(",", ""),
                                                                                        requiredBy: a
                                                                                    });
                                                                                if (f && !e.lang[a]) {
                                                                                    if (f.split && (f = f.split(",")), CKEDITOR.tools.indexOf(f, e.langCode) >= 0) E = e.langCode;
                                                                                    else {
                                                                                        var h = e.langCode.replace(/-.*/, "");
                                                                                        E = h != e.langCode && CKEDITOR.tools.indexOf(f, h) >= 0 ? h : CKEDITOR.tools.indexOf(f, "en") >= 0 ? "en" : f[0]
                                                                                    }
                                                                                    c.langEntries && c.langEntries[E] ? (e.lang[a] = c.langEntries[E], E = null) : r.push(CKEDITOR.getUrl(c.path + "lang/" + E + ".js"))
                                                                                }
                                                                                o.push(E), i.push(c)
                                                                            }
                                                                            CKEDITOR.scriptLoader.load(r, function() {
                                                                                for (var n = ["beforeInit", "init", "afterInit"], r = 0; r < n.length; r++)
                                                                                    for (var s = 0; s < i.length; s++) {
                                                                                        var a = i[s];
                                                                                        0 === r && o[s] && a.lang && a.langEntries && (e.lang[a.name] = a.langEntries[o[s]]), a[n[r]] && a[n[r]](e)
                                                                                    }
                                                                                for (e.fireOnce("pluginsLoaded"), t.keystrokes && e.setKeystroke(e.config.keystrokes), s = 0; s < e.config.blockedKeystrokes.length; s++) e.keystrokeHandler.blockedKeystrokes[e.config.blockedKeystrokes[s]] = 1;
                                                                                e.status = "loaded", e.fireOnce("loaded"), CKEDITOR.fire("instanceLoaded", null, e)
                                                                            })
                                                                        })
                                                                    }(e)
                                                            })
                                                        }(e)
                                                })
                                            }(e)
                                        })
                                    }(e)
                            }(e)
                    }(e)
                }), t && null != t.customConfig && (e.config.customConfig = t.customConfig);
                (function e(t) {
                    var n = t.config.customConfig;
                    if (!n) return !1;
                    n = CKEDITOR.getUrl(n);
                    var i = r[n] || (r[n] = {});
                    i.fn ? (i.fn.call(t, t.config), CKEDITOR.getUrl(t.config.customConfig) != n && e(t) || t.fireOnce("customConfigLoaded")) : CKEDITOR.scriptLoader.queue(n, function() {
                        CKEDITOR.editorConfig ? i.fn = CKEDITOR.editorConfig : i.fn = function() {}, e(t)
                    });
                    return !0
                })(e) || e.fireOnce("customConfigLoaded")
            }(this, e) : CKEDITOR.warn("editor-incorrect-destroy")
        }, 0, this)
    }
    e.prototype = CKEDITOR.editor.prototype, CKEDITOR.editor = e;
    var t = 0;

    function n() {
        var e, t = this.commands;
        for (e in t) i(this, t[e])
    }

    function i(e, t) {
        t[t.startDisabled ? "disable" : e.readOnly && !t.readOnly ? "disable" : t.modes[e.mode] ? "enable" : "disable"]()
    }

    function o(e, t, n) {
        if (t) {
            var i, o, r = e.commands;
            for (o in r) i = r[o], (n || i.contextSensitive) && i.refresh(e, t)
        }
    }
    var r = {};

    function s() {
        var e = this.element;
        if (e && this.elementMode != CKEDITOR.ELEMENT_MODE_APPENDTO) {
            var t = this.getData();
            return this.config.htmlEncodeOutput && (t = CKEDITOR.tools.htmlEncode(t)), e.is("textarea") ? e.setValue(t) : e.setHtml(t), !0
        }
        return !1
    }

    function a(e, t) {
        return e.blockless ? CKEDITOR.ENTER_BR : t
    }
    CKEDITOR.tools.extend(CKEDITOR.editor.prototype, {
        plugins: {
            detectConflict: function(e, t) {
                for (var n = 0; n < t.length; n++) {
                    var i = t[n];
                    if (this[i]) return CKEDITOR.warn("editor-plugin-conflict", {
                        plugin: e,
                        replacedWith: i
                    }), !0
                }
                return !1
            }
        },
        addCommand: function(e, t) {
            t.name = e.toLowerCase();
            var n = t instanceof CKEDITOR.command ? t : new CKEDITOR.command(this, t);
            return this.mode && i(this, n), this.commands[e] = n
        },
        _attachToForm: function() {
            var e, t = this,
                n = t.element,
                i = new CKEDITOR.dom.element(n.$.form);

            function o(e) {
                t.updateElement(), t._.required && !n.getValue() && !1 === t.fire("required") && e.data.preventDefault()
            }
            n.is("textarea") && i && (i.on("submit", o), (e = i.$.submit) && e.call && e.apply && (i.$.submit = CKEDITOR.tools.override(i.$.submit, function(e) {
                return function() {
                    o(), e.apply ? e.apply(this) : e()
                }
            })), t.on("destroy", function() {
                i.removeListener("submit", o)
            }))
        },
        destroy: function(e) {
            var t = CKEDITOR.filter.instances,
                n = this;
            this.fire("beforeDestroy"), !e && s.call(this), this.editable(null), this.filter && delete this.filter, CKEDITOR.tools.array.forEach(CKEDITOR.tools.objectKeys(t), function(e) {
                var i = t[e];
                n === i.editor && i.destroy()
            }), delete this.activeFilter, this.status = "destroyed", this.fire("destroy"), this.removeAllListeners(), CKEDITOR.remove(this), CKEDITOR.fire("instanceDestroyed", null, this)
        },
        elementPath: function(e) {
            if (!e) {
                var t = this.getSelection();
                if (!t) return null;
                e = t.getStartElement()
            }
            return e ? new CKEDITOR.dom.elementPath(e, this.editable()) : null
        },
        createRange: function() {
            var e = this.editable();
            return e ? new CKEDITOR.dom.range(e) : null
        },
        execCommand: function(e, t) {
            var n = this.getCommand(e),
                i = {
                    name: e,
                    commandData: t || {},
                    command: n
                };
            return !(!n || n.state == CKEDITOR.TRISTATE_DISABLED || !1 === this.fire("beforeCommandExec", i) || (i.returnValue = n.exec(i.commandData), n.async || !1 === this.fire("afterCommandExec", i))) && i.returnValue
        },
        getCommand: function(e) {
            return this.commands[e]
        },
        getData: function(e) {
            !e && this.fire("beforeGetData");
            var t = this._.data;
            if ("string" != typeof t) {
                var n = this.element;
                t = n && this.elementMode == CKEDITOR.ELEMENT_MODE_REPLACE ? n.is("textarea") ? n.getValue() : n.getHtml() : ""
            }
            return t = {
                dataValue: t
            }, !e && this.fire("getData", t), t.dataValue
        },
        getSnapshot: function() {
            var e = this.fire("getSnapshot");
            if ("string" != typeof e) {
                var t = this.element;
                e = t && this.elementMode == CKEDITOR.ELEMENT_MODE_REPLACE ? t.is("textarea") ? t.getValue() : t.getHtml() : ""
            }
            return e
        },
        loadSnapshot: function(e) {
            this.fire("loadSnapshot", e)
        },
        setData: function(e, t, n) {
            var i, o = !0,
                r = t;
            t && "object" == typeof t && (n = t.internal, r = t.callback, o = !t.noSnapshot), !n && o && this.fire("saveSnapshot"), !r && n || this.once("dataReady", function(e) {
                !n && o && this.fire("saveSnapshot"), r && r.call(e.editor)
            }), i = {
                dataValue: e
            }, !n && this.fire("setData", i), this._.data = i.dataValue, !n && this.fire("afterSetData", i)
        },
        setReadOnly: function(e) {
            e = null == e || e, this.readOnly != e && (this.readOnly = e, this.keystrokeHandler.blockedKeystrokes[8] = +e, this.editable().setReadOnly(e), this.fire("readOnly"))
        },
        insertHtml: function(e, t, n) {
            this.fire("insertHtml", {
                dataValue: e,
                mode: t,
                range: n
            })
        },
        insertText: function(e) {
            this.fire("insertText", e)
        },
        insertElement: function(e) {
            this.fire("insertElement", e)
        },
        getSelectedHtml: function(e) {
            var t = this.editable(),
                n = this.getSelection(),
                i = n && n.getRanges();
            if (!t || !i || 0 === i.length) return null;
            var o = function(e, t) {
                var n, i, o, r = new CKEDITOR.dom.documentFragment;

                function s(e) {
                    var t = e.startContainer,
                        n = e.endContainer;
                    return !(!t.is || !(t.is("tr") || t.is("td") && t.equals(n) && e.endOffset === t.getChildCount()))
                }

                function a(e) {
                    var t = e.startContainer;
                    return t.is("tr") ? e.cloneContents() : t.clone(!0)
                }
                for (var l = 0; l < e.length; l++) {
                    var d = e[l],
                        c = d.startContainer.getAscendant("tr", !0);
                    s(d) ? (n || ((n = c.getAscendant("table").clone()).append(c.getAscendant({
                        thead: 1,
                        tbody: 1,
                        tfoot: 1
                    }).clone()), r.append(n), n = n.findOne("thead, tbody, tfoot")), i && i.equals(c) || (i = c, o = c.clone(), n.append(o)), o.append(a(d))) : r.append(d.cloneContents())
                }
                return n ? r : t.getHtmlFromRange(e[0])
            }(i, t);
            return e ? o.getHtml() : o
        },
        extractSelectedHtml: function(e, t) {
            var n, i = this.editable(),
                o = this.getSelection().getRanges(),
                r = new CKEDITOR.dom.documentFragment;
            if (!i || 0 === o.length) return null;
            for (n = 0; n < o.length; n++) r.append(i.extractHtmlFromRange(o[n], t));
            return t || this.getSelection().selectRanges([o[0]]), e ? r.getHtml() : r
        },
        focus: function() {
            this.fire("beforeFocus")
        },
        checkDirty: function() {
            return "ready" == this.status && this._.previousValue !== this.getSnapshot()
        },
        resetDirty: function() {
            this._.previousValue = this.getSnapshot()
        },
        updateElement: function() {
            return s.call(this)
        },
        setKeystroke: function() {
            for (var e, t, n = this.keystrokeHandler.keystrokes, i = CKEDITOR.tools.isArray(arguments[0]) ? arguments[0] : [
                    [].slice.call(arguments, 0)
                ], o = i.length; o--;) e = i[o], t = 0, CKEDITOR.tools.isArray(e) && (t = e[1], e = e[0]), t ? n[e] = t : delete n[e]
        },
        getCommandKeystroke: function(e, t) {
            var n = "string" == typeof e ? this.getCommand(e) : e,
                i = [];
            if (n) {
                var o = CKEDITOR.tools.object.findKey(this.commands, n),
                    r = this.keystrokeHandler.keystrokes;
                if (n.fakeKeystroke) i.push(n.fakeKeystroke);
                else
                    for (var s in r) r[s] === o && i.push(s)
            }
            return t ? i : i[0] || null
        },
        addFeature: function(e) {
            return this.filter.addFeature(e)
        },
        setActiveFilter: function(e) {
            e || (e = this.filter), this.activeFilter !== e && (this.activeFilter = e, this.fire("activeFilterChange"), e === this.filter ? this.setActiveEnterMode(null, null) : this.setActiveEnterMode(e.getAllowedEnterMode(this.enterMode), e.getAllowedEnterMode(this.shiftEnterMode, !0)))
        },
        setActiveEnterMode: function(e, t) {
            e = e ? a(this, e) : this.enterMode, t = t ? a(this, t) : this.shiftEnterMode, this.activeEnterMode == e && this.activeShiftEnterMode == t || (this.activeEnterMode = e, this.activeShiftEnterMode = t, this.fire("activeEnterModeChange"))
        },
        showNotification: function(e) {
            alert(e)
        }
    })
}(), CKEDITOR.ELEMENT_MODE_NONE = 0, CKEDITOR.ELEMENT_MODE_REPLACE = 1, CKEDITOR.ELEMENT_MODE_APPENDTO = 2, CKEDITOR.ELEMENT_MODE_INLINE = 3;