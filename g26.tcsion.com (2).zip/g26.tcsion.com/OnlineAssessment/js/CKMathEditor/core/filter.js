! function() {
    "use strict";
    var e, t, s = CKEDITOR.dtd,
        r = 1,
        n = CKEDITOR.tools.copy,
        l = CKEDITOR.tools.trim,
        i = "cke-test",
        a = ["", "p", "br", "div"];

    function o(e, t, s, r, l) {
        var i, a, o = [];
        for (i in t) a = "boolean" == typeof(a = t[i]) ? {} : "function" == typeof a ? {
            match: a
        } : n(a), "$" != i.charAt(0) && (a.elements = i), s && (a.featureName = s.toLowerCase()), A(a), r.push(a), o.push(a);
        ! function(e, t) {
            var s, r, l, i, a, o = e.elements,
                u = e.generic;
            for (s = 0, r = t.length; s < r; ++s)
                if (l = n(t[s]), a = !0 === l.classes || !0 === l.styles || !0 === l.attributes, T(l), !0 === l.elements || null === l.elements) u[a ? "unshift" : "push"](l);
                else {
                    var c = l.elements;
                    for (i in delete l.elements, c) o[i] ? o[i][a ? "unshift" : "push"](l) : o[i] = [l]
                }
        }(l, o)
    }

    function u(e, t, s, r) {
        e.match && !e.match(t) || (r || function(e, t) {
            if (e.nothingRequired) return !0;
            var s, r, n, l;
            if (n = e.requiredClasses)
                for (l = t.classes, s = 0; s < n.length; ++s)
                    if ("string" == typeof(r = n[s])) {
                        if (-1 == CKEDITOR.tools.indexOf(l, r)) return !1
                    } else if (!CKEDITOR.tools.checkIfAnyArrayItemMatches(l, r)) return !1;
            return m(t.styles, e.requiredStyles) && m(t.attributes, e.requiredAttributes)
        }(e, t)) && (e.propertiesOnly || (s.valid = !0), s.allAttributes || (s.allAttributes = c(e.attributes, t.attributes, s.validAttributes)), s.allStyles || (s.allStyles = c(e.styles, t.styles, s.validStyles)), s.allClasses || (s.allClasses = function(e, t, s) {
            if (!e) return !1;
            if (!0 === e) return !0;
            for (var r, n = 0, l = t.length; n < l; ++n) r = t[n], s[r] || (s[r] = e(r));
            return !1
        }(e.classes, t.classes, s.validClasses)))
    }

    function c(e, t, s) {
        if (!e) return !1;
        if (!0 === e) return !0;
        for (var r in t) s[r] || (s[r] = e(r));
        return !1
    }

    function f(e, t, s) {
        if (!e.match || e.match(t)) {
            if (e.noProperties) return !1;
            s.hadInvalidAttribute = h(e.attributes, t.attributes) || s.hadInvalidAttribute, s.hadInvalidStyle = h(e.styles, t.styles) || s.hadInvalidStyle, s.hadInvalidClass = function(e, t) {
                if (!e) return !1;
                for (var s = !1, r = !0 === e, n = t.length; n--;)(r || e(t[n])) && (t.splice(n, 1), s = !0);
                return s
            }(e.classes, t.classes) || s.hadInvalidClass
        }
    }

    function h(e, t) {
        if (!e) return !1;
        var s = !1,
            r = !0 === e;
        for (var n in t)(r || e(n)) && (delete t[n], s = !0);
        return s
    }

    function d(e, t, s) {
        return !e.disabled && (!(e.customConfig && !s) && (!!t && (e._.cachedChecks = {}, !0)))
    }

    function p(e, t) {
        if (!e) return !1;
        if (!0 === e) return e;
        if ("string" == typeof e) return "*" == (e = l(e)) || CKEDITOR.tools.convertArrayToObject(e.split(t));
        if (CKEDITOR.tools.isArray(e)) return !!e.length && CKEDITOR.tools.convertArrayToObject(e);
        var s = {},
            r = 0;
        for (var n in e) s[n] = e[n], r++;
        return !!r && s
    }

    function y(e, t) {
        var s, r = [],
            n = !0;
        for (s in e ? n = !1 : e = {}, t) "!" == s.charAt(0) && (s = s.slice(1), r.push(s), e[s] = !0, n = !1);
        for (; s = r.pop();) t[s] = t["!" + s], delete t["!" + s];
        return !n && e
    }

    function m(e, t) {
        if (!t) return !0;
        for (var s, r = 0; r < t.length; ++r)
            if ("string" == typeof(s = t[r])) {
                if (!(s in e)) return !1
            } else if (!CKEDITOR.tools.checkIfAnyObjectPropertyMatches(e, s)) return !1;
        return !0
    }

    function b(e) {
        if (!e) return {};
        for (var t = e.split(/\s*,\s*/).sort(), s = {}; t.length;) s[t.shift()] = i;
        return s
    }

    function C(e) {
        var t = [];
        for (var s in e) s.indexOf("*") > -1 ? t.push(new RegExp("^" + s.replace(/\*/g, ".*") + "$")) : t.push(s);
        return t
    }
    CKEDITOR.FILTER_SKIP_TREE = 2, CKEDITOR.filter = function(e, t) {
        this.allowedContent = [], this.disallowedContent = [], this.elementCallbacks = null, this.disabled = !1, this.editor = null, this.id = CKEDITOR.tools.getNextNumber(), this._ = {
            allowedRules: {
                elements: {},
                generic: []
            },
            disallowedRules: {
                elements: {},
                generic: []
            },
            transformations: {},
            cachedTests: {},
            cachedChecks: {}
        }, CKEDITOR.filter.instances[this.id] = this;
        var s = this.editor = e instanceof CKEDITOR.editor ? e : null;
        if (s && !t) {
            this.customConfig = !0;
            var r = s.config.allowedContent;
            if (!0 === r) return void(this.disabled = !0);
            r || (this.customConfig = !1), this.allow(r, "config", 1), this.allow(s.config.extraAllowedContent, "extra", 1), this.allow(a[s.enterMode] + " " + a[s.shiftEnterMode], "default", 1), this.disallow(s.config.disallowedContent)
        } else this.customConfig = !1, this.allow(t || e, "default", 1)
    }, CKEDITOR.filter.instances = {}, CKEDITOR.filter.prototype = {
        allow: function(e, t, s) {
            if (!d(this, e, s)) return !1;
            var r, l;
            if ("string" == typeof e) e = O(e);
            else if (e instanceof CKEDITOR.style) {
                if (e.toAllowedContentRules) return this.allow(e.toAllowedContentRules(this.editor), t, s);
                e = function(e) {
                    var t, s = e.getDefinition(),
                        r = {},
                        l = s.attributes;
                    r[s.element] = t = {
                        styles: s.styles,
                        requiredStyles: s.styles && CKEDITOR.tools.objectKeys(s.styles)
                    }, l && (l = n(l), t.classes = l.class ? l.class.split(/\s+/) : null, t.requiredClasses = t.classes, delete l.class, t.attributes = l, t.requiredAttributes = l && CKEDITOR.tools.objectKeys(l));
                    return r
                }(e)
            } else if (CKEDITOR.tools.isArray(e)) {
                for (r = 0; r < e.length; ++r) l = this.allow(e[r], t, s);
                return l
            }
            return o(this, e, t, this.allowedContent, this._.allowedRules), !0
        },
        applyTo: function(e, t, n, l) {
            if (this.disabled) return !1;
            var i, o = this,
                u = [],
                c = this.editor && this.editor.config.protectedSource,
                f = !1,
                h = {
                    doFilter: !n,
                    doTransform: !0,
                    doCallbacks: !0,
                    toHtml: t
                };
            e.forEach(function(e) {
                if (e.type == CKEDITOR.NODE_ELEMENT) {
                    if ("off" == e.attributes["data-cke-filter"]) return !1;
                    if (t && "span" == e.name && ~CKEDITOR.tools.objectKeys(e.attributes).join("|").indexOf("data-cke-")) return;
                    if ((i = _(o, e, u, h)) & r) f = !0;
                    else if (2 & i) return !1
                } else e.type == CKEDITOR.NODE_COMMENT && e.value.match(/^\{cke_protected\}(?!\{C\})/) && (function(e, t, s, r) {
                    var n, l, i, a, o = decodeURIComponent(t.value.replace(/^\{cke_protected\}/, "")),
                        u = [];
                    if (s)
                        for (i = 0; i < s.length; ++i)
                            if ((a = o.match(s[i])) && a[0].length == o.length) return !0;
                    1 == (n = CKEDITOR.htmlParser.fragment.fromHtml(o)).children.length && (l = n.children[0]).type == CKEDITOR.NODE_ELEMENT && _(e, l, u, r);
                    return !u.length
                }(o, e, c, h) || u.push(e))
            }, null, !0), u.length && (f = !0);
            for (var d, p, y, m, b = [], C = a[l || (this.editor ? this.editor.enterMode : CKEDITOR.ENTER_P)]; d = u.pop();) d.type == CKEDITOR.NODE_ELEMENT ? j(d, C, b) : d.remove();
            for (; y = b.pop();)
                if ((p = y.el).parent) switch (m = s[p.parent.name] || s.span, y.check) {
                    case "it":
                        s.$removeEmpty[p.name] && !p.children.length ? j(p, C, b) : S(p) || j(p, C, b);
                        break;
                    case "el-up":
                        p.parent.type == CKEDITOR.NODE_DOCUMENT_FRAGMENT || m[p.name] || j(p, C, b);
                        break;
                    case "parent-down":
                        p.parent.type == CKEDITOR.NODE_DOCUMENT_FRAGMENT || m[p.name] || j(p.parent, C, b)
                }
            return f
        },
        checkFeature: function(e) {
            return !!this.disabled || (!e || (e.toFeature && (e = e.toFeature(this.editor)), !e.requiredContent || this.check(e.requiredContent)))
        },
        disable: function() {
            this.disabled = !0
        },
        disallow: function(e) {
            return !!d(this, e, !0) && ("string" == typeof e && (e = O(e)), o(this, e, null, this.disallowedContent, this._.disallowedRules), !0)
        },
        addContentForms: function(e) {
            if (!this.disabled && e) {
                var t, s, r, n = [];
                for (t = 0; t < e.length && !r; ++t)("string" == typeof(s = e[t]) || s instanceof CKEDITOR.style) && this.check(s) && (r = s);
                if (r) {
                    for (t = 0; t < e.length; ++t) n.push(B(e[t], r));
                    this.addTransformations(n)
                }
            }
        },
        addElementCallback: function(e) {
            this.elementCallbacks || (this.elementCallbacks = []), this.elementCallbacks.push(e)
        },
        addFeature: function(e) {
            return !!this.disabled || (!e || (e.toFeature && (e = e.toFeature(this.editor)), this.allow(e.allowedContent, e.name), this.addTransformations(e.contentTransformations), this.addContentForms(e.contentForms), !e.requiredContent || !this.customConfig && !this.disallowedContent.length || this.check(e.requiredContent)))
        },
        addTransformations: function(e) {
            if (!this.disabled && e) {
                var t, s, r = this._.transformations;
                for (s = 0; s < e.length; ++s) r[(t = z(e[s])).name] || (r[t.name] = []), r[t.name].push(t.rules)
            }
        },
        check: function(e, t, s) {
            if (this.disabled) return !0;
            if (CKEDITOR.tools.isArray(e)) {
                for (var r = e.length; r--;)
                    if (this.check(e[r], t, s)) return !0;
                return !1
            }
            var l, i, a;
            if ("string" == typeof e) {
                if ((a = e + "<" + (!1 === t ? "0" : "1") + (s ? "1" : "0") + ">") in this._.cachedChecks) return this._.cachedChecks[a];
                l = function(e) {
                    var t = O(e).$1,
                        s = t.styles,
                        r = t.classes;
                    t.name = t.elements, t.classes = r = r ? r.split(/\s*,\s*/) : [], t.styles = b(s), t.attributes = b(t.attributes), t.children = [], r.length && (t.attributes.class = r.join(" "));
                    s && (t.attributes.style = CKEDITOR.tools.writeCssText(t.styles));
                    return t
                }(e)
            } else l = function(e) {
                var t = e.getDefinition(),
                    s = t.styles,
                    r = t.attributes || {};
                s && !CKEDITOR.tools.isEmpty(s) ? (s = n(s), r.style = CKEDITOR.tools.writeCssText(s, !0)) : s = {};
                return {
                    name: t.element,
                    attributes: r,
                    classes: r.class ? r.class.split(/\s+/) : [],
                    styles: s,
                    children: []
                }
            }(e);
            var o, u = CKEDITOR.tools.clone(l),
                c = [];
            if (!1 !== t && (o = this._.transformations[l.name])) {
                for (r = 0; r < o.length; ++r) q(this, l, o[r]);
                N(l)
            }
            if (_(this, u, c, {
                    doFilter: !0,
                    doTransform: !1 !== t,
                    skipRequired: !s,
                    skipFinalValidation: !s
                }), c.length > 0) i = !1;
            else {
                var f = l.attributes.class;
                f && (l.attributes.class = l.attributes.class.split(" ").sort().join(" ")), i = CKEDITOR.tools.objectCompare(l.attributes, u.attributes, !0), f && (l.attributes.class = f)
            }
            return "string" == typeof e && (this._.cachedChecks[a] = i), i
        },
        getAllowedEnterMode: (e = ["p", "div", "br"], t = {
            p: CKEDITOR.ENTER_P,
            div: CKEDITOR.ENTER_DIV,
            br: CKEDITOR.ENTER_BR
        }, function(s, r) {
            var n, l = e.slice();
            if (this.check(a[s])) return s;
            for (r || (l = l.reverse()); n = l.pop();)
                if (this.check(n)) return t[n];
            return CKEDITOR.ENTER_BR
        }),
        clone: function() {
            var e = new CKEDITOR.filter,
                t = CKEDITOR.tools.clone;
            return e.allowedContent = t(this.allowedContent), e._.allowedRules = t(this._.allowedRules), e.disallowedContent = t(this.disallowedContent), e._.disallowedRules = t(this._.disallowedRules), e._.transformations = t(this._.transformations), e.disabled = this.disabled, e.editor = this.editor, e
        },
        destroy: function() {
            delete CKEDITOR.filter.instances[this.id], delete this._, delete this.allowedContent, delete this.disallowedContent
        }
    };
    var E = {
            styles: 1,
            attributes: 1,
            classes: 1
        },
        g = {
            styles: "requiredStyles",
            attributes: "requiredAttributes",
            classes: "requiredClasses"
        };

    function T(e) {
        var t, s, r;
        for (t in E) e[t] = M(e[t]);
        var n = !0;
        for (r in g)(s = C(e[t = g[r]])).length && (e[t] = s, n = !1);
        e.nothingRequired = n, e.noProperties = !(e.attributes || e.classes || e.styles)
    }
    var v = /^([a-z0-9\-*\s]+)((?:\s*\{[!\w\-,\s\*]+\}\s*|\s*\[[!\w\-,\s\*]+\]\s*|\s*\([!\w\-,\s\*]+\)\s*){0,3})(?:;\s*|$)/i,
        R = {
            styles: /{([^}]+)}/,
            attrs: /\[([^\]]+)\]/,
            classes: /\(([^\)]+)\)/
        };

    function O(e) {
        var t, s, r, n, i, a = {},
            o = 1;
        for (e = l(e); t = e.match(v);)(s = t[2]) ? (r = D(s, "styles"), n = D(s, "attrs"), i = D(s, "classes")) : r = n = i = null, a["$" + o++] = {
            elements: t[1],
            classes: i,
            styles: r,
            attributes: n
        }, e = e.slice(t[0].length);
        return a
    }

    function D(e, t) {
        var s = e.match(R[t]);
        return s ? l(s[1]) : null
    }

    function I(e) {
        var t = e.styleBackup = e.attributes.style,
            s = e.classBackup = e.attributes.class;
        e.styles || (e.styles = CKEDITOR.tools.parseCssText(t || "", 1)), e.classes || (e.classes = s ? s.split(/\s+/) : [])
    }
    var k, w = /^cke:(object|embed|param)$/,
        K = /^(object|embed|param)$/;

    function _(e, t, s, n) {
        var l, i, a = 0;
        if (n.toHtml && (t.name = t.name.replace(w, "$1")), n.doCallbacks && e.elementCallbacks && (i = function(e, t) {
                for (var s, r = 0, n = t.length; r < n; ++r)
                    if (s = t[r](e)) return s
            }(t, e.elementCallbacks))) return i;
        if (n.doTransform && function(e, t) {
                var s, r = e._.transformations[t.name];
                if (!r) return;
                for (I(t), s = 0; s < r.length; ++s) q(e, t, r[s]);
                N(t)
            }(e, t), n.doFilter) {
            if (!(l = function(e, t, s) {
                    var r, n, l = t.name,
                        i = e._,
                        a = i.allowedRules.elements[l],
                        o = i.allowedRules.generic,
                        c = i.disallowedRules.elements[l],
                        h = i.disallowedRules.generic,
                        d = s.skipRequired,
                        p = {
                            valid: !1,
                            validAttributes: {},
                            validClasses: {},
                            validStyles: {},
                            allAttributes: !1,
                            allClasses: !1,
                            allStyles: !1,
                            hadInvalidAttribute: !1,
                            hadInvalidClass: !1,
                            hadInvalidStyle: !1
                        };
                    if (!a && !o) return null;
                    if (I(t), c)
                        for (r = 0, n = c.length; r < n; ++r)
                            if (!1 === f(c[r], t, p)) return null;
                    if (h)
                        for (r = 0, n = h.length; r < n; ++r) f(h[r], t, p);
                    if (a)
                        for (r = 0, n = a.length; r < n; ++r) u(a[r], t, p, d);
                    if (o)
                        for (r = 0, n = o.length; r < n; ++r) u(o[r], t, p, d);
                    return p
                }(e, t, n))) return s.push(t), r;
            if (!l.valid) return s.push(t), r;
            if (function(e, t) {
                    var s, r, n, l = t.validAttributes,
                        i = t.validStyles,
                        a = t.validClasses,
                        o = e.attributes,
                        u = e.styles,
                        c = e.classes,
                        f = e.classBackup,
                        h = e.styleBackup,
                        d = [],
                        p = [],
                        y = /^data-cke-/,
                        m = !1;
                    if (delete o.style, delete o.class, delete e.classBackup, delete e.styleBackup, !t.allAttributes)
                        for (s in o) l[s] || y.test(s) && (s == (r = s.replace(/^data-cke-saved-/, "")) || l[r]) || (delete o[s], m = !0);
                    if (!t.allStyles || t.hadInvalidStyle) {
                        for (s in u) t.allStyles || i[s] ? d.push(s + ":" + u[s]) : m = !0;
                        d.length && (o.style = d.sort().join("; "))
                    } else h && (o.style = h);
                    if (!t.allClasses || t.hadInvalidClass) {
                        for (n = 0; n < c.length; ++n)(t.allClasses || a[c[n]]) && p.push(c[n]);
                        p.length && (o.class = p.sort().join(" ")), f && p.length < f.split(/\s+/).length && (m = !0)
                    } else f && (o.class = f);
                    return m
                }(t, l) && (a = r), !n.skipFinalValidation && !S(t)) return s.push(t), r
        }
        return n.toHtml && (t.name = t.name.replace(K, "cke:$1")), a
    }

    function A(e) {
        e.elements = p(e.elements, /\s+/) || null, e.propertiesOnly = e.propertiesOnly || !0 === e.elements;
        var t, s = /\s*,\s*/;
        for (t in E) e[t] = p(e[t], s) || null, e[g[t]] = y(p(e[g[t]], s), e[t]) || null;
        e.match = e.match || null
    }

    function N(e) {
        var t, s = e.attributes;
        delete s.style, delete s.class, (t = CKEDITOR.tools.writeCssText(e.styles, !0)) && (s.style = t), e.classes.length && (s.class = e.classes.sort().join(" "))
    }

    function S(e) {
        switch (e.name) {
            case "a":
                if (!(e.children.length || e.attributes.name || e.attributes.id)) return !1;
                break;
            case "img":
                if (!e.attributes.src) return !1
        }
        return !0
    }

    function M(e) {
        if (!e) return !1;
        if (!0 === e) return !0;
        var t = function(e) {
            var t, s = [];
            for (t in e) t.indexOf("*") > -1 && s.push(t.replace(/\*/g, ".*"));
            return s.length ? new RegExp("^(?:" + s.join("|") + ")$") : null
        }(e);
        return function(s) {
            return s in e || t && s.match(t)
        }
    }

    function x() {
        return new CKEDITOR.htmlParser.element("br")
    }

    function F(e) {
        return e.type == CKEDITOR.NODE_ELEMENT && ("br" == e.name || s.$block[e.name])
    }

    function j(e, t, r) {
        var n = e.name;
        s.$empty[n] || !e.children.length ? "hr" == n && "br" == t ? e.replaceWith(x()) : (e.parent && r.push({
            check: "it",
            el: e.parent
        }), e.remove()) : s.$block[n] || "tr" == n ? "br" == t ? function(e) {
            e.previous && !F(e.previous) && x().insertBefore(e);
            e.next && !F(e.next) && x().insertAfter(e);
            e.replaceWithChildren()
        }(e) : function(e, t, r) {
            var n = e.children;
            if (function(e, t) {
                    for (var r, n = s[t], l = 0, i = e.length; l < i; ++l)
                        if ((r = e[l]).type == CKEDITOR.NODE_ELEMENT && !n[r.name]) return !1;
                    return !0
                }(n, t)) return e.name = t, e.attributes = {}, void r.push({
                check: "parent-down",
                el: e
            });
            var l, i, a, o, u = e.parent,
                c = u.type == CKEDITOR.NODE_DOCUMENT_FRAGMENT || "body" == u.name;
            for (l = n.length; l > 0;) i = n[--l], c && ((f = i).type == CKEDITOR.NODE_TEXT || f.type == CKEDITOR.NODE_ELEMENT && s.$inline[f.name]) ? (a || ((a = new CKEDITOR.htmlParser.element(t)).insertAfter(e), r.push({
                check: "parent-down",
                el: a
            })), a.add(i, 0)) : (a = null, o = s[u.name] || s.span, i.insertAfter(e), u.type == CKEDITOR.NODE_DOCUMENT_FRAGMENT || i.type != CKEDITOR.NODE_ELEMENT || o[i.name] || r.push({
                check: "el-up",
                el: i
            }));
            var f;
            e.remove()
        }(e, t, r) : n in {
            style: 1,
            script: 1
        } ? e.remove() : (e.parent && r.push({
            check: "it",
            el: e.parent
        }), e.replaceWithChildren())
    }

    function q(e, t, s) {
        var r, n;
        for (r = 0; r < s.length; ++r)
            if ((!(n = s[r]).check || e.check(n.check, !1)) && (!n.left || n.left(t))) return void n.right(t, k)
    }

    function $(e, t) {
        var s, r, n, l, i, a = t.getDefinition(),
            o = a.attributes,
            u = a.styles;
        if (e.name != a.element) return !1;
        for (s in o)
            if ("class" == s) {
                for (n = o[s].split(/\s+/), l = e.classes.join("|"); i = n.pop();)
                    if (-1 == l.indexOf(i)) return !1
            } else if (e.attributes[s] != o[s]) return !1;
        for (r in u)
            if (e.styles[r] != u[r]) return !1;
        return !0
    }

    function B(e, t) {
        var s, r;
        return "string" == typeof e ? s = e : e instanceof CKEDITOR.style ? r = e : (s = e[0], r = e[1]), [{
            element: s,
            left: r,
            right: function(e, s) {
                s.transform(e, t)
            }
        }]
    }

    function L(e, t) {
        return e.element ? e.element : t ? t.match(/^([a-z0-9]+)/i)[0] : e.left.getDefinition().element
    }

    function P(e) {
        return function(t) {
            return $(t, e)
        }
    }

    function U(e) {
        return function(t, s) {
            s[e](t)
        }
    }

    function z(e) {
        var t, s, r, n, l, i, a = [];
        for (s = 0; s < e.length; ++s) "string" == typeof(r = e[s]) ? (n = (r = r.split(/\s*:\s*/))[0], l = null, i = r[1]) : (n = r.check, l = r.left, i = r.right), t || (t = L(r, n)), l instanceof CKEDITOR.style && (l = P(l)), a.push({
            check: n == t ? null : n,
            left: l,
            right: "string" == typeof i ? U(i) : i
        });
        return {
            name: t,
            rules: a
        }
    }
    k = CKEDITOR.filter.transformationsTools = {
        sizeToStyle: function(e) {
            this.lengthToStyle(e, "width"), this.lengthToStyle(e, "height")
        },
        sizeToAttribute: function(e) {
            this.lengthToAttribute(e, "width"), this.lengthToAttribute(e, "height")
        },
        lengthToStyle: function(e, t, s) {
            if (!((s = s || t) in e.styles)) {
                var r = e.attributes[t];
                r && (/^\d+$/.test(r) && (r += "px"), e.styles[s] = r)
            }
            delete e.attributes[t]
        },
        lengthToAttribute: function(e, t, s) {
            if (!((s = s || t) in e.attributes)) {
                var r = e.styles[t],
                    n = r && r.match(/^(\d+)(?:\.\d*)?px$/);
                n ? e.attributes[s] = n[1] : r == i && (e.attributes[s] = i)
            }
            delete e.styles[t]
        },
        alignmentToStyle: function(e) {
            if (!("float" in e.styles)) {
                var t = e.attributes.align;
                "left" != t && "right" != t || (e.styles.float = t)
            }
            delete e.attributes.align
        },
        alignmentToAttribute: function(e) {
            if (!("align" in e.attributes)) {
                var t = e.styles.float;
                "left" != t && "right" != t || (e.attributes.align = t)
            }
            delete e.styles.float
        },
        splitBorderShorthand: function(e) {
            if (e.styles.border) {
                var t = CKEDITOR.tools.style.parse.border(e.styles.border);
                t.color && (e.styles["border-color"] = t.color), t.style && (e.styles["border-style"] = t.style), t.width && (e.styles["border-width"] = t.width), delete e.styles.border
            }
        },
        listTypeToStyle: function(e) {
            if (e.attributes.type) switch (e.attributes.type) {
                case "a":
                    e.styles["list-style-type"] = "lower-alpha";
                    break;
                case "A":
                    e.styles["list-style-type"] = "upper-alpha";
                    break;
                case "i":
                    e.styles["list-style-type"] = "lower-roman";
                    break;
                case "I":
                    e.styles["list-style-type"] = "upper-roman";
                    break;
                case "1":
                    e.styles["list-style-type"] = "decimal";
                    break;
                default:
                    e.styles["list-style-type"] = e.attributes.type
            }
        },
        splitMarginShorthand: function(e) {
            if (e.styles.margin) {
                var t = e.styles.margin.match(/(\-?[\.\d]+\w+)/g) || ["0px"];
                switch (t.length) {
                    case 1:
                        s([0, 0, 0, 0]);
                        break;
                    case 2:
                        s([0, 1, 0, 1]);
                        break;
                    case 3:
                        s([0, 1, 2, 1]);
                        break;
                    case 4:
                        s([0, 1, 2, 3])
                }
                delete e.styles.margin
            }

            function s(s) {
                e.styles["margin-top"] = t[s[0]], e.styles["margin-right"] = t[s[1]], e.styles["margin-bottom"] = t[s[2]], e.styles["margin-left"] = t[s[3]]
            }
        },
        matchesStyle: $,
        transform: function(e, t) {
            if ("string" == typeof t) e.name = t;
            else {
                var s, r, n, l, i, a = t.getDefinition(),
                    o = a.styles,
                    u = a.attributes;
                for (s in e.name = a.element, u)
                    if ("class" == s)
                        for (n = e.classes.join("|"), l = u[s].split(/\s+/); i = l.pop();) - 1 == n.indexOf(i) && e.classes.push(i);
                    else e.attributes[s] = u[s];
                for (r in o) e.styles[r] = o[r]
            }
        }
    }
}();