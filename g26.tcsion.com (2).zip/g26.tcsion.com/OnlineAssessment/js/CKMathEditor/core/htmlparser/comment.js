"use strict";
CKEDITOR.htmlParser.comment = function(t) {
    this.value = t, this._ = {
        isBlockLike: !1
    }
}, CKEDITOR.htmlParser.comment.prototype = CKEDITOR.tools.extend(new CKEDITOR.htmlParser.node, {
    type: CKEDITOR.NODE_COMMENT,
    filter: function(t, e) {
        var i = this.value;
        return (i = t.onComment(e, i, this)) ? "string" != typeof i ? (this.replaceWith(i), !1) : (this.value = i, !0) : (this.remove(), !1)
    },
    writeHtml: function(t, e) {
        e && this.filter(e), t.comment(this.value)
    }
});