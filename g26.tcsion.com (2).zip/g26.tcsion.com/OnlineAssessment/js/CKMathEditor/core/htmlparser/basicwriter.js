CKEDITOR.htmlParser.basicWriter = CKEDITOR.tools.createClass({
    $: function() {
        this._ = {
            output: []
        }
    },
    proto: {
        openTag: function(t) {
            this._.output.push("<", t)
        },
        openTagClose: function(t, u) {
            u ? this._.output.push(" />") : this._.output.push(">")
        },
        attribute: function(t, u) {
            "string" == typeof u && (u = CKEDITOR.tools.htmlEncodeAttr(u)), this._.output.push(" ", t, '="', u, '"')
        },
        closeTag: function(t) {
            this._.output.push("</", t, ">")
        },
        text: function(t) {
            this._.output.push(t)
        },
        comment: function(t) {
            this._.output.push("\x3c!--", t, "--\x3e")
        },
        write: function(t) {
            this._.output.push(t)
        },
        reset: function() {
            this._.output = [], this._.indent = !1
        },
        getHtml: function(t) {
            var u = this._.output.join("");
            return t && this.reset(), u
        }
    }
});