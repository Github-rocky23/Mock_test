"use strict";
! function() {
    function e() {
        this.rules = []
    }

    function t(t, n, s, i) {
        var r, u;
        for (r in n)(u = t[r]) || (u = t[r] = new e), u.add(n[r], s, i)
    }

    function n(e, t) {
        return !(e.nonEditable && !t.options.applyToAll) && (!e.nestedEditable || !t.options.excludeNestedEditable)
    }
    CKEDITOR.htmlParser.filter = CKEDITOR.tools.createClass({
        $: function(t) {
            this.id = CKEDITOR.tools.getNextNumber(), this.elementNameRules = new e, this.attributeNameRules = new e, this.elementsRules = {}, this.attributesRules = {}, this.textRules = new e, this.commentRules = new e, this.rootRules = new e, t && this.addRules(t, 10)
        },
        proto: {
            addRules: function(e, n) {
                var s;
                "number" == typeof n ? s = n : n && "priority" in n && (s = n.priority), "number" != typeof s && (s = 10), "object" != typeof n && (n = {}), e.elementNames && this.elementNameRules.addMany(e.elementNames, s, n), e.attributeNames && this.attributeNameRules.addMany(e.attributeNames, s, n), e.elements && t(this.elementsRules, e.elements, s, n), e.attributes && t(this.attributesRules, e.attributes, s, n), e.text && this.textRules.add(e.text, s, n), e.comment && this.commentRules.add(e.comment, s, n), e.root && this.rootRules.add(e.root, s, n)
            },
            applyTo: function(e) {
                e.filter(this)
            },
            onElementName: function(e, t) {
                return this.elementNameRules.execOnName(e, t)
            },
            onAttributeName: function(e, t) {
                return this.attributeNameRules.execOnName(e, t)
            },
            onText: function(e, t, n) {
                return this.textRules.exec(e, t, n)
            },
            onComment: function(e, t, n) {
                return this.commentRules.exec(e, t, n)
            },
            onRoot: function(e, t) {
                return this.rootRules.exec(e, t)
            },
            onElement: function(e, t) {
                for (var n, s, i = [this.elementsRules["^"], this.elementsRules[t.name], this.elementsRules.$], r = 0; r < 3; r++)
                    if (n = i[r]) {
                        if (!1 === (s = n.exec(e, t, this))) return null;
                        if (s && s != t) return this.onNode(e, s);
                        if (t.parent && !t.name) break
                    }
                return t
            },
            onNode: function(e, t) {
                var n = t.type;
                return n == CKEDITOR.NODE_ELEMENT ? this.onElement(e, t) : n == CKEDITOR.NODE_TEXT ? new CKEDITOR.htmlParser.text(this.onText(e, t.value)) : n == CKEDITOR.NODE_COMMENT ? new CKEDITOR.htmlParser.comment(this.onComment(e, t.value)) : null
            },
            onAttribute: function(e, t, n, s) {
                var i = this.attributesRules[n];
                return i ? i.exec(e, s, t, this) : s
            }
        }
    }), CKEDITOR.htmlParser.filterRulesGroup = e, e.prototype = {
        add: function(e, t, n) {
            this.rules.splice(this.findIndex(t), 0, {
                value: e,
                priority: t,
                options: n
            })
        },
        addMany: function(e, t, n) {
            for (var s = [this.findIndex(t), 0], i = 0, r = e.length; i < r; i++) s.push({
                value: e[i],
                priority: t,
                options: n
            });
            this.rules.splice.apply(this.rules, s)
        },
        findIndex: function(e) {
            for (var t = this.rules, n = t.length - 1; n >= 0 && e < t[n].priority;) n--;
            return n + 1
        },
        exec: function(e, t) {
            var s, i, r, u, l, o = t instanceof CKEDITOR.htmlParser.node || t instanceof CKEDITOR.htmlParser.fragment,
                a = Array.prototype.slice.call(arguments, 1),
                m = this.rules,
                h = m.length;
            for (u = 0; u < h; u++)
                if (o && (s = t.type, i = t.name), n(e, l = m[u])) {
                    if (!1 === (r = l.value.apply(null, a))) return r;
                    if (o && r && (r.name != i || r.type != s)) return r;
                    null != r && (a[0] = t = r)
                }
            return t
        },
        execOnName: function(e, t) {
            for (var s, i = 0, r = this.rules, u = r.length; t && i < u; i++) n(e, s = r[i]) && (t = t.replace(s.value[0], s.value[1]));
            return t
        }
    }
}();