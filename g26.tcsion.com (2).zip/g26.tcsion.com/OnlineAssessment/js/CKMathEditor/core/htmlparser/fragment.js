"use strict";
CKEDITOR.htmlParser.fragment = function() {
        this.children = [], this.parent = null, this._ = {
            isBlockLike: !0,
            hasInlineStarted: !1
        }
    },
    function() {
        var t = CKEDITOR.tools.extend({
                table: 1,
                ul: 1,
                ol: 1,
                dl: 1
            }, CKEDITOR.dtd.table, CKEDITOR.dtd.ul, CKEDITOR.dtd.ol, CKEDITOR.dtd.dl),
            e = {
                ol: 1,
                ul: 1
            },
            n = CKEDITOR.tools.extend({}, {
                html: 1
            }, CKEDITOR.dtd.html, CKEDITOR.dtd.body, CKEDITOR.dtd.head, {
                style: 1,
                script: 1
            }),
            i = {
                ul: "li",
                ol: "li",
                dl: "dd",
                table: "tbody",
                tbody: "tr",
                thead: "tr",
                tfoot: "tr",
                tr: "td"
            };

        function r(t) {
            return !t.attributes["data-cke-survive"] && ("a" == t.name && t.attributes.href || CKEDITOR.dtd.$removeEmpty[t.name])
        }
        CKEDITOR.htmlParser.fragment.fromHtml = function(l, a, d) {
            var o = new CKEDITOR.htmlParser,
                s = a instanceof CKEDITOR.htmlParser.element ? a : "string" == typeof a ? new CKEDITOR.htmlParser.element(a) : new CKEDITOR.htmlParser.fragment,
                h = [],
                f = [],
                E = s,
                T = "textarea" == s.name,
                C = "pre" == s.name;

            function O(t) {
                var e;
                if (h.length > 0)
                    for (var n = 0; n < h.length; n++) {
                        var i = h[n],
                            r = i.name,
                            l = CKEDITOR.dtd[r],
                            a = E.name && CKEDITOR.dtd[E.name];
                        a && !a[r] || t && l && !l[t] && CKEDITOR.dtd[t] ? r == E.name && (c(E, E.parent, 1), n--) : (e || (u(), e = 1), (i = i.clone()).parent = E, E = i, h.splice(n, 1), n--)
                    }
            }

            function u() {
                for (; f.length;) c(f.shift(), E)
            }

            function m(t) {
                if (t._.isBlockLike && "pre" != t.name && "textarea" != t.name) {
                    var e, n = t.children.length,
                        i = t.children[n - 1];
                    i && i.type == CKEDITOR.NODE_TEXT && ((e = CKEDITOR.tools.rtrim(i.value)) ? i.value = e : t.children.length = n - 1)
                }
            }

            function c(t, e, n) {
                e = e || E || s;
                var i = E;
                void 0 === t.previous && (p(e, t) && (E = e, o.onTagOpen(d, {}), t.returnPoint = e = E), m(t), r(t) && !t.children.length || e.add(t), "pre" == t.name && (C = !1), "textarea" == t.name && (T = !1)), t.returnPoint ? (E = t.returnPoint, delete t.returnPoint) : E = n ? e : i
            }

            function p(t, e) {
                var n, i;
                if ((t == s || "body" == t.name) && d && (!t.name || CKEDITOR.dtd[t.name][d])) return (n = e.attributes && (i = e.attributes["data-cke-real-element-type"]) ? i : e.name) && n in CKEDITOR.dtd.$inline && !(n in CKEDITOR.dtd.head) && !e.isOrphan || e.type == CKEDITOR.NODE_TEXT
            }

            function D(t, e) {
                return (t in CKEDITOR.dtd.$listItem || t in CKEDITOR.dtd.$tableContent) && (t == e || "dt" == t && "dd" == e || "dd" == t && "dt" == e)
            }
            for (o.onTagOpen = function(i, l, a, d) {
                    var s = new CKEDITOR.htmlParser.element(i, l);
                    if (s.isUnknown && a && (s.isEmpty = !0), s.isOptionalClose = d, r(s)) h.push(s);
                    else {
                        if ("pre" == i) C = !0;
                        else {
                            if ("br" == i && C) return void E.add(new CKEDITOR.htmlParser.text("\n"));
                            "textarea" == i && (T = !0)
                        }
                        if ("br" != i) {
                            for (;;) {
                                var m = E.name,
                                    p = m ? CKEDITOR.dtd[m] || (E._.isBlockLike ? CKEDITOR.dtd.div : CKEDITOR.dtd.span) : n;
                                if (s.isUnknown || E.isUnknown || p[i]) break;
                                if (E.isOptionalClose) o.onTagClose(m);
                                else if (i in e && m in e) {
                                    var I = E.children,
                                        R = I[I.length - 1];
                                    R && "li" == R.name || c(R = new CKEDITOR.htmlParser.element("li"), E), !s.returnPoint && (s.returnPoint = E), E = R
                                } else if (i in CKEDITOR.dtd.$listItem && !D(i, m)) o.onTagOpen("li" == i ? "ul" : "dl", {}, 0, 1);
                                else if (m in t && !D(i, m)) !s.returnPoint && (s.returnPoint = E), E = E.parent;
                                else {
                                    if (m in CKEDITOR.dtd.$inline && h.unshift(E), !E.parent) {
                                        s.isOrphan = 1;
                                        break
                                    }
                                    c(E, E.parent, 1)
                                }
                            }
                            O(i), u(), s.parent = E, s.isEmpty ? c(s) : E = s
                        } else f.push(s)
                    }
                }, o.onTagClose = function(t) {
                    for (var e = h.length - 1; e >= 0; e--)
                        if (t == h[e].name) return void h.splice(e, 1);
                    for (var n = [], i = [], r = E; r != s && r.name != t;) r._.isBlockLike || i.unshift(r), n.push(r), r = r.returnPoint || r.parent;
                    if (r != s) {
                        for (e = 0; e < n.length; e++) {
                            var l = n[e];
                            c(l, l.parent)
                        }
                        E = r, r._.isBlockLike && u(), c(r, r.parent), r == E && (E = E.parent), h = h.concat(i)
                    }
                    "body" == t && (d = !1)
                }, o.onText = function(e) {
                    if (E._.hasInlineStarted && !f.length || C || T || 0 !== (e = CKEDITOR.tools.ltrim(e)).length) {
                        var r = E.name,
                            l = r ? CKEDITOR.dtd[r] || (E._.isBlockLike ? CKEDITOR.dtd.div : CKEDITOR.dtd.span) : n;
                        if (!T && !l["#"] && r in t) return o.onTagOpen(i[r] || ""), void o.onText(e);
                        u(), O(), C || T || (e = e.replace(/[\t\r\n ]{2,}|[\t\r\n]/g, " ")), e = new CKEDITOR.htmlParser.text(e), p(E, e) && this.onTagOpen(d, {}, 0, 1), E.add(e)
                    }
                }, o.onCDATA = function(t) {
                    E.add(new CKEDITOR.htmlParser.cdata(t))
                }, o.onComment = function(t) {
                    u(), O(), E.add(new CKEDITOR.htmlParser.comment(t))
                }, o.parse(l), u(); E != s;) c(E, E.parent, 1);
            return m(s), s
        }, CKEDITOR.htmlParser.fragment.prototype = {
            type: CKEDITOR.NODE_DOCUMENT_FRAGMENT,
            add: function(t, e) {
                isNaN(e) && (e = this.children.length);
                var n = e > 0 ? this.children[e - 1] : null;
                if (n) {
                    if (t._.isBlockLike && n.type == CKEDITOR.NODE_TEXT && (n.value = CKEDITOR.tools.rtrim(n.value), 0 === n.value.length)) return this.children.pop(), void this.add(t);
                    n.next = t
                }
                t.previous = n, t.parent = this, this.children.splice(e, 0, t), this._.hasInlineStarted || (this._.hasInlineStarted = t.type == CKEDITOR.NODE_TEXT || t.type == CKEDITOR.NODE_ELEMENT && !t._.isBlockLike)
            },
            filter: function(t, e) {
                e = this.getFilterContext(e), t.onRoot(e, this), this.filterChildren(t, !1, e)
            },
            filterChildren: function(t, e, n) {
                if (this.childrenFilteredBy != t.id) {
                    n = this.getFilterContext(n), e && !this.parent && t.onRoot(n, this), this.childrenFilteredBy = t.id;
                    for (var i = 0; i < this.children.length; i++) !1 === this.children[i].filter(t, n) && i--
                }
            },
            writeHtml: function(t, e) {
                e && this.filter(e), this.writeChildrenHtml(t)
            },
            writeChildrenHtml: function(t, e, n) {
                var i = this.getFilterContext();
                n && !this.parent && e && e.onRoot(i, this), e && this.filterChildren(e, !1, i);
                for (var r = 0, l = this.children, a = l.length; r < a; r++) l[r].writeHtml(t)
            },
            forEach: function(t, e, n) {
                if (!(n || e && this.type != e)) var i = t(this);
                if (!1 !== i)
                    for (var r, l = this.children, a = 0; a < l.length; a++)(r = l[a]).type == CKEDITOR.NODE_ELEMENT ? r.forEach(t, e) : e && r.type != e || t(r)
            },
            getFilterContext: function(t) {
                return t || {}
            }
        }
    }();