"use strict";
CKEDITOR.htmlParser.element = function(t, e) {
        this.name = t, this.attributes = e || {}, this.children = [];
        var n = t || "",
            r = n.match(/^cke:(.*)/);
        r && (n = r[1]);
        var i = !!(CKEDITOR.dtd.$nonBodyContent[n] || CKEDITOR.dtd.$block[n] || CKEDITOR.dtd.$listItem[n] || CKEDITOR.dtd.$tableContent[n] || CKEDITOR.dtd.$nonEditable[n] || "br" == n);
        this.isEmpty = !!CKEDITOR.dtd.$empty[t], this.isUnknown = !CKEDITOR.dtd[t], this._ = {
            isBlockLike: i,
            hasInlineStarted: this.isEmpty || !i
        }
    }, CKEDITOR.htmlParser.cssStyle = function() {
        var t = arguments[0],
            e = {};
        return ((t instanceof CKEDITOR.htmlParser.element ? t.attributes.style : t) || "").replace(/&quot;/g, '"').replace(/\s*([^ :;]+)\s*:\s*([^;]+)\s*(?=;|$)/g, function(t, n, r) {
            "font-family" == n && (r = r.replace(/["']/g, "")), e[n.toLowerCase()] = r
        }), {
            rules: e,
            populate: function(t) {
                var e = this.toString();
                e && (t instanceof CKEDITOR.dom.element ? t.setAttribute("style", e) : t instanceof CKEDITOR.htmlParser.element ? t.attributes.style = e : t.style = e)
            },
            toString: function() {
                var t = [];
                for (var n in e) e[n] && t.push(n, ":", e[n], ";");
                return t.join("")
            }
        }
    },
    function() {
        var t = function(t, e) {
                return (t = t[0]) < (e = e[0]) ? -1 : t > e ? 1 : 0
            },
            e = CKEDITOR.htmlParser.fragment.prototype;
        CKEDITOR.htmlParser.element.prototype = CKEDITOR.tools.extend(new CKEDITOR.htmlParser.node, {
            type: CKEDITOR.NODE_ELEMENT,
            add: e.add,
            clone: function() {
                return new CKEDITOR.htmlParser.element(this.name, this.attributes)
            },
            filter: function(t, e) {
                var n, r, i = this;
                for (e = i.getFilterContext(e), i.parent || t.onRoot(e, i);;) {
                    if (n = i.name, !(r = t.onElementName(e, n))) return this.remove(), !1;
                    if (i.name = r, !(i = t.onElement(e, i))) return this.remove(), !1;
                    if (i !== this) return this.replaceWith(i), !1;
                    if (i.name == n) break;
                    if (i.type != CKEDITOR.NODE_ELEMENT) return this.replaceWith(i), !1;
                    if (!i.name) return this.replaceWithChildren(), !1
                }
                var s, l, a, h = i.attributes;
                for (s in h) {
                    for (a = s, l = h[s];;) {
                        if (a = t.onAttributeName(e, s)) {
                            if (a != s) {
                                delete h[s], s = a;
                                continue
                            }
                            break
                        }
                        delete h[s];
                        break
                    }
                    a && (!1 === (l = t.onAttribute(e, i, a, l)) ? delete h[a] : h[a] = l)
                }
                return i.isEmpty || this.filterChildren(t, !1, e), !0
            },
            filterChildren: e.filterChildren,
            writeHtml: function(e, n) {
                n && this.filter(n);
                var r, i, s, l, a = this.name,
                    h = [],
                    o = this.attributes;
                for (r in e.openTag(a, o), o) h.push([r, o[r]]);
                for (e.sortAttributes && h.sort(t), s = 0, l = h.length; s < l; s++) i = h[s], e.attribute(i[0], i[1]);
                e.openTagClose(a, this.isEmpty), this.writeChildrenHtml(e), this.isEmpty || e.closeTag(a)
            },
            writeChildrenHtml: e.writeChildrenHtml,
            replaceWithChildren: function() {
                for (var t = this.children, e = t.length; e;) t[--e].insertAfter(this);
                this.remove()
            },
            forEach: e.forEach,
            getFirst: function(t) {
                if (!t) return this.children.length ? this.children[0] : null;
                "function" != typeof t && (t = function(t) {
                    return function(e) {
                        return e.type == CKEDITOR.NODE_ELEMENT && ("string" == typeof t ? e.name == t : e.name in t)
                    }
                }(t));
                for (var e = 0, n = this.children.length; e < n; ++e)
                    if (t(this.children[e])) return this.children[e];
                return null
            },
            getHtml: function() {
                var t = new CKEDITOR.htmlParser.basicWriter;
                return this.writeChildrenHtml(t), t.getHtml()
            },
            setHtml: function(t) {
                for (var e = this.children = CKEDITOR.htmlParser.fragment.fromHtml(t).children, n = 0, r = e.length; n < r; ++n) e[n].parent = this
            },
            getOuterHtml: function() {
                var t = new CKEDITOR.htmlParser.basicWriter;
                return this.writeHtml(t), t.getHtml()
            },
            split: function(t) {
                for (var e = this.children.splice(t, this.children.length - t), n = this.clone(), r = 0; r < e.length; ++r) e[r].parent = n;
                return n.children = e, e[0] && (e[0].previous = null), t > 0 && (this.children[t - 1].next = null), this.parent.add(n, this.getIndex() + 1), n
            },
            find: function(t, e) {
                void 0 === e && (e = !1);
                var n, r = [];
                for (n = 0; n < this.children.length; n++) {
                    var i = this.children[n];
                    "function" == typeof t && t(i) ? r.push(i) : "string" == typeof t && i.name === t && r.push(i), e && i.find && (r = r.concat(i.find(t, e)))
                }
                return r
            },
            addClass: function(t) {
                if (!this.hasClass(t)) {
                    var e = this.attributes.class || "";
                    this.attributes.class = e + (e ? " " : "") + t
                }
            },
            removeClass: function(t) {
                var e = this.attributes.class;
                e && ((e = CKEDITOR.tools.trim(e.replace(new RegExp("(?:\\s+|^)" + t + "(?:\\s+|$)"), " "))) ? this.attributes.class = e : delete this.attributes.class)
            },
            hasClass: function(t) {
                var e = this.attributes.class;
                return !!e && new RegExp("(?:^|\\s)" + t + "(?=\\s|$)").test(e)
            },
            getFilterContext: function(t) {
                var e = [];
                if (t || (t = {
                        nonEditable: !1,
                        nestedEditable: !1
                    }), t.nonEditable || "false" != this.attributes.contenteditable ? t.nonEditable && !t.nestedEditable && "true" == this.attributes.contenteditable && e.push("nestedEditable", !0) : e.push("nonEditable", !0), e.length) {
                    t = CKEDITOR.tools.copy(t);
                    for (var n = 0; n < e.length; n += 2) t[e[n]] = e[n + 1]
                }
                return t
            }
        }, !0)
    }();