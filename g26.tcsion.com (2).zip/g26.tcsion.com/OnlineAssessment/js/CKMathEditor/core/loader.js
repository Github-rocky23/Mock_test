"undefined" == typeof CKEDITOR && (CKEDITOR = {}), CKEDITOR.loader || (CKEDITOR.loader = function() {
    var e, t = {
        _bootstrap: ["config", "creators/inline", "creators/themedui", "editable", "ckeditor", "plugins", "scriptloader", "style", "tools", "dom/comment", "dom/elementpath", "dom/text", "dom/rangelist", "skin"],
        ckeditor: ["ckeditor_basic", "log", "dom", "dtd", "dom/document", "dom/element", "dom/iterator", "editor", "event", "htmldataprocessor", "htmlparser", "htmlparser/element", "htmlparser/fragment", "htmlparser/filter", "htmlparser/basicwriter", "template", "tools"],
        ckeditor_base: [],
        ckeditor_basic: ["editor_basic", "env", "event"],
        command: [],
        config: ["ckeditor_base"],
        dom: [],
        "dom/comment": ["dom/node"],
        "dom/document": ["dom/node", "dom/window"],
        "dom/documentfragment": ["dom/element"],
        "dom/element": ["dom", "dom/document", "dom/domobject", "dom/node", "dom/nodelist", "tools"],
        "dom/elementpath": ["dom/element"],
        "dom/event": [],
        "dom/iterator": ["dom/range"],
        "dom/node": ["dom/domobject", "tools"],
        "dom/nodelist": ["dom/node"],
        "dom/domobject": ["dom/event"],
        "dom/range": ["dom/document", "dom/documentfragment", "dom/element", "dom/walker"],
        "dom/rangelist": ["dom/range"],
        "dom/text": ["dom/node", "dom/domobject"],
        "dom/walker": ["dom/node"],
        "dom/window": ["dom/domobject"],
        dtd: ["tools"],
        editable: ["editor", "tools"],
        editor: ["command", "config", "editor_basic", "filter", "focusmanager", "keystrokehandler", "lang", "plugins", "tools", "ui"],
        editor_basic: ["event"],
        env: [],
        event: [],
        filter: ["dtd", "tools"],
        focusmanager: [],
        htmldataprocessor: ["htmlparser", "htmlparser/basicwriter", "htmlparser/fragment", "htmlparser/filter"],
        htmlparser: [],
        "htmlparser/comment": ["htmlparser", "htmlparser/node"],
        "htmlparser/element": ["htmlparser", "htmlparser/fragment", "htmlparser/node"],
        "htmlparser/fragment": ["htmlparser", "htmlparser/comment", "htmlparser/text", "htmlparser/cdata"],
        "htmlparser/text": ["htmlparser", "htmlparser/node"],
        "htmlparser/cdata": ["htmlparser", "htmlparser/node"],
        "htmlparser/filter": ["htmlparser"],
        "htmlparser/basicwriter": ["htmlparser"],
        "htmlparser/node": ["htmlparser"],
        keystrokehandler: ["event"],
        lang: [],
        log: ["ckeditor_basic"],
        plugins: ["resourcemanager"],
        resourcemanager: ["scriptloader", "tools"],
        scriptloader: ["dom/element", "env"],
        selection: ["dom/range", "dom/walker"],
        skin: [],
        style: ["selection"],
        template: [],
        tools: ["env"],
        ui: [],
        "creators/themedui": [],
        "creators/inline": []
    };
    e = CKEDITOR && CKEDITOR.timestamp || (new Date).valueOf();
    var o = function(t) {
            return CKEDITOR && CKEDITOR.getUrl ? CKEDITOR.getUrl(t) : CKEDITOR.basePath + t + (t.indexOf("?") >= 0 ? "&" : "?") + "t=" + e
        },
        r = [];
    return {
        loadedScripts: [],
        scripts: t,
        loadPending: function() {
            var e = r.shift();
            if (e) {
                var t = o("core/" + e + ".js"),
                    d = document.createElement("script");
                d.type = "text/javascript", d.src = t, void 0 !== d.onreadystatechange ? d.onreadystatechange = function() {
                    "loaded" != d.readyState && "complete" != d.readyState || (d.onreadystatechange = null, a())
                } : d.onload = function() {
                    setTimeout(function() {
                        a()
                    }, 0)
                }, document.body.appendChild(d)
            }

            function a() {
                CKEDITOR.loader.loadedScripts.push(e), CKEDITOR.loader.loadPending()
            }
        },
        load: function(e, d) {
            if (!("s:" + e in this.loadedScripts)) {
                var a = t[e];
                if (!a) throw 'The script name"' + e + '" is not defined.';
                this.loadedScripts["s:" + e] = !0;
                for (var m = 0; m < a.length; m++) this.load(a[m], !0);
                var n = o("core/" + e + ".js");
                !document.body || document.readyState && "complete" != document.readyState ? (this.loadedScripts.push(e), document.write('<script src="' + n + '" type="text/javascript"><\/script>')) : (r.push(e), d || this.loadPending())
            }
        }
    }
}()), CKEDITOR._autoLoad && (CKEDITOR.loader.load(CKEDITOR._autoLoad), delete CKEDITOR._autoLoad);