CKEDITOR.command = function(t, e) {
    var s;
    this.uiItems = [], this.exec = function(s) {
        return !(this.state == CKEDITOR.TRISTATE_DISABLED || !this.checkAllowed()) && (this.editorFocus && t.focus(), !1 === this.fire("exec") || !1 !== e.exec.call(this, t, s))
    }, this.refresh = function(t, s) {
        return !(this.readOnly || !t.readOnly) || (this.context && !s.isContextFor(this.context) ? (this.disable(), !0) : this.checkAllowed(!0) ? (this.startDisabled || this.enable(), this.modes && !this.modes[t.mode] && this.disable(), !1 === this.fire("refresh", {
            editor: t,
            path: s
        }) || e.refresh && !1 !== e.refresh.apply(this, arguments)) : (this.disable(), !0))
    }, this.checkAllowed = function(e) {
        return e || "boolean" != typeof s ? s = t.activeFilter.checkFeature(this) : s
    }, CKEDITOR.tools.extend(this, e, {
        modes: {
            wysiwyg: 1
        },
        editorFocus: 1,
        contextSensitive: !!e.context,
        state: CKEDITOR.TRISTATE_DISABLED
    }), CKEDITOR.event.call(this)
}, CKEDITOR.command.prototype = {
    enable: function() {
        this.state == CKEDITOR.TRISTATE_DISABLED && this.checkAllowed() && this.setState(this.preserveState && void 0 !== this.previousState ? this.previousState : CKEDITOR.TRISTATE_OFF)
    },
    disable: function() {
        this.setState(CKEDITOR.TRISTATE_DISABLED)
    },
    setState: function(t) {
        return this.state != t && (!(t != CKEDITOR.TRISTATE_DISABLED && !this.checkAllowed()) && (this.previousState = this.state, this.state = t, this.fire("state"), !0))
    },
    toggleState: function() {
        this.state == CKEDITOR.TRISTATE_OFF ? this.setState(CKEDITOR.TRISTATE_ON) : this.state == CKEDITOR.TRISTATE_ON && this.setState(CKEDITOR.TRISTATE_OFF)
    }
}, CKEDITOR.event.implementOn(CKEDITOR.command.prototype);