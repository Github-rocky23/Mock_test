delete CKEDITOR.loadFullCore, CKEDITOR.instances = {}, CKEDITOR.document = new CKEDITOR.dom.document(document), CKEDITOR.add = function(n) {
        CKEDITOR.instances[n.name] = n, n.on("focus", function() {
            CKEDITOR.currentInstance != n && (CKEDITOR.currentInstance = n, CKEDITOR.fire("currentInstance"))
        }), n.on("blur", function() {
            CKEDITOR.currentInstance == n && (CKEDITOR.currentInstance = null, CKEDITOR.fire("currentInstance"))
        }), CKEDITOR.fire("instance", null, n)
    }, CKEDITOR.remove = function(n) {
        delete CKEDITOR.instances[n.name]
    },
    function() {
        var n = {};
        CKEDITOR.addTemplate = function(e, t) {
            var T = n[e];
            if (T) return T;
            var r = {
                name: e,
                source: t
            };
            return CKEDITOR.fire("template", r), n[e] = new CKEDITOR.template(r.source)
        }, CKEDITOR.getTemplate = function(e) {
            return n[e]
        }
    }(),
    function() {
        var n = [];
        CKEDITOR.addCss = function(e) {
            n.push(e)
        }, CKEDITOR.getCss = function() {
            return n.join("\n")
        }
    }(), CKEDITOR.on("instanceDestroyed", function() {
        CKEDITOR.tools.isEmpty(this.instances) && CKEDITOR.fire("reset")
    }), CKEDITOR.loader.load("_bootstrap"), CKEDITOR.TRISTATE_ON = 1, CKEDITOR.TRISTATE_OFF = 2, CKEDITOR.TRISTATE_DISABLED = 0;