CKEDITOR.dom.document = function(e) {
    CKEDITOR.dom.domObject.call(this, e)
}, CKEDITOR.dom.document.prototype = new CKEDITOR.dom.domObject, CKEDITOR.tools.extend(CKEDITOR.dom.document.prototype, {
    type: CKEDITOR.NODE_DOCUMENT,
    appendStyleSheet: function(e) {
        if (this.$.createStyleSheet) this.$.createStyleSheet(e);
        else {
            var t = new CKEDITOR.dom.element("link");
            t.setAttributes({
                rel: "stylesheet",
                type: "text/css",
                href: e
            }), this.getHead().append(t)
        }
    },
    appendStyleText: function(e) {
        if (this.$.createStyleSheet) {
            var t = this.$.createStyleSheet("");
            t.cssText = e
        } else {
            var n = new CKEDITOR.dom.element("style", this);
            n.append(new CKEDITOR.dom.text(e, this)), this.getHead().append(n)
        }
        return t || n.$.sheet
    },
    createElement: function(e, t) {
        var n = new CKEDITOR.dom.element(e, this);
        return t && (t.attributes && n.setAttributes(t.attributes), t.styles && n.setStyles(t.styles)), n
    },
    createText: function(e) {
        return new CKEDITOR.dom.text(e, this)
    },
    focus: function() {
        this.getWindow().focus()
    },
    getActive: function() {
        var e;
        try {
            e = this.$.activeElement
        } catch (e) {
            return null
        }
        return new CKEDITOR.dom.element(e)
    },
    getById: function(e) {
        var t = this.$.getElementById(e);
        return t ? new CKEDITOR.dom.element(t) : null
    },
    getByAddress: function(e, t) {
        for (var n = this.$.documentElement, i = 0; n && i < e.length; i++) {
            var o = e[i];
            if (t)
                for (var r = -1, s = 0; s < n.childNodes.length; s++) {
                    var l = n.childNodes[s];
                    if ((!0 !== t || 3 != l.nodeType || !l.previousSibling || 3 != l.previousSibling.nodeType) && ++r == o) {
                        n = l;
                        break
                    }
                } else n = n.childNodes[o]
        }
        return n ? new CKEDITOR.dom.node(n) : null
    },
    getElementsByTag: function(e, t) {
        return CKEDITOR.env.ie && document.documentMode <= 8 || !t || (e = t + ":" + e), new CKEDITOR.dom.nodeList(this.$.getElementsByTagName(e))
    },
    getHead: function() {
        var e = this.$.getElementsByTagName("head")[0];
        return e = e ? new CKEDITOR.dom.element(e) : this.getDocumentElement().append(new CKEDITOR.dom.element("head"), !0)
    },
    getBody: function() {
        return new CKEDITOR.dom.element(this.$.body)
    },
    getDocumentElement: function() {
        return new CKEDITOR.dom.element(this.$.documentElement)
    },
    getWindow: function() {
        return new CKEDITOR.dom.window(this.$.parentWindow || this.$.defaultView)
    },
    write: function(e) {
        this.$.open("text/html", "replace"), CKEDITOR.env.ie && (e = e.replace(/(?:^\s*<!DOCTYPE[^>]*?>)|^/i, '$&\n<script data-cke-temp="1">(' + CKEDITOR.tools.fixDomain + ")();<\/script>")), this.$.write(e), this.$.close()
    },
    find: function(e) {
        return new CKEDITOR.dom.nodeList(this.$.querySelectorAll(e))
    },
    findOne: function(e) {
        var t = this.$.querySelector(e);
        return t ? new CKEDITOR.dom.element(t) : null
    },
    _getHtml5ShivFrag: function() {
        var e = this.getCustomData("html5ShivFrag");
        return e || (e = this.$.createDocumentFragment(), CKEDITOR.tools.enableHtml5Elements(e, !0), this.setCustomData("html5ShivFrag", e)), e
    }
});