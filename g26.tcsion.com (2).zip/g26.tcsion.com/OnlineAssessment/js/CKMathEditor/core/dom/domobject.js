CKEDITOR.dom.domObject = function(t) {
        t && (this.$ = t)
    }, CKEDITOR.dom.domObject.prototype = {
        getPrivate: function() {
            var t;
            return (t = this.getCustomData("_")) || this.setCustomData("_", t = {}), t
        },
        on: function(t) {
            var e = this.getCustomData("_cke_nativeListeners");
            if (e || (e = {}, this.setCustomData("_cke_nativeListeners", e)), !e[t]) {
                var n = e[t] = function(t, e) {
                    return function(n) {
                        "undefined" != typeof CKEDITOR && t.fire(e, new CKEDITOR.dom.event(n))
                    }
                }(this, t);
                this.$.addEventListener ? this.$.addEventListener(t, n, !!CKEDITOR.event.useCapture) : this.$.attachEvent && this.$.attachEvent("on" + t, n)
            }
            return CKEDITOR.event.prototype.on.apply(this, arguments)
        },
        removeListener: function(t) {
            if (CKEDITOR.event.prototype.removeListener.apply(this, arguments), !this.hasListeners(t)) {
                var e = this.getCustomData("_cke_nativeListeners"),
                    n = e && e[t];
                n && (this.$.removeEventListener ? this.$.removeEventListener(t, n, !1) : this.$.detachEvent && this.$.detachEvent("on" + t, n), delete e[t])
            }
        },
        removeAllListeners: function() {
            var t = this.getCustomData("_cke_nativeListeners");
            for (var e in t) {
                var n = t[e];
                this.$.detachEvent ? this.$.detachEvent("on" + e, n) : this.$.removeEventListener && this.$.removeEventListener(e, n, !1), delete t[e]
            }
            CKEDITOR.event.prototype.removeAllListeners.call(this)
        }
    },
    function(t) {
        var e = {};
        CKEDITOR.on("reset", function() {
            e = {}
        }), t.equals = function(t) {
            try {
                return t && t.$ === this.$
            } catch (t) {
                return !1
            }
        }, t.setCustomData = function(t, n) {
            var i = this.getUniqueId();
            return (e[i] || (e[i] = {}))[t] = n, this
        }, t.getCustomData = function(t) {
            var n = this.$["data-cke-expando"],
                i = n && e[n];
            return i && t in i ? i[t] : null
        }, t.removeCustomData = function(t) {
            var n, i, s = this.$["data-cke-expando"],
                a = s && e[s];
            return a && (n = a[t], i = t in a, delete a[t]), i ? n : null
        }, t.clearCustomData = function() {
            this.removeAllListeners();
            var t = this.$["data-cke-expando"];
            t && delete e[t]
        }, t.getUniqueId = function() {
            return this.$["data-cke-expando"] || (this.$["data-cke-expando"] = CKEDITOR.tools.getNextNumber())
        }, CKEDITOR.event.implementOn(t)
    }(CKEDITOR.dom.domObject.prototype);