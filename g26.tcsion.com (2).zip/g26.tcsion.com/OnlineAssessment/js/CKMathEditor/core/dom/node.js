CKEDITOR.dom.node = function(e) {
    if (e) {
        var t = e.nodeType == CKEDITOR.NODE_DOCUMENT ? "document" : e.nodeType == CKEDITOR.NODE_ELEMENT ? "element" : e.nodeType == CKEDITOR.NODE_TEXT ? "text" : e.nodeType == CKEDITOR.NODE_COMMENT ? "comment" : e.nodeType == CKEDITOR.NODE_DOCUMENT_FRAGMENT ? "documentFragment" : "domObject";
        return new CKEDITOR.dom[t](e)
    }
    return this
}, CKEDITOR.dom.node.prototype = new CKEDITOR.dom.domObject, CKEDITOR.NODE_ELEMENT = 1, CKEDITOR.NODE_DOCUMENT = 9, CKEDITOR.NODE_TEXT = 3, CKEDITOR.NODE_COMMENT = 8, CKEDITOR.NODE_DOCUMENT_FRAGMENT = 11, CKEDITOR.POSITION_IDENTICAL = 0, CKEDITOR.POSITION_DISCONNECTED = 1, CKEDITOR.POSITION_FOLLOWING = 2, CKEDITOR.POSITION_PRECEDING = 4, CKEDITOR.POSITION_IS_CONTAINED = 8, CKEDITOR.POSITION_CONTAINS = 16, CKEDITOR.tools.extend(CKEDITOR.dom.node.prototype, {
    appendTo: function(e, t) {
        return e.append(this, t), e
    },
    clone: function(e, t) {
        var n = this.$.cloneNode(e);
        ! function n(r) {
            r["data-cke-expando"] && (r["data-cke-expando"] = !1);
            if (r.nodeType != CKEDITOR.NODE_ELEMENT && r.nodeType != CKEDITOR.NODE_DOCUMENT_FRAGMENT) return;
            t || r.nodeType != CKEDITOR.NODE_ELEMENT || r.removeAttribute("id", !1);
            if (e)
                for (var i = r.childNodes, o = 0; o < i.length; o++) n(i[o])
        }(n);
        var r = new CKEDITOR.dom.node(n);
        return CKEDITOR.env.ie && CKEDITOR.env.version < 9 && (this.type == CKEDITOR.NODE_ELEMENT || this.type == CKEDITOR.NODE_DOCUMENT_FRAGMENT) && function t(n) {
            if (n.type != CKEDITOR.NODE_ELEMENT && n.type != CKEDITOR.NODE_DOCUMENT_FRAGMENT) return;
            if (n.type != CKEDITOR.NODE_DOCUMENT_FRAGMENT) {
                var r = n.getName();
                ":" == r[0] && n.renameNode(r.substring(1))
            }
            if (e)
                for (var i = 0; i < n.getChildCount(); i++) t(n.getChild(i))
        }(r), r
    },
    hasPrevious: function() {
        return !!this.$.previousSibling
    },
    hasNext: function() {
        return !!this.$.nextSibling
    },
    insertAfter: function(e) {
        return e.$.parentNode.insertBefore(this.$, e.$.nextSibling), e
    },
    insertBefore: function(e) {
        return e.$.parentNode.insertBefore(this.$, e.$), e
    },
    insertBeforeMe: function(e) {
        return this.$.parentNode.insertBefore(e.$, this.$), e
    },
    getAddress: function(e) {
        for (var t = [], n = this.getDocument().$.documentElement, r = this.$; r && r != n;) {
            var i = r.parentNode;
            i && t.unshift(this.getIndex.call({
                $: r
            }, e)), r = i
        }
        return t
    },
    getDocument: function() {
        return new CKEDITOR.dom.document(this.$.ownerDocument || this.$.parentNode.ownerDocument)
    },
    getIndex: function(e) {
        var t, n = this.$,
            r = -1;
        if (!this.$.parentNode) return -1;
        if (e && n.nodeType == CKEDITOR.NODE_TEXT && o(n) && !(i(n) || i(n, !0))) return -1;
        do {
            e && n != this.$ && n.nodeType == CKEDITOR.NODE_TEXT && (t || o(n)) || (r++, t = n.nodeType == CKEDITOR.NODE_TEXT)
        } while (n = n.previousSibling);
        return r;

        function i(e, t) {
            var n = t ? e.nextSibling : e.previousSibling;
            return n && n.nodeType == CKEDITOR.NODE_TEXT ? o(n) ? i(n, t) : n : null
        }

        function o(e) {
            return !e.nodeValue || e.nodeValue == CKEDITOR.dom.selection.FILLING_CHAR_SEQUENCE
        }
    },
    getNextSourceNode: function(e, t, n) {
        if (n && !n.call) {
            var r = n;
            n = function(e) {
                return !e.equals(r)
            }
        }
        var i, o = !e && this.getFirst && this.getFirst();
        if (!o) {
            if (this.type == CKEDITOR.NODE_ELEMENT && n && !1 === n(this, !0)) return null;
            o = this.getNext()
        }
        for (; !o && (i = (i || this).getParent());) {
            if (n && !1 === n(i, !0)) return null;
            o = i.getNext()
        }
        return o ? n && !1 === n(o) ? null : t && t != o.type ? o.getNextSourceNode(!1, t, n) : o : null
    },
    getPreviousSourceNode: function(e, t, n) {
        if (n && !n.call) {
            var r = n;
            n = function(e) {
                return !e.equals(r)
            }
        }
        var i, o = !e && this.getLast && this.getLast();
        if (!o) {
            if (this.type == CKEDITOR.NODE_ELEMENT && n && !1 === n(this, !0)) return null;
            o = this.getPrevious()
        }
        for (; !o && (i = (i || this).getParent());) {
            if (n && !1 === n(i, !0)) return null;
            o = i.getPrevious()
        }
        return o ? n && !1 === n(o) ? null : t && o.type != t ? o.getPreviousSourceNode(!1, t, n) : o : null
    },
    getPrevious: function(e) {
        var t, n = this.$;
        do {
            t = (n = n.previousSibling) && 10 != n.nodeType && new CKEDITOR.dom.node(n)
        } while (t && e && !e(t));
        return t
    },
    getNext: function(e) {
        var t, n = this.$;
        do {
            t = (n = n.nextSibling) && new CKEDITOR.dom.node(n)
        } while (t && e && !e(t));
        return t
    },
    getParent: function(e) {
        var t = this.$.parentNode;
        return t && (t.nodeType == CKEDITOR.NODE_ELEMENT || e && t.nodeType == CKEDITOR.NODE_DOCUMENT_FRAGMENT) ? new CKEDITOR.dom.node(t) : null
    },
    getParents: function(e) {
        var t = this,
            n = [];
        do {
            n[e ? "push" : "unshift"](t)
        } while (t = t.getParent());
        return n
    },
    getCommonAncestor: function(e) {
        if (e.equals(this)) return this;
        if (e.contains && e.contains(this)) return e;
        var t = this.contains ? this : this.getParent();
        do {
            if (t.contains(e)) return t
        } while (t = t.getParent());
        return null
    },
    getPosition: function(e) {
        var t = this.$,
            n = e.$;
        if (t.compareDocumentPosition) return t.compareDocumentPosition(n);
        if (t == n) return CKEDITOR.POSITION_IDENTICAL;
        if (this.type == CKEDITOR.NODE_ELEMENT && e.type == CKEDITOR.NODE_ELEMENT) {
            if (t.contains) {
                if (t.contains(n)) return CKEDITOR.POSITION_CONTAINS + CKEDITOR.POSITION_PRECEDING;
                if (n.contains(t)) return CKEDITOR.POSITION_IS_CONTAINED + CKEDITOR.POSITION_FOLLOWING
            }
            if ("sourceIndex" in t) return t.sourceIndex < 0 || n.sourceIndex < 0 ? CKEDITOR.POSITION_DISCONNECTED : t.sourceIndex < n.sourceIndex ? CKEDITOR.POSITION_PRECEDING : CKEDITOR.POSITION_FOLLOWING
        }
        for (var r = this.getAddress(), i = e.getAddress(), o = Math.min(r.length, i.length), E = 0; E < o; E++)
            if (r[E] != i[E]) return r[E] < i[E] ? CKEDITOR.POSITION_PRECEDING : CKEDITOR.POSITION_FOLLOWING;
        return r.length < i.length ? CKEDITOR.POSITION_CONTAINS + CKEDITOR.POSITION_PRECEDING : CKEDITOR.POSITION_IS_CONTAINED + CKEDITOR.POSITION_FOLLOWING
    },
    getAscendant: function(e, t) {
        var n, r, i = this.$;
        for (t || (i = i.parentNode), "function" == typeof e ? (r = !0, n = e) : (r = !1, n = function(t) {
                var n = "string" == typeof t.nodeName ? t.nodeName.toLowerCase() : "";
                return "string" == typeof e ? n == e : n in e
            }); i;) {
            if (n(r ? new CKEDITOR.dom.node(i) : i)) return new CKEDITOR.dom.node(i);
            try {
                i = i.parentNode
            } catch (e) {
                i = null
            }
        }
        return null
    },
    hasAscendant: function(e, t) {
        var n = this.$;
        for (t || (n = n.parentNode); n;) {
            if (n.nodeName && n.nodeName.toLowerCase() == e) return !0;
            n = n.parentNode
        }
        return !1
    },
    move: function(e, t) {
        e.append(this.remove(), t)
    },
    remove: function(e) {
        var t = this.$,
            n = t.parentNode;
        if (n) {
            if (e)
                for (var r; r = t.firstChild;) n.insertBefore(t.removeChild(r), t);
            n.removeChild(t)
        }
        return this
    },
    replace: function(e) {
        this.insertBefore(e), e.remove()
    },
    trim: function() {
        this.ltrim(), this.rtrim()
    },
    ltrim: function() {
        for (var e; this.getFirst && (e = this.getFirst());) {
            if (e.type == CKEDITOR.NODE_TEXT) {
                var t = CKEDITOR.tools.ltrim(e.getText()),
                    n = e.getLength();
                if (!t) {
                    e.remove();
                    continue
                }
                t.length < n && (e.split(n - t.length), this.$.removeChild(this.$.firstChild))
            }
            break
        }
    },
    rtrim: function() {
        for (var e; this.getLast && (e = this.getLast());) {
            if (e.type == CKEDITOR.NODE_TEXT) {
                var t = CKEDITOR.tools.rtrim(e.getText()),
                    n = e.getLength();
                if (!t) {
                    e.remove();
                    continue
                }
                t.length < n && (e.split(t.length), this.$.lastChild.parentNode.removeChild(this.$.lastChild))
            }
            break
        }
        CKEDITOR.env.needsBrFiller && (e = this.$.lastChild) && 1 == e.type && "br" == e.nodeName.toLowerCase() && e.parentNode.removeChild(e)
    },
    isReadOnly: function(e) {
        var t = this;
        if (this.type != CKEDITOR.NODE_ELEMENT && (t = this.getParent()), CKEDITOR.env.edge && t && t.is("textarea", "input") && (e = !0), !e && t && void 0 !== t.$.isContentEditable) return !(t.$.isContentEditable || t.data("cke-editable"));
        for (; t;) {
            if (t.data("cke-editable")) return !1;
            if (t.hasAttribute("contenteditable")) return "false" == t.getAttribute("contenteditable");
            t = t.getParent()
        }
        return !0
    }
});