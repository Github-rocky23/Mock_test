"use strict";
! function() {
    function e(e) {
        arguments.length < 1 || (this.range = e, this.forceBrBreak = 0, this.enlargeBr = 1, this.enforceRealBlocks = 0, this._ || (this._ = {}))
    }
    var t = /^[\r\n\t ]+$/,
        r = CKEDITOR.dom.walker.bookmark(!1, !0),
        n = CKEDITOR.dom.walker.whitespaces(!0),
        a = function(e) {
            return r(e) && n(e)
        },
        i = {
            dd: 1,
            dt: 1,
            li: 1
        };

    function o(e, t) {
        var r, n;
        for (null == t && (r = [], e.forEach(function(e) {
                if ("true" == e.getAttribute("contenteditable")) return r.push(e), !1
            }, CKEDITOR.NODE_ELEMENT, !0), t = r); n = t.shift();)
            if (s(n)) return {
                element: n,
                remaining: t
            };
        return null
    }

    function s(e) {
        return e.getDtd().p
    }

    function l(e, t, r, n) {
        var a = o(r, n);
        if (!a) return 0;
        var i = CKEDITOR.filter.instances[a.element.data("cke-filter")];
        if (i && !i.check(t)) return l(e, t, r, a.remaining);
        var s = new CKEDITOR.dom.range(a.element);
        s.selectNodeContents(a.element);
        var c = s.createIterator();
        return c.enlargeBr = e.enlargeBr, c.enforceRealBlocks = e.enforceRealBlocks, c.activeFilter = c.filter = i, e._.nestedEditable = {
            element: a.element,
            container: r,
            remaining: a.remaining,
            iterator: c
        }, 1
    }

    function c(e, t, r) {
        if (!t) return !1;
        var n = e.clone();
        return n.collapse(!r), n.checkBoundaryOfElement(t, r ? CKEDITOR.START : CKEDITOR.END)
    }
    e.prototype = {
        getNextParagraph: function(e) {
            var n, o, s, d, E;
            if (e = e || "p", this._.nestedEditable) {
                if (n = this._.nestedEditable.iterator.getNextParagraph(e)) return this.activeFilter = this._.nestedEditable.iterator.activeFilter, n;
                if (this.activeFilter = this.filter, l(this, e, this._.nestedEditable.container, this._.nestedEditable.remaining)) return this.activeFilter = this._.nestedEditable.iterator.activeFilter, this._.nestedEditable.iterator.getNextParagraph(e);
                this._.nestedEditable = null
            }
            if (!this.range.root.getDtd()[e]) return null;
            this._.started || (o = function() {
                var e, t = this.range.clone(),
                    r = t.startPath(),
                    n = t.endPath(),
                    a = !t.collapsed && c(t, r.block),
                    i = !t.collapsed && c(t, n.block, 1);
                t.shrink(CKEDITOR.SHRINK_ELEMENT, !0), a && t.setStartAt(r.block, CKEDITOR.POSITION_BEFORE_END);
                i && t.setEndAt(n.block, CKEDITOR.POSITION_AFTER_START);
                if (e = t.endContainer.hasAscendant("pre", !0) || t.startContainer.hasAscendant("pre", !0), t.enlarge(this.forceBrBreak && !e || !this.enlargeBr ? CKEDITOR.ENLARGE_LIST_ITEM_CONTENTS : CKEDITOR.ENLARGE_BLOCK_CONTENTS), !t.collapsed) {
                    var o = new CKEDITOR.dom.walker(t.clone()),
                        s = CKEDITOR.dom.walker.bookmark(!0, !0);
                    o.evaluator = s, this._.nextNode = o.next(), (o = new CKEDITOR.dom.walker(t.clone())).evaluator = s;
                    var l = o.previous();
                    if (this._.lastNode = l.getNextSourceNode(!0, null, t.root), this._.lastNode && this._.lastNode.type == CKEDITOR.NODE_TEXT && !CKEDITOR.tools.trim(this._.lastNode.getText()) && this._.lastNode.getParent().isBlockBoundary()) {
                        var d = this.range.clone();
                        if (d.moveToPosition(this._.lastNode, CKEDITOR.POSITION_AFTER_END), d.checkEndOfBlock()) {
                            var E = new CKEDITOR.dom.elementPath(d.endContainer, d.root),
                                h = E.block || E.blockLimit;
                            this._.lastNode = h.getNextSourceNode(!0)
                        }
                    }
                    this._.lastNode && t.root.contains(this._.lastNode) || (this._.lastNode = this._.docEndMarker = t.document.createText(""), this._.lastNode.insertAfter(l)), t = null
                }
                return this._.started = 1, t
            }.call(this));
            var h = this._.nextNode,
                N = this._.lastNode;
            for (this._.nextNode = null; h;) {
                var u = 0,
                    T = h.hasAscendant("pre"),
                    f = h.type != CKEDITOR.NODE_ELEMENT,
                    O = 0;
                if (f) h.type == CKEDITOR.NODE_TEXT && t.test(h.getText()) && (f = 0);
                else {
                    var _ = h.getName();
                    if (CKEDITOR.dtd.$block[_] && "false" == h.getAttribute("contenteditable")) {
                        l(this, e, n = h);
                        break
                    }
                    if (h.isBlockBoundary(this.forceBrBreak && !T && {
                            br: 1
                        })) {
                        if ("br" == _) f = 1;
                        else if (!o && !h.getChildCount() && "hr" != _) {
                            n = h, s = h.equals(N);
                            break
                        }
                        o && (o.setEndAt(h, CKEDITOR.POSITION_BEFORE_START), "br" != _ && (this._.nextNode = h)), u = 1
                    } else {
                        if (h.getFirst()) {
                            o || (o = this.range.clone()).setStartAt(h, CKEDITOR.POSITION_BEFORE_START), h = h.getFirst();
                            continue
                        }
                        f = 1
                    }
                }
                if (f && !o && (o = this.range.clone()).setStartAt(h, CKEDITOR.POSITION_BEFORE_START), s = (!u || f) && h.equals(N), o && !u)
                    for (; !h.getNext(a) && !s;) {
                        var g = h.getParent();
                        if (g.isBlockBoundary(this.forceBrBreak && !T && {
                                br: 1
                            })) {
                            u = 1, f = 0, s = s || g.equals(N), o.setEndAt(g, CKEDITOR.POSITION_BEFORE_END);
                            break
                        }
                        f = 1, s = (h = g).equals(N), O = 1
                    }
                if (f && o.setEndAt(h, CKEDITOR.POSITION_AFTER_END), (s = !(h = this._getNextSourceNode(h, O, N))) || u && o) break
            }
            if (!n) {
                if (!o) return this._.docEndMarker && this._.docEndMarker.remove(), this._.nextNode = null, null;
                var k = new CKEDITOR.dom.elementPath(o.startContainer, o.root),
                    I = k.blockLimit;
                if (!(n = k.block) && I && !this.enforceRealBlocks && {
                        div: 1,
                        th: 1,
                        td: 1
                    }[I.getName()] && o.checkStartOfBlock() && o.checkEndOfBlock() && !I.equals(o.root)) n = I;
                else if (!n || this.enforceRealBlocks && n.is(i)) n = this.range.document.createElement(e), o.extractContents().appendTo(n), n.trim(), o.insertNode(n), d = E = !0;
                else if ("li" != n.getName()) {
                    if (!o.checkStartOfBlock() || !o.checkEndOfBlock()) {
                        n = n.clone(!1), o.extractContents().appendTo(n), n.trim();
                        var R = o.splitBlock();
                        d = !R.wasStartOfBlock, E = !R.wasEndOfBlock, o.insertNode(n)
                    }
                } else s || (this._.nextNode = n.equals(N) ? null : this._getNextSourceNode(o.getBoundaryNodes().endNode, 1, N))
            }
            if (d) {
                var C = n.getPrevious();
                C && C.type == CKEDITOR.NODE_ELEMENT && ("br" == C.getName() ? C.remove() : C.getLast() && "br" == C.getLast().$.nodeName.toLowerCase() && C.getLast().remove())
            }
            if (E) {
                var D = n.getLast();
                D && D.type == CKEDITOR.NODE_ELEMENT && "br" == D.getName() && (!CKEDITOR.env.needsBrFiller || D.getPrevious(r) || D.getNext(r)) && D.remove()
            }
            return this._.nextNode || (this._.nextNode = s || n.equals(N) || !N ? null : this._getNextSourceNode(n, 1, N)), n
        },
        _getNextSourceNode: function(e, t, n) {
            var a, i = this.range.root;

            function o(e) {
                return !(e.equals(n) || e.equals(i))
            }
            for (a = e.getNextSourceNode(t, null, o); !r(a);) a = a.getNextSourceNode(t, null, o);
            return a
        }
    }, CKEDITOR.dom.range.prototype.createIterator = function() {
        return new e(this)
    }
}();