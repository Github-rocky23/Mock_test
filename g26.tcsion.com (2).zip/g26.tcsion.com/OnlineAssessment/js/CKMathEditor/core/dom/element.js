CKEDITOR.dom.element = function(t, e) {
        "string" == typeof t && (t = (e ? e.$ : document).createElement(t)), CKEDITOR.dom.domObject.call(this, t)
    }, CKEDITOR.dom.element.get = function(t) {
        var e = "string" == typeof t ? document.getElementById(t) || document.getElementsByName(t)[0] : t;
        return e && (e.$ ? e : new CKEDITOR.dom.element(e))
    }, CKEDITOR.dom.element.prototype = new CKEDITOR.dom.node, CKEDITOR.dom.element.createFromHtml = function(t, e) {
        var i = new CKEDITOR.dom.element("div", e);
        return i.setHtml(t), i.getFirst().remove()
    }, CKEDITOR.dom.element.setMarker = function(t, e, i, n) {
        var r = e.getCustomData("list_marker_id") || e.setCustomData("list_marker_id", CKEDITOR.tools.getNextNumber()).getCustomData("list_marker_id"),
            s = e.getCustomData("list_marker_names") || e.setCustomData("list_marker_names", {}).getCustomData("list_marker_names");
        return t[r] = e, s[i] = 1, e.setCustomData(i, n)
    }, CKEDITOR.dom.element.clearAllMarkers = function(t) {
        for (var e in t) CKEDITOR.dom.element.clearMarkers(t, t[e], 1)
    }, CKEDITOR.dom.element.clearMarkers = function(t, e, i) {
        var n = e.getCustomData("list_marker_names"),
            r = e.getCustomData("list_marker_id");
        for (var s in n) e.removeCustomData(s);
        e.removeCustomData("list_marker_names"), i && (e.removeCustomData("list_marker_id"), delete t[r])
    },
    function() {
        var t, e, i = document.createElement("_").classList,
            n = void 0 !== i && null !== String(i.add).match(/\[Native code\]/gi),
            r = /[\n\t\r]/g;

        function s(t, e) {
            return (" " + t + " ").replace(r, " ").indexOf(" " + e + " ") > -1
        }

        function o(t) {
            var e = !0;
            return t.$.id || (t.$.id = "cke_tmp_" + CKEDITOR.tools.getNextNumber(), e = !1),
                function() {
                    e || t.removeAttribute("id")
                }
        }

        function a(t, e) {
            var i = CKEDITOR.tools.escapeCss(t.$.id);
            return "#" + i + " " + e.split(/,\s*/).join(", #" + i + " ")
        }
        CKEDITOR.tools.extend(CKEDITOR.dom.element.prototype, {
            type: CKEDITOR.NODE_ELEMENT,
            addClass: n ? function(t) {
                return this.$.classList.add(t), this
            } : function(t) {
                var e = this.$.className;
                return e && (s(e, t) || (e += " " + t)), this.$.className = e || t, this
            },
            removeClass: n ? function(t) {
                var e = this.$;
                return e.classList.remove(t), e.className || e.removeAttribute("class"), this
            } : function(t) {
                var e = this.getAttribute("class");
                return e && s(e, t) && ((e = e.replace(new RegExp("(?:^|\\s+)" + t + "(?=\\s|$)"), "").replace(/^\s+/, "")) ? this.setAttribute("class", e) : this.removeAttribute("class")), this
            },
            hasClass: function(t) {
                return s(this.$.className, t)
            },
            append: function(t, e) {
                return "string" == typeof t && (t = this.getDocument().createElement(t)), e ? this.$.insertBefore(t.$, this.$.firstChild) : this.$.appendChild(t.$), t
            },
            appendHtml: function(t) {
                if (this.$.childNodes.length) {
                    var e = new CKEDITOR.dom.element("div", this.getDocument());
                    e.setHtml(t), e.moveChildren(this)
                } else this.setHtml(t)
            },
            appendText: function(t) {
                null != this.$.text && CKEDITOR.env.ie && CKEDITOR.env.version < 9 ? this.$.text += t : this.append(new CKEDITOR.dom.text(t))
            },
            appendBogus: function(t) {
                if (t || CKEDITOR.env.needsBrFiller) {
                    for (var e = this.getLast(); e && e.type == CKEDITOR.NODE_TEXT && !CKEDITOR.tools.rtrim(e.getText());) e = e.getPrevious();
                    if (!e || !e.is || !e.is("br")) {
                        var i = this.getDocument().createElement("br");
                        CKEDITOR.env.gecko && i.setAttribute("type", "_moz"), this.append(i)
                    }
                }
            },
            breakParent: function(t, e) {
                var i = new CKEDITOR.dom.range(this.getDocument());
                i.setStartAfter(this), i.setEndAfter(t);
                var n, r, s = i.extractContents(!1, e || !1);
                if (i.insertNode(this.remove()), CKEDITOR.env.ie && !CKEDITOR.env.edge) {
                    for (n = new CKEDITOR.dom.element("div"); r = s.getFirst();) r.$.style.backgroundColor && (r.$.style.backgroundColor = r.$.style.backgroundColor), n.append(r);
                    n.insertAfter(this), n.remove(!0)
                } else s.insertAfterNode(this)
            },
            contains: document.compareDocumentPosition ? function(t) {
                return !!(16 & this.$.compareDocumentPosition(t.$))
            } : function(t) {
                var e = this.$;
                return t.type != CKEDITOR.NODE_ELEMENT ? e.contains(t.getParent().$) : e != t.$ && e.contains(t.$)
            },
            focus: function() {
                function t() {
                    try {
                        this.$.focus()
                    } catch (t) {}
                }
                return function(e) {
                    e ? CKEDITOR.tools.setTimeout(t, 100, this) : t.call(this)
                }
            }(),
            getHtml: function() {
                var t = this.$.innerHTML;
                return CKEDITOR.env.ie ? t.replace(/<\?[^>]*>/g, "") : t
            },
            getOuterHtml: function() {
                if (this.$.outerHTML) return this.$.outerHTML.replace(/<\?[^>]*>/, "");
                var t = this.$.ownerDocument.createElement("div");
                return t.appendChild(this.$.cloneNode(!0)), t.innerHTML
            },
            getClientRect: function(t) {
                var e = CKEDITOR.tools.extend({}, this.$.getBoundingClientRect());
                return !e.width && (e.width = e.right - e.left), !e.height && (e.height = e.bottom - e.top), t ? CKEDITOR.tools.getAbsoluteRectPosition(this.getWindow(), e) : e
            },
            setHtml: CKEDITOR.env.ie && CKEDITOR.env.version < 9 ? function(t) {
                try {
                    var e = this.$;
                    if (this.getParent()) return e.innerHTML = t;
                    var i = this.getDocument()._getHtml5ShivFrag();
                    return i.appendChild(e), e.innerHTML = t, i.removeChild(e), t
                } catch (e) {
                    this.$.innerHTML = "";
                    var n = new CKEDITOR.dom.element("body", this.getDocument());
                    n.$.innerHTML = t;
                    for (var r = n.getChildren(); r.count();) this.append(r.getItem(0));
                    return t
                }
            } : function(t) {
                return this.$.innerHTML = t
            },
            setText: (e = document.createElement("p"), e.innerHTML = "x", e = e.textContent, function(t) {
                this.$[e ? "textContent" : "innerText"] = t
            }),
            getAttribute: (t = function(t) {
                return this.$.getAttribute(t, 2)
            }, CKEDITOR.env.ie && (CKEDITOR.env.ie7Compat || CKEDITOR.env.quirks) ? function(e) {
                switch (e) {
                    case "class":
                        e = "className";
                        break;
                    case "http-equiv":
                        e = "httpEquiv";
                        break;
                    case "name":
                        return this.$.name;
                    case "tabindex":
                        var i = t.call(this, e);
                        return 0 !== i && 0 === this.$.tabIndex && (i = null), i;
                    case "checked":
                        var n = this.$.attributes.getNamedItem(e);
                        return (n.specified ? n.nodeValue : this.$.checked) ? "checked" : null;
                    case "hspace":
                    case "value":
                        return this.$[e];
                    case "style":
                        return this.$.style.cssText;
                    case "contenteditable":
                    case "contentEditable":
                        return this.$.attributes.getNamedItem("contentEditable").specified ? this.$.getAttribute("contentEditable") : null
                }
                return t.call(this, e)
            } : t),
            getAttributes: function(t) {
                var e, i = {},
                    n = this.$.attributes;
                for (t = CKEDITOR.tools.isArray(t) ? t : [], e = 0; e < n.length; e++) - 1 === CKEDITOR.tools.indexOf(t, n[e].name) && (i[n[e].name] = n[e].value);
                return i
            },
            getChildren: function() {
                return new CKEDITOR.dom.nodeList(this.$.childNodes)
            },
            getComputedStyle: document.defaultView && document.defaultView.getComputedStyle ? function(t) {
                var e = this.getWindow().$.getComputedStyle(this.$, null);
                return e ? e.getPropertyValue(t) : ""
            } : function(t) {
                return this.$.currentStyle[CKEDITOR.tools.cssStyleToDomStyle(t)]
            },
            getDtd: function() {
                var t = CKEDITOR.dtd[this.getName()];
                return this.getDtd = function() {
                    return t
                }, t
            },
            getElementsByTag: CKEDITOR.dom.document.prototype.getElementsByTag,
            getTabIndex: function() {
                var t = this.$.tabIndex;
                return 0 !== t || CKEDITOR.dtd.$tabIndex[this.getName()] || 0 === parseInt(this.getAttribute("tabindex"), 10) ? t : -1
            },
            getText: function() {
                return this.$.textContent || this.$.innerText || ""
            },
            getWindow: function() {
                return this.getDocument().getWindow()
            },
            getId: function() {
                return this.$.id || null
            },
            getNameAtt: function() {
                return this.$.name || null
            },
            getName: function() {
                var t = this.$.nodeName.toLowerCase();
                if (CKEDITOR.env.ie && document.documentMode <= 8) {
                    var e = this.$.scopeName;
                    "HTML" != e && (t = e.toLowerCase() + ":" + t)
                }
                return this.getName = function() {
                    return t
                }, this.getName()
            },
            getValue: function() {
                return this.$.value
            },
            getFirst: function(t) {
                var e = this.$.firstChild,
                    i = e && new CKEDITOR.dom.node(e);
                return i && t && !t(i) && (i = i.getNext(t)), i
            },
            getLast: function(t) {
                var e = this.$.lastChild,
                    i = e && new CKEDITOR.dom.node(e);
                return i && t && !t(i) && (i = i.getPrevious(t)), i
            },
            getStyle: function(t) {
                return this.$.style[CKEDITOR.tools.cssStyleToDomStyle(t)]
            },
            is: function() {
                var t = this.getName();
                if ("object" == typeof arguments[0]) return !!arguments[0][t];
                for (var e = 0; e < arguments.length; e++)
                    if (arguments[e] == t) return !0;
                return !1
            },
            isEditable: function(t) {
                var e = this.getName();
                if (this.isReadOnly() || "none" == this.getComputedStyle("display") || "hidden" == this.getComputedStyle("visibility") || CKEDITOR.dtd.$nonEditable[e] || CKEDITOR.dtd.$empty[e] || this.is("a") && (this.data("cke-saved-name") || this.hasAttribute("name")) && !this.getChildCount()) return !1;
                if (!1 !== t) {
                    var i = CKEDITOR.dtd[e] || CKEDITOR.dtd.span;
                    return !(!i || !i["#"])
                }
                return !0
            },
            isIdentical: function(t) {
                var e = this.clone(0, 1),
                    i = t.clone(0, 1);
                if (e.removeAttributes(["_moz_dirty", "data-cke-expando", "data-cke-saved-href", "data-cke-saved-name"]), i.removeAttributes(["_moz_dirty", "data-cke-expando", "data-cke-saved-href", "data-cke-saved-name"]), e.$.isEqualNode) return e.$.style.cssText = CKEDITOR.tools.normalizeCssText(e.$.style.cssText), i.$.style.cssText = CKEDITOR.tools.normalizeCssText(i.$.style.cssText), e.$.isEqualNode(i.$);
                if (e = e.getOuterHtml(), i = i.getOuterHtml(), CKEDITOR.env.ie && CKEDITOR.env.version < 9 && this.is("a")) {
                    var n = this.getParent();
                    if (n.type == CKEDITOR.NODE_ELEMENT) {
                        var r = n.clone();
                        r.setHtml(e), e = r.getHtml(), r.setHtml(i), i = r.getHtml()
                    }
                }
                return e == i
            },
            isVisible: function() {
                var t, e, i = (this.$.offsetHeight || this.$.offsetWidth) && "hidden" != this.getComputedStyle("visibility");
                return i && CKEDITOR.env.webkit && !(t = this.getWindow()).equals(CKEDITOR.document.getWindow()) && (e = t.$.frameElement) && (i = new CKEDITOR.dom.element(e).isVisible()), !!i
            },
            isEmptyInlineRemoveable: function() {
                if (!CKEDITOR.dtd.$removeEmpty[this.getName()]) return !1;
                for (var t = this.getChildren(), e = 0, i = t.count(); e < i; e++) {
                    var n = t.getItem(e);
                    if ((n.type != CKEDITOR.NODE_ELEMENT || !n.data("cke-bookmark")) && (n.type == CKEDITOR.NODE_ELEMENT && !n.isEmptyInlineRemoveable() || n.type == CKEDITOR.NODE_TEXT && CKEDITOR.tools.trim(n.getText()))) return !1
                }
                return !0
            },
            hasAttributes: CKEDITOR.env.ie && (CKEDITOR.env.ie7Compat || CKEDITOR.env.quirks) ? function() {
                for (var t = this.$.attributes, e = 0; e < t.length; e++) {
                    var i = t[e];
                    switch (i.nodeName) {
                        case "class":
                            if (this.getAttribute("class")) return !0;
                        case "data-cke-expando":
                            continue;
                        default:
                            if (i.specified) return !0
                    }
                }
                return !1
            } : function() {
                var t = this.$.attributes,
                    e = t.length,
                    i = {
                        "data-cke-expando": 1,
                        _moz_dirty: 1
                    };
                return e > 0 && (e > 2 || !i[t[0].nodeName] || 2 == e && !i[t[1].nodeName])
            },
            hasAttribute: function() {
                function t(t) {
                    var e = this.$.attributes.getNamedItem(t);
                    if ("input" == this.getName()) switch (t) {
                        case "class":
                            return this.$.className.length > 0;
                        case "checked":
                            return !!this.$.checked;
                        case "value":
                            var i = this.getAttribute("type");
                            return "checkbox" == i || "radio" == i ? "on" != this.$.value : !!this.$.value
                    }
                    return !!e && e.specified
                }
                return CKEDITOR.env.ie ? CKEDITOR.env.version < 8 ? function(e) {
                    return "name" == e ? !!this.$.name : t.call(this, e)
                } : t : function(t) {
                    return !!this.$.attributes.getNamedItem(t)
                }
            }(),
            hide: function() {
                this.setStyle("display", "none")
            },
            moveChildren: function(t, e) {
                var i, n = this.$;
                if (n != (t = t.$))
                    if (e)
                        for (; i = n.lastChild;) t.insertBefore(n.removeChild(i), t.firstChild);
                    else
                        for (; i = n.firstChild;) t.appendChild(n.removeChild(i))
            },
            mergeSiblings: function() {
                function t(t, e, i) {
                    if (e && e.type == CKEDITOR.NODE_ELEMENT) {
                        for (var n = []; e.data("cke-bookmark") || e.isEmptyInlineRemoveable();)
                            if (n.push(e), !(e = i ? e.getNext() : e.getPrevious()) || e.type != CKEDITOR.NODE_ELEMENT) return;
                        if (t.isIdentical(e)) {
                            for (var r = i ? t.getLast() : t.getFirst(); n.length;) n.shift().move(t, !i);
                            e.moveChildren(t, !i), e.remove(), r && r.type == CKEDITOR.NODE_ELEMENT && r.mergeSiblings()
                        }
                    }
                }
                return function(e) {
                    (!1 === e || CKEDITOR.dtd.$removeEmpty[this.getName()] || this.is("a")) && (t(this, this.getNext(), !0), t(this, this.getPrevious()))
                }
            }(),
            show: function() {
                this.setStyles({
                    display: "",
                    visibility: ""
                })
            },
            setAttribute: function() {
                var t = function(t, e) {
                    return this.$.setAttribute(t, e), this
                };
                return CKEDITOR.env.ie && (CKEDITOR.env.ie7Compat || CKEDITOR.env.quirks) ? function(e, i) {
                    return "class" == e ? this.$.className = i : "style" == e ? this.$.style.cssText = i : "tabindex" == e ? this.$.tabIndex = i : "checked" == e ? this.$.checked = i : "contenteditable" == e ? t.call(this, "contentEditable", i) : t.apply(this, arguments), this
                } : CKEDITOR.env.ie8Compat && CKEDITOR.env.secure ? function(e, i) {
                    if ("src" == e && i.match(/^http:\/\//)) try {
                        t.apply(this, arguments)
                    } catch (t) {} else t.apply(this, arguments);
                    return this
                } : t
            }(),
            setAttributes: function(t) {
                for (var e in t) this.setAttribute(e, t[e]);
                return this
            },
            setValue: function(t) {
                return this.$.value = t, this
            },
            removeAttribute: function() {
                var t = function(t) {
                    this.$.removeAttribute(t)
                };
                return CKEDITOR.env.ie && (CKEDITOR.env.ie7Compat || CKEDITOR.env.quirks) ? function(e) {
                    "class" == e ? e = "className" : "tabindex" == e ? e = "tabIndex" : "contenteditable" == e && (e = "contentEditable"), t.call(this, e)
                } : t
            }(),
            removeAttributes: function(t) {
                if (CKEDITOR.tools.isArray(t))
                    for (var e = 0; e < t.length; e++) this.removeAttribute(t[e]);
                else
                    for (var i in t = t || this.getAttributes()) t.hasOwnProperty(i) && this.removeAttribute(i)
            },
            removeStyle: function(t) {
                var e = this.$.style;
                if (e.removeProperty || "border" != t && "margin" != t && "padding" != t) e.removeProperty ? e.removeProperty(t) : e.removeAttribute(CKEDITOR.tools.cssStyleToDomStyle(t)), this.$.style.cssText || this.removeAttribute("style");
                else
                    for (var i = function(t) {
                            var e, i = ["top", "left", "right", "bottom"];
                            "border" == t && (e = ["color", "style", "width"]);
                            for (var n = [], r = 0; r < i.length; r++)
                                if (e)
                                    for (var s = 0; s < e.length; s++) n.push([t, i[r], e[s]].join("-"));
                                else n.push([t, i[r]].join("-"));
                            return n
                        }(t), n = 0; n < i.length; n++) this.removeStyle(i[n])
            },
            setStyle: function(t, e) {
                return this.$.style[CKEDITOR.tools.cssStyleToDomStyle(t)] = e, this
            },
            setStyles: function(t) {
                for (var e in t) this.setStyle(e, t[e]);
                return this
            },
            setOpacity: function(t) {
                CKEDITOR.env.ie && CKEDITOR.env.version < 9 ? (t = Math.round(100 * t), this.setStyle("filter", t >= 100 ? "" : "progid:DXImageTransform.Microsoft.Alpha(opacity=" + t + ")")) : this.setStyle("opacity", t)
            },
            unselectable: function() {
                if (this.setStyles(CKEDITOR.tools.cssVendorPrefix("user-select", "none")), CKEDITOR.env.ie) {
                    this.setAttribute("unselectable", "on");
                    for (var t = this.getElementsByTag("*"), e = 0, i = t.count(); e < i; e++) t.getItem(e).setAttribute("unselectable", "on")
                }
            },
            getPositionedAncestor: function() {
                for (var t = this;
                    "html" != t.getName();) {
                    if ("static" != t.getComputedStyle("position")) return t;
                    t = t.getParent()
                }
                return null
            },
            getDocumentPosition: function(t) {
                var e = 0,
                    i = 0,
                    n = this.getDocument(),
                    r = n.getBody(),
                    s = "BackCompat" == n.$.compatMode;
                if (!document.documentElement.getBoundingClientRect || CKEDITOR.env.ie && 8 === CKEDITOR.env.version)
                    for (var o, a = this, l = null; a && "body" != a.getName() && "html" != a.getName();) {
                        e += a.$.offsetLeft - a.$.scrollLeft, i += a.$.offsetTop - a.$.scrollTop, a.equals(this) || (e += a.$.clientLeft || 0, i += a.$.clientTop || 0);
                        for (var u = l; u && !u.equals(a);) e -= u.$.scrollLeft, i -= u.$.scrollTop, u = u.getParent();
                        l = a, a = (o = a.$.offsetParent) ? new CKEDITOR.dom.element(o) : null
                    } else {
                        var c = this.$.getBoundingClientRect(),
                            h = n.$.documentElement,
                            d = h.clientTop || r.$.clientTop || 0,
                            m = h.clientLeft || r.$.clientLeft || 0,
                            f = !0;
                        if (CKEDITOR.env.ie) {
                            var v = n.getDocumentElement().contains(this),
                                g = n.getBody().contains(this);
                            f = s && g || !s && v
                        }
                        if (f) {
                            var E, C;
                            if (CKEDITOR.env.webkit || CKEDITOR.env.ie && CKEDITOR.env.version >= 12) E = r.$.scrollLeft || h.scrollLeft, C = r.$.scrollTop || h.scrollTop;
                            else {
                                var T = s ? r.$ : h;
                                E = T.scrollLeft, C = T.scrollTop
                            }
                            e = c.left + E - m, i = c.top + C - d
                        }
                    }
                if (t) {
                    var D = this.getWindow(),
                        p = t.getWindow();
                    if (!D.equals(p) && D.$.frameElement) {
                        var $ = new CKEDITOR.dom.element(D.$.frameElement).getDocumentPosition(t);
                        e += $.x, i += $.y
                    }
                }
                return document.documentElement.getBoundingClientRect || CKEDITOR.env.gecko && !s && (e += this.$.clientLeft ? 1 : 0, i += this.$.clientTop ? 1 : 0), {
                    x: e,
                    y: i
                }
            },
            scrollIntoView: function(t) {
                var e = this.getParent();
                if (e)
                    do {
                        if ((e.$.clientWidth && e.$.clientWidth < e.$.scrollWidth || e.$.clientHeight && e.$.clientHeight < e.$.scrollHeight) && !e.is("body") && this.scrollIntoParent(e, t, 1), e.is("html")) {
                            var i = e.getWindow();
                            try {
                                var n = i.$.frameElement;
                                n && (e = new CKEDITOR.dom.element(n))
                            } catch (t) {}
                        }
                    } while (e = e.getParent())
            },
            scrollIntoParent: function(t, e, i) {
                !t && (t = this.getWindow());
                var n = t.getDocument(),
                    r = "BackCompat" == n.$.compatMode;

                function s(e, i) {
                    /body|html/.test(t.getName()) ? t.getWindow().$.scrollBy(e, i) : (t.$.scrollLeft += e, t.$.scrollTop += i)
                }

                function o(t, e) {
                    var i = {
                        x: 0,
                        y: 0
                    };
                    if (!t.is(r ? "body" : "html")) {
                        var n = t.$.getBoundingClientRect();
                        i.x = n.left, i.y = n.top
                    }
                    var s = t.getWindow();
                    if (!s.equals(e)) {
                        var a = o(CKEDITOR.dom.element.get(s.$.frameElement), e);
                        i.x += a.x, i.y += a.y
                    }
                    return i
                }

                function a(t, e) {
                    return parseInt(t.getComputedStyle("margin-" + e) || 0, 10) || 0
                }
                if (t instanceof CKEDITOR.dom.window && (t = r ? n.getBody() : n.getDocumentElement()), CKEDITOR.env.webkit) {
                    var l = this.getEditor(!1);
                    l && (l._.previousScrollTop = null)
                }
                var u, c, h = t.getWindow(),
                    d = o(this, h),
                    m = o(t, h),
                    f = this.$.offsetHeight,
                    v = this.$.offsetWidth,
                    g = t.$.clientHeight,
                    E = t.$.clientWidth;
                u = {
                    x: d.x - a(this, "left") - m.x || 0,
                    y: d.y - a(this, "top") - m.y || 0
                }, c = {
                    x: d.x + v + a(this, "right") - (m.x + E) || 0,
                    y: d.y + f + a(this, "bottom") - (m.y + g) || 0
                }, (u.y < 0 || c.y > 0) && s(0, !0 === e ? u.y : !1 === e ? c.y : u.y < 0 ? u.y : c.y), i && (u.x < 0 || c.x > 0) && s(u.x < 0 ? u.x : c.x, 0)
            },
            setState: function(t, e, i) {
                switch (e = e || "cke", t) {
                    case CKEDITOR.TRISTATE_ON:
                        this.addClass(e + "_on"), this.removeClass(e + "_off"), this.removeClass(e + "_disabled"), i && this.setAttribute("aria-pressed", !0), i && this.removeAttribute("aria-disabled");
                        break;
                    case CKEDITOR.TRISTATE_DISABLED:
                        this.addClass(e + "_disabled"), this.removeClass(e + "_off"), this.removeClass(e + "_on"), i && this.setAttribute("aria-disabled", !0), i && this.removeAttribute("aria-pressed");
                        break;
                    default:
                        this.addClass(e + "_off"), this.removeClass(e + "_on"), this.removeClass(e + "_disabled"), i && this.removeAttribute("aria-pressed"), i && this.removeAttribute("aria-disabled")
                }
            },
            getFrameDocument: function() {
                var t = this.$;
                try {
                    t.contentWindow.document
                } catch (e) {
                    t.src = t.src
                }
                return t && new CKEDITOR.dom.document(t.contentWindow.document)
            },
            copyAttributes: function(t, e) {
                var i = this.$.attributes;
                e = e || {};
                for (var n = 0; n < i.length; n++) {
                    var r, s = i[n],
                        o = s.nodeName.toLowerCase();
                    o in e || ("checked" == o && (r = this.getAttribute(o)) ? t.setAttribute(o, r) : CKEDITOR.env.ie && !this.hasAttribute(o) || (null === (r = this.getAttribute(o)) && (r = s.nodeValue), t.setAttribute(o, r)))
                }
                "" !== this.$.style.cssText && (t.$.style.cssText = this.$.style.cssText)
            },
            renameNode: function(t) {
                if (this.getName() != t) {
                    var e = this.getDocument(),
                        i = new CKEDITOR.dom.element(t, e);
                    this.copyAttributes(i), this.moveChildren(i), this.getParent(!0) && this.$.parentNode.replaceChild(i.$, this.$), i.$["data-cke-expando"] = this.$["data-cke-expando"], this.$ = i.$, delete this.getName
                }
            },
            getChild: function() {
                function t(t, e) {
                    var i = t.childNodes;
                    if (e >= 0 && e < i.length) return i[e]
                }
                return function(e) {
                    var i = this.$;
                    if (e.slice)
                        for (e = e.slice(); e.length > 0 && i;) i = t(i, e.shift());
                    else i = t(i, e);
                    return i ? new CKEDITOR.dom.node(i) : null
                }
            }(),
            getChildCount: function() {
                return this.$.childNodes.length
            },
            disableContextMenu: function() {
                function t(t) {
                    return t.type == CKEDITOR.NODE_ELEMENT && t.hasClass("cke_enable_context_menu")
                }
                this.on("contextmenu", function(e) {
                    e.data.getTarget().getAscendant(t, !0) || e.data.preventDefault()
                })
            },
            getDirection: function(t) {
                return t ? this.getComputedStyle("direction") || this.getDirection() || this.getParent() && this.getParent().getDirection(1) || this.getDocument().$.dir || "ltr" : this.getStyle("direction") || this.getAttribute("dir")
            },
            data: function(t, e) {
                return t = "data-" + t, void 0 === e ? this.getAttribute(t) : (!1 === e ? this.removeAttribute(t) : this.setAttribute(t, e), null)
            },
            getEditor: function(t) {
                var e, i, n, r = CKEDITOR.instances;
                for (e in t = t || void 0 === t, r) {
                    if ((i = r[e]).element.equals(this) && i.elementMode != CKEDITOR.ELEMENT_MODE_APPENDTO) return i;
                    if (!t && (n = i.editable()) && (n.equals(this) || n.contains(this))) return i
                }
                return null
            },
            find: function(t) {
                var e = o(this),
                    i = new CKEDITOR.dom.nodeList(this.$.querySelectorAll(a(this, t)));
                return e(), i
            },
            findOne: function(t) {
                var e = o(this),
                    i = this.$.querySelector(a(this, t));
                return e(), i ? new CKEDITOR.dom.element(i) : null
            },
            forEach: function(t, e, i) {
                if (!(i || e && this.type != e)) var n = t(this);
                if (!1 !== n)
                    for (var r, s = this.getChildren(), o = 0; o < s.count(); o++)(r = s.getItem(o)).type == CKEDITOR.NODE_ELEMENT ? r.forEach(t, e) : e && r.type != e || t(r)
            }
        });
        var l = {
            width: ["border-left-width", "border-right-width", "padding-left", "padding-right"],
            height: ["border-top-width", "border-bottom-width", "padding-top", "padding-bottom"]
        };

        function u(t) {
            for (var e = 0, i = 0, n = l[t].length; i < n; i++) e += parseFloat(this.getComputedStyle(l[t][i]) || 0, 10) || 0;
            return e
        }
        CKEDITOR.dom.element.prototype.setSize = function(t, e, i) {
            "number" == typeof e && (!i || CKEDITOR.env.ie && CKEDITOR.env.quirks || (e -= u.call(this, t)), this.setStyle(t, e + "px"))
        }, CKEDITOR.dom.element.prototype.getSize = function(t, e) {
            var i = Math.max(this.$["offset" + CKEDITOR.tools.capitalize(t)], this.$["client" + CKEDITOR.tools.capitalize(t)]) || 0;
            return e && (i -= u.call(this, t)), i
        }
    }();