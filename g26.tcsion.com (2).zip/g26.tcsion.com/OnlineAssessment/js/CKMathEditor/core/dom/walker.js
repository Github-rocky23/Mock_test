! function() {
    function t(t, e) {
        var r = this.range;
        if (this._.end) return null;
        if (!this._.start) {
            if (this._.start = 1, r.collapsed) return this.end(), null;
            r.optimize()
        }
        var n, i, o = r.startContainer,
            u = r.endContainer,
            a = r.startOffset,
            l = r.endOffset,
            E = this.guard,
            s = this.type,
            d = t ? "getPreviousSourceNode" : "getNextSourceNode";
        if (!t && !this._.guardLTR) {
            var c = u.type == CKEDITOR.NODE_ELEMENT ? u : u.getParent(),
                T = u.type == CKEDITOR.NODE_ELEMENT ? u.getChild(l) : u.getNext();
            this._.guardLTR = function(t, e) {
                return !(e && c.equals(t) || T && t.equals(T) || t.type == CKEDITOR.NODE_ELEMENT && e && t.equals(r.root))
            }
        }
        if (t && !this._.guardRTL) {
            var O = o.type == CKEDITOR.NODE_ELEMENT ? o : o.getParent(),
                f = o.type == CKEDITOR.NODE_ELEMENT ? a ? o.getChild(a - 1) : null : o.getPrevious();
            this._.guardRTL = function(t, e) {
                return !(e && O.equals(t) || f && t.equals(f) || t.type == CKEDITOR.NODE_ELEMENT && e && t.equals(r.root))
            }
        }
        var D = t ? this._.guardRTL : this._.guardLTR;
        for (i = E ? function(t, e) {
                return !1 !== D(t, e) && E(t, e)
            } : D, this.current ? n = this.current[d](!1, s, i) : (t ? (n = u).type == CKEDITOR.NODE_ELEMENT && (n = l > 0 ? n.getChild(l - 1) : !1 === i(n, !0) ? null : n.getPreviousSourceNode(!0, s, i)) : (n = o).type == CKEDITOR.NODE_ELEMENT && ((n = n.getChild(a)) || (n = !1 === i(o, !0) ? null : o.getNextSourceNode(!0, s, i))), n && !1 === i(n) && (n = null)); n && !this._.end;) {
            if (this.current = n, this.evaluator && !1 === this.evaluator(n)) {
                if (e && this.evaluator) return !1
            } else if (!e) return n;
            n = n[d](!1, s, i)
        }
        return this.end(), this.current = null
    }

    function e(e) {
        for (var r, n = null; r = t.call(this, e);) n = r;
        return n
    }
    CKEDITOR.dom.walker = CKEDITOR.tools.createClass({
        $: function(t) {
            this.range = t, this._ = {}
        },
        proto: {
            end: function() {
                this._.end = 1
            },
            next: function() {
                return t.call(this)
            },
            previous: function() {
                return t.call(this, 1)
            },
            checkForward: function() {
                return !1 !== t.call(this, 0, 1)
            },
            checkBackward: function() {
                return !1 !== t.call(this, 1, 1)
            },
            lastForward: function() {
                return e.call(this)
            },
            lastBackward: function() {
                return e.call(this, 1)
            },
            reset: function() {
                delete this.current, this._ = {}
            }
        }
    });
    var r = {
            block: 1,
            "list-item": 1,
            table: 1,
            "table-row-group": 1,
            "table-header-group": 1,
            "table-footer-group": 1,
            "table-row": 1,
            "table-column-group": 1,
            "table-column": 1,
            "table-cell": 1,
            "table-caption": 1
        },
        n = {
            absolute: 1,
            fixed: 1
        };
    CKEDITOR.dom.element.prototype.isBlockBoundary = function(t) {
        return !("none" != this.getComputedStyle("float") || this.getComputedStyle("position") in n || !r[this.getComputedStyle("display")]) || !!(this.is(CKEDITOR.dtd.$block) || t && this.is(t))
    }, CKEDITOR.dom.walker.blockBoundary = function(t) {
        return function(e) {
            return !(e.type == CKEDITOR.NODE_ELEMENT && e.isBlockBoundary(t))
        }
    }, CKEDITOR.dom.walker.listItemBoundary = function() {
        return this.blockBoundary({
            br: 1
        })
    }, CKEDITOR.dom.walker.bookmark = function(t, e) {
        function r(t) {
            return t && t.getName && "span" == t.getName() && t.data("cke-bookmark")
        }
        return function(n) {
            var i, o;
            return i = n && n.type != CKEDITOR.NODE_ELEMENT && (o = n.getParent()) && r(o), i = t ? i : i || r(n), !!(e ^ i)
        }
    }, CKEDITOR.dom.walker.whitespaces = function(t) {
        return function(e) {
            var r;
            return e && e.type == CKEDITOR.NODE_TEXT && (r = !CKEDITOR.tools.trim(e.getText()) || CKEDITOR.env.webkit && e.getText() == CKEDITOR.dom.selection.FILLING_CHAR_SEQUENCE), !!(t ^ r)
        }
    }, CKEDITOR.dom.walker.invisible = function(t) {
        var e = CKEDITOR.dom.walker.whitespaces(),
            r = CKEDITOR.env.webkit ? 1 : 0;
        return function(n) {
            var i;
            return e(n) ? i = 1 : (n.type == CKEDITOR.NODE_TEXT && (n = n.getParent()), i = n.$.offsetWidth <= r), !!(t ^ i)
        }
    }, CKEDITOR.dom.walker.nodeType = function(t, e) {
        return function(r) {
            return !!(e ^ r.type == t)
        }
    }, CKEDITOR.dom.walker.bogus = function(t) {
        function e(t) {
            return !o(t) && !u(t)
        }
        return function(r) {
            var n = CKEDITOR.env.needsBrFiller ? r.is && r.is("br") : r.getText && i.test(r.getText());
            if (n) {
                var o = r.getParent(),
                    u = r.getNext(e);
                n = o.isBlockBoundary() && (!u || u.type == CKEDITOR.NODE_ELEMENT && u.isBlockBoundary())
            }
            return !!(t ^ n)
        }
    }, CKEDITOR.dom.walker.temp = function(t) {
        return function(e) {
            e.type != CKEDITOR.NODE_ELEMENT && (e = e.getParent());
            var r = e && e.hasAttribute("data-cke-temp");
            return !!(t ^ r)
        }
    };
    var i = /^[\t\r\n ]*(?:&nbsp;|\xa0)$/,
        o = CKEDITOR.dom.walker.whitespaces(),
        u = CKEDITOR.dom.walker.bookmark(),
        a = CKEDITOR.dom.walker.temp();
    CKEDITOR.dom.walker.ignored = function(t) {
        return function(e) {
            var r = o(e) || u(e) || a(e);
            return !!(t ^ r)
        }
    };
    var l = CKEDITOR.dom.walker.ignored();
    CKEDITOR.dom.walker.empty = function(t) {
        return function(e) {
            for (var r = 0, n = e.getChildCount(); r < n; ++r)
                if (!l(e.getChild(r))) return !!t;
            return !t
        }
    };
    var E = CKEDITOR.dom.walker.empty();
    var s = CKEDITOR.dom.walker.validEmptyBlockContainers = CKEDITOR.tools.extend(function(t) {
        var e, r = {};
        for (e in t) CKEDITOR.dtd[e]["#"] && (r[e] = 1);
        return r
    }(CKEDITOR.dtd.$block), {
        caption: 1,
        td: 1,
        th: 1
    });
    CKEDITOR.dom.walker.editable = function(t) {
        return function(e) {
            return !!(t ^ function(t) {
                if (l(t)) return !1;
                if (t.type == CKEDITOR.NODE_TEXT) return !0;
                if (t.type == CKEDITOR.NODE_ELEMENT) {
                    if (t.is(CKEDITOR.dtd.$inline) || t.is("hr") || "false" == t.getAttribute("contenteditable")) return !0;
                    if (!CKEDITOR.env.needsBrFiller && t.is(s) && E(t)) return !0
                }
                return !1
            }(e))
        }
    }, CKEDITOR.dom.element.prototype.getBogus = function() {
        var t, e = this;
        do {
            e = e.getPreviousSourceNode()
        } while (u(t = e) || o(t) || t.type == CKEDITOR.NODE_ELEMENT && t.is(CKEDITOR.dtd.$inline) && !t.is(CKEDITOR.dtd.$empty));
        return !(!e || !(CKEDITOR.env.needsBrFiller ? e.is && e.is("br") : e.getText && i.test(e.getText()))) && e
    }
}();