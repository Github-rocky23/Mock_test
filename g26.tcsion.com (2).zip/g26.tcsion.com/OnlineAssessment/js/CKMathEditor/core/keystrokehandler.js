CKEDITOR.keystrokeHandler = function(e) {
        return e.keystrokeHandler ? e.keystrokeHandler : (this.keystrokes = {}, this.blockedKeystrokes = {}, this._ = {
            editor: e
        }, this)
    },
    function() {
        var e, t = function(t) {
                var o = (t = t.data).getKeystroke(),
                    r = this.keystrokes[o],
                    n = this._.editor;
                if (!(e = !1 === n.fire("key", {
                        keyCode: o,
                        domEvent: t
                    }))) {
                    if (r) {
                        e = !1 !== n.execCommand(r, {
                            from: "keystrokeHandler"
                        })
                    }
                    e || (e = !!this.blockedKeystrokes[o])
                }
                return e && t.preventDefault(!0), !e
            },
            o = function(t) {
                e && (e = !1, t.data.preventDefault(!0))
            };
        CKEDITOR.keystrokeHandler.prototype = {
            attach: function(e) {
                e.on("keydown", t, this), CKEDITOR.env.gecko && CKEDITOR.env.mac && e.on("keypress", o, this)
            }
        }
    }();