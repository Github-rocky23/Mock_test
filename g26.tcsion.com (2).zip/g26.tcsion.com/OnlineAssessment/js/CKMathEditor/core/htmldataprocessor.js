! function() {
    function e(e, t) {
        function n(e) {
            return e || CKEDITOR.env.needsNbspFiller ? new CKEDITOR.htmlParser.text("�") : new CKEDITOR.htmlParser.element("br", {
                "data-cke-bogus": 1
            })
        }

        function u(e, t) {
            return function(r) {
                r.type != CKEDITOR.NODE_DOCUMENT_FRAGMENT && (p(r), (!e || !1 !== ("function" == typeof t ? t(r) : t)) && m(r) && r.add(n(e)))
            }
        }

        function s(e, t) {
            if ((!h || CKEDITOR.env.needsBrFiller) && e.type == CKEDITOR.NODE_ELEMENT && "br" == e.name && !e.attributes["data-cke-eol"]) return !0;
            var n;
            if (e.type == CKEDITOR.NODE_TEXT && (n = e.value.match(r))) {
                if (n.index && (new CKEDITOR.htmlParser.text(e.value.substring(0, n.index)).insertBefore(e), e.value = n[0]), !CKEDITOR.env.needsBrFiller && h && (!t || e.parent.name in v)) return !0;
                if (!h) {
                    var a = e.previous;
                    if (a && "br" == a.name) return !0;
                    if (!a || l(a)) return !0
                }
            }
            return !1
        }

        function p(e) {
            var t, r, o = [],
                c = a(e);
            if (c)
                for (s(c, 1) && o.push(c); c;) l(c) && (t = i(c)) && s(t) && ((r = i(t)) && !l(r) ? o.push(t) : (n(h).insertAfter(t), t.remove())), c = c.previous;
            for (var u = 0; u < o.length; u++) o[u].remove()
        }

        function m(e) {
            if (!h && !CKEDITOR.env.needsBrFiller && e.type == CKEDITOR.NODE_DOCUMENT_FRAGMENT) return !1;
            if (!h && !CKEDITOR.env.needsBrFiller && (document.documentMode > 7 || e.name in CKEDITOR.dtd.tr || e.name in CKEDITOR.dtd.$listItem)) return !1;
            var t = a(e);
            return !t || "form" == e.name && "input" == t.name
        }
        var E = {
                elements: {}
            },
            h = "html" == t,
            v = CKEDITOR.tools.extend({}, f);
        for (var D in v) "#" in d[D] || delete v[D];
        for (D in v) E.elements[D] = u(h, e.config.fillEmptyBlocks);
        return E.root = u(h, !1), E.elements.br = function(e) {
            return function(t) {
                if (t.parent.type != CKEDITOR.NODE_DOCUMENT_FRAGMENT) {
                    var r = t.attributes;
                    if ("data-cke-bogus" in r || "data-cke-eol" in r) delete r["data-cke-bogus"];
                    else {
                        var a = function(e) {
                                for (var t = e.next; t && o(t);) t = t.next;
                                return t
                            }(t),
                            u = i(t);
                        !a && l(t.parent) ? c(t.parent, n(e)) : l(a) && u && !l(u) && n(e).insertBefore(a)
                    }
                }
            }
        }(h), E
    }

    function t(e, t) {
        return e != CKEDITOR.ENTER_BR && !1 !== t && (e == CKEDITOR.ENTER_DIV ? "div" : "p")
    }
    CKEDITOR.htmlDataProcessor = function(r) {
        var a, i, o = this;
        this.editor = r, this.dataFilter = a = new CKEDITOR.htmlParser.filter, this.htmlFilter = i = new CKEDITOR.htmlParser.filter, this.writer = new CKEDITOR.htmlParser.basicWriter, a.addRules(p), a.addRules(m, {
            applyToAll: !0
        }), a.addRules(e(r, "data"), {
            applyToAll: !0
        }), i.addRules(h), i.addRules(v, {
            applyToAll: !0
        }), i.addRules(e(r, "html"), {
            applyToAll: !0
        }), r.on("toHtml", function(e) {
            var a, i = e.data,
                o = i.dataValue;
            o = y(o = function(e, t) {
                var r = [],
                    a = t.config.protectedSource,
                    i = t._.dataStore || (t._.dataStore = {
                        id: 1
                    }),
                    o = /<\!--\{cke_temp(comment)?\}(\d*?)-->/g,
                    l = [/<script[\s\S]*?(<\/script>|$)/gi, /<noscript[\s\S]*?<\/noscript>/gi, /<meta[\s\S]*?\/?>/gi].concat(a);
                e = e.replace(/<!--[\s\S]*?-->/g, function(e) {
                    return "\x3c!--{cke_tempcomment}" + (r.push(e) - 1) + "--\x3e"
                });
                for (var c = 0; c < l.length; c++) e = e.replace(l[c], function(e) {
                    return e = e.replace(o, function(e, t, n) {
                        return r[n]
                    }), /cke_temp(comment)?/.test(e) ? e : "\x3c!--{cke_temp}" + (r.push(e) - 1) + "--\x3e"
                });
                return e = (e = (e = e.replace(o, function(e, t, a) {
                    return "\x3c!--" + n + (t ? "{C}" : "") + encodeURIComponent(r[a]).replace(/--/g, "%2D%2D") + "--\x3e"
                })).replace(/<\w+(?:\s+(?:(?:[^\s=>]+\s*=\s*(?:[^'"\s>]+|'[^']*'|"[^"]*"))|[^\s=\/>]+))+\s*\/?>/g, function(e) {
                    return e.replace(/<!--\{cke_protected\}([^>]*)-->/g, function(e, t) {
                        return i[i.id] = decodeURIComponent(t), "{cke_protected_" + i.id++ + "}"
                    })
                })).replace(/<(title|iframe|textarea)([^>]*)>([\s\S]*?)<\/\1>/g, function(e, r, n, a) {
                    return "<" + r + n + ">" + w(F(a), t) + "</" + r + ">"
                })
            }(o = o.replace(I, ""), r), O), o = function(e) {
                return e.replace(/([^a-z0-9<\-])(on\w{3,})(?!>)/gi, "$1data-cke-" + CKEDITOR.rnd + "-$2")
            }(o = function(e) {
                return e.replace(/(<pre\b[^>]*>)(\r\n|\n)/g, "$1$2$2")
            }(o = function(e) {
                return e.replace(K, "<cke:$1$2></cke:$1>")
            }(o = function(e) {
                return e.replace(k, "$1cke:$2")
            }(o = y(o = o.replace(b, function(e, t, r) {
                return "<" + t + r.replace(T, function(e, t) {
                    return C.test(t) && -1 == r.indexOf("data-cke-saved-" + t) ? " data-cke-saved-" + e + " data-cke-" + CKEDITOR.rnd + "-" + e : e
                }) + ">"
            }), R)))));
            var l, c = i.context || r.editable().getName();
            CKEDITOR.env.ie && CKEDITOR.env.version < 9 && "pre" == c && (c = "div", o = "<pre>" + o + "</pre>", l = 1);
            var u = r.document.createElement(c);
            u.setHtml("a" + o), o = (o = u.getHtml().substr(1)).replace(new RegExp("data-cke-" + CKEDITOR.rnd + "-", "ig"), ""), l && (o = o.replace(/^<pre>|<\/pre>$/gi, "")), o = F(o = function(e) {
                return e.replace(g, function(e, t) {
                    return decodeURIComponent(t)
                })
            }(o = function(e) {
                return e.replace(x, "$1$2")
            }(o))), a = !1 !== i.fixForBody && t(i.enterMode, r.config.autoParagraph), o = CKEDITOR.htmlParser.fragment.fromHtml(o, i.context, a), a && function(e, t) {
                if (!e.children.length && CKEDITOR.dtd[e.name][t]) {
                    var r = new CKEDITOR.htmlParser.element(t);
                    e.add(r)
                }
            }(o, a), i.dataValue = o
        }, null, null, 5), r.on("toHtml", function(e) {
            e.data.filter.applyTo(e.data.dataValue, !0, e.data.dontFilter, e.data.enterMode) && r.fire("dataFiltered")
        }, null, null, 6), r.on("toHtml", function(e) {
            e.data.dataValue.filterChildren(o.dataFilter, !0)
        }, null, null, 10), r.on("toHtml", function(e) {
            var t = e.data,
                r = t.dataValue,
                a = new CKEDITOR.htmlParser.basicWriter;
            r.writeChildrenHtml(a), r = a.getHtml(!0), t.dataValue = r.replace(/<!--(?!{cke_protected})[\s\S]+?-->/g, function(e) {
                return "\x3c!--" + n + "{C}" + encodeURIComponent(e).replace(/--/g, "%2D%2D") + "--\x3e"
            })
        }, null, null, 15), r.on("toDataFormat", function(e) {
            var n = e.data.dataValue;
            e.data.enterMode != CKEDITOR.ENTER_BR && (n = n.replace(/^<br *\/?>/i, "")), e.data.dataValue = CKEDITOR.htmlParser.fragment.fromHtml(n, e.data.context, t(e.data.enterMode, r.config.autoParagraph))
        }, null, null, 5), r.on("toDataFormat", function(e) {
            e.data.dataValue.filterChildren(o.htmlFilter, !0)
        }, null, null, 10), r.on("toDataFormat", function(e) {
            e.data.filter.applyTo(e.data.dataValue, !1, !0)
        }, null, null, 11), r.on("toDataFormat", function(e) {
            var t = e.data.dataValue,
                n = o.writer;
            n.reset(), t.writeChildrenHtml(n), t = w(t = F(t = n.getHtml(!0)), r), e.data.dataValue = t
        }, null, null, 15)
    }, CKEDITOR.htmlDataProcessor.prototype = {
        toHtml: function(e, t, r, n) {
            var a, i, o, l, c = this.editor;
            return t && "object" == typeof t ? (a = t.context, r = t.fixForBody, n = t.dontFilter, i = t.filter, o = t.enterMode, l = t.protectedWhitespaces) : a = t, a || null === a || (a = c.editable().getName()), c.fire("toHtml", {
                dataValue: e,
                context: a,
                fixForBody: r,
                dontFilter: n,
                filter: i || c.filter,
                enterMode: o || c.enterMode,
                protectedWhitespaces: l
            }).dataValue
        },
        toDataFormat: function(e, t) {
            var r, n, a;
            return t && (r = t.context, n = t.filter, a = t.enterMode), r || null === r || (r = this.editor.editable().getName()), this.editor.fire("toDataFormat", {
                dataValue: e,
                filter: n || this.editor.filter,
                context: r,
                enterMode: a || this.editor.enterMode
            }).dataValue
        }
    };
    var r = /(?:&nbsp;|\xa0)$/,
        n = "{cke_protected}";

    function a(e) {
        for (var t = e.children[e.children.length - 1]; t && o(t);) t = t.previous;
        return t
    }

    function i(e) {
        for (var t = e.previous; t && o(t);) t = t.previous;
        return t
    }

    function o(e) {
        return e.type == CKEDITOR.NODE_TEXT && !CKEDITOR.tools.trim(e.value) || e.type == CKEDITOR.NODE_ELEMENT && e.attributes["data-cke-bookmark"]
    }

    function l(e) {
        return e && (e.type == CKEDITOR.NODE_ELEMENT && e.name in f || e.type == CKEDITOR.NODE_DOCUMENT_FRAGMENT)
    }

    function c(e, t) {
        var r = e.children[e.children.length - 1];
        e.children.push(t), t.parent = e, r && (r.next = t, t.previous = r)
    }

    function u(e) {
        return e.parent ? e.getIndex() : -1
    }
    var d = CKEDITOR.dtd,
        s = ["caption", "colgroup", "col", "thead", "tfoot", "tbody"],
        f = CKEDITOR.tools.extend({}, d.$blockLimit, d.$block),
        p = {
            elements: {
                input: E,
                textarea: E
            }
        },
        m = {
            attributeNames: [
                [/^on/, "data-cke-pa-on"],
                [/^srcdoc/, "data-cke-pa-srcdoc"],
                [/^data-cke-expando$/, ""]
            ],
            elements: {
                iframe: function(e) {
                    if (e.attributes && e.attributes.src) {
                        var t = e.attributes.src.toLowerCase().replace(/[^a-z]/gi, "");
                        0 !== t.indexOf("javascript") && 0 !== t.indexOf("data") || (e.attributes["data-cke-pa-src"] = e.attributes.src, delete e.attributes.src)
                    }
                }
            }
        };

    function E(e) {
        var t = e.attributes;
        "false" != t.contenteditable && (t["data-cke-editable"] = t.contenteditable ? "true" : 1), t.contenteditable = "false"
    }
    var h = {
            elements: {
                embed: function(e) {
                    var t = e.parent;
                    if (t && "object" == t.name) {
                        var r = t.attributes.width,
                            n = t.attributes.height;
                        r && (e.attributes.width = r), n && (e.attributes.height = n)
                    }
                },
                a: function(e) {
                    var t = e.attributes;
                    if (!(e.children.length || t.name || t.id || e.attributes["data-cke-saved-name"])) return !1
                }
            }
        },
        v = {
            elementNames: [
                [/^cke:/, ""],
                [/^\?xml:namespace$/, ""]
            ],
            attributeNames: [
                [/^data-cke-(saved|pa)-/, ""],
                [/^data-cke-.*/, ""],
                ["hidefocus", ""]
            ],
            elements: {
                $: function(e) {
                    var t = e.attributes;
                    if (t) {
                        if (t["data-cke-temp"]) return !1;
                        for (var r = ["name", "href", "src"], n = 0; n < r.length; n++) "data-cke-saved-" + r[n] in t && delete t[r[n]]
                    }
                    return e
                },
                table: function(e) {
                    e.children.slice(0).sort(function(e, t) {
                        var r, n;
                        return e.type == CKEDITOR.NODE_ELEMENT && t.type == e.type && (r = CKEDITOR.tools.indexOf(s, e.name), n = CKEDITOR.tools.indexOf(s, t.name)), r > -1 && n > -1 && r != n || (r = u(e), n = u(t)), r > n ? 1 : -1
                    })
                },
                param: function(e) {
                    return e.children = [], e.isEmpty = !0, e
                },
                span: function(e) {
                    "Apple-style-span" == e.attributes.class && delete e.name
                },
                html: function(e) {
                    delete e.attributes.contenteditable, delete e.attributes.class
                },
                body: function(e) {
                    delete e.attributes.spellcheck, delete e.attributes.contenteditable
                },
                style: function(e) {
                    var t = e.children[0];
                    t && t.value && (t.value = CKEDITOR.tools.trim(t.value)), e.attributes.type || (e.attributes.type = "text/css")
                },
                title: function(e) {
                    var t = e.children[0];
                    !t && c(e, t = new CKEDITOR.htmlParser.text), t.value = e.attributes["data-cke-title"] || ""
                },
                input: D,
                textarea: D
            },
            attributes: {
                class: function(e) {
                    return CKEDITOR.tools.ltrim(e.replace(/(?:^|\s+)cke_[^\s]*/g, "")) || !1
                }
            }
        };

    function D(e) {
        var t = e.attributes;
        switch (t["data-cke-editable"]) {
            case "true":
                t.contenteditable = "true";
                break;
            case "1":
                delete t.contenteditable
        }
    }
    CKEDITOR.env.ie && (v.attributes.style = function(e) {
        return e.replace(/(^|;)([^\:]+)/g, function(e) {
            return e.toLowerCase()
        })
    });
    var b = /<(a|area|img|input|source)\b([^>]*)>/gi,
        T = /([\w-:]+)\s*=\s*(?:(?:"[^"]*")|(?:'[^']*')|(?:[^ "'>]+))/gi,
        C = /^(href|src|name)$/i,
        R = /(?:<style(?=[ >])[^>]*>[\s\S]*?<\/style>)|(?:<(:?link|meta|base)[^>]*>)/gi,
        O = /(<textarea(?=[ >])[^>]*>)([\s\S]*?)(?:<\/textarea>)/gi,
        g = /<cke:encoded>([^<]*)<\/cke:encoded>/gi,
        I = new RegExp("(" + _("<cke:encoded>") + "(.*?)" + _("</cke:encoded>") + ")|(" + _("<") + _("/") + "?" + _("cke:encoded>") + ")", "gi"),
        k = /(<\/?)((?:object|embed|param|html|body|head|title)([\s][^>]*)?>)/gi,
        x = /(<\/?)cke:((?:html|body|head|title)[^>]*>)/gi,
        K = /<cke:(param|embed)([^>]*?)\/?>(?!\s*<\/cke:\1)/gi;

    function y(e, t) {
        return e.replace(t, function(e, t, r) {
            return 0 === e.indexOf("<textarea") && (e = t + F(r).replace(/</g, "&lt;").replace(/>/g, "&gt;") + "</textarea>"), "<cke:encoded>" + encodeURIComponent(e) + "</cke:encoded>"
        })
    }

    function _(e) {
        return CKEDITOR.tools.array.reduce(e.split(""), function(e, t) {
            var r = t.toLowerCase(),
                n = t.toUpperCase(),
                a = N(r);
            return r !== n && (a += "|" + N(n)), e += "(" + a + ")"
        }, "")
    }

    function N(e) {
        var t = function(e) {
                var t = e.charCodeAt(0),
                    r = t.toString(16);
                return {
                    htmlCode: "&#" + t + ";?",
                    hex: "&#x0*" + r + ";?",
                    entity: {
                        "<": "&lt;",
                        ">": "&gt;",
                        ":": "&colon;"
                    }[e]
                }
            }(e),
            r = e;
        for (var n in t) t[n] && (r += "|" + t[n]);
        return r
    }

    function F(e) {
        return e.replace(/<!--\{cke_protected\}\{C\}([\s\S]+?)-->/g, function(e, t) {
            return decodeURIComponent(t)
        })
    }

    function w(e, t) {
        var r = t._.dataStore;
        return e.replace(/<!--\{cke_protected\}([\s\S]+?)-->/g, function(e, t) {
            return decodeURIComponent(t)
        }).replace(/\{cke_protected_(\d+)\}/g, function(e, t) {
            return r && r[t] || ""
        })
    }
}();