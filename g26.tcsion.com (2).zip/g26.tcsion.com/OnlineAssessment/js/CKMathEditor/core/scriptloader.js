CKEDITOR.scriptLoader = function() {
    var e = {},
        t = {};
    return {
        load: function(n, a, o, r) {
            var c = "string" == typeof n;
            c && (n = [n]), o || (o = CKEDITOR);
            var i = n.length,
                l = [],
                u = [],
                s = function(e) {
                    a && (c ? a.call(o, e) : a.call(o, l, u))
                };
            if (0 !== i) {
                var f = function(e, t) {
                        (t ? l : u).push(e), --i <= 0 && (r && CKEDITOR.document.getDocumentElement().removeStyle("cursor"), s(t))
                    },
                    d = function(n, a) {
                        e[n] = 1;
                        var o = t[n];
                        delete t[n];
                        for (var r = 0; r < o.length; r++) o[r](n, a)
                    },
                    v = function(n) {
                        if (e[n]) f(n, !0);
                        else {
                            var o = t[n] || (t[n] = []);
                            if (o.push(f), !(o.length > 1)) {
                                var r = new CKEDITOR.dom.element("script");
                                r.setAttributes({
                                    type: "text/javascript",
                                    src: n
                                }), a && (CKEDITOR.env.ie && (CKEDITOR.env.version <= 8 || CKEDITOR.env.ie9Compat) ? r.$.onreadystatechange = function() {
                                    "loaded" != r.$.readyState && "complete" != r.$.readyState || (r.$.onreadystatechange = null, d(n, !0))
                                } : (r.$.onload = function() {
                                    setTimeout(function() {
                                        d(n, !0)
                                    }, 0)
                                }, r.$.onerror = function() {
                                    d(n, !1)
                                })), r.appendTo(CKEDITOR.document.getHead()), CKEDITOR.fire("download", n)
                            }
                        }
                    };
                r && CKEDITOR.document.getDocumentElement().setStyle("cursor", "wait");
                for (var p = 0; p < i; p++) v(n[p])
            } else s(!0)
        },
        queue: function() {
            var e = [];

            function t() {
                var t;
                (t = e[0]) && this.load(t.scriptUrl, t.callback, CKEDITOR, 0)
            }
            return function(n, a) {
                var o = this;
                e.push({
                    scriptUrl: n,
                    callback: function() {
                        a && a.apply(this, arguments), e.shift(), t.call(o)
                    }
                }), 1 == e.length && t.call(this)
            }
        }()
    }
}();