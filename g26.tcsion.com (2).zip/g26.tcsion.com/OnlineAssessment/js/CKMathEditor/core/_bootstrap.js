! function() {
    if (CKEDITOR.env.webkit) CKEDITOR.env.hc = !1;
    else {
        var e = CKEDITOR.dom.element.createFromHtml('<div style="width:0;height:0;position:absolute;left:-10000px;border:1px solid;border-color:red blue"></div>', CKEDITOR.document);
        e.appendTo(CKEDITOR.document.getHead());
        try {
            var t = e.getComputedStyle("border-top-color"),
                o = e.getComputedStyle("border-right-color");
            CKEDITOR.env.hc = !(!t || t != o)
        } catch (e) {
            CKEDITOR.env.hc = !1
        }
        e.remove()
    }
    CKEDITOR.env.hc && (CKEDITOR.env.cssClass += " cke_hc"), CKEDITOR.document.appendStyleText(".cke{visibility:hidden;}"), CKEDITOR.status = "loaded", CKEDITOR.fireOnce("loaded");
    var d = CKEDITOR._.pending;
    if (d) {
        delete CKEDITOR._.pending;
        for (var r = 0; r < d.length; r++) CKEDITOR.editor.prototype.constructor.apply(d[r][0], d[r][1]), CKEDITOR.add(d[r][0])
    }
}();