! function() {
    var e, t, n, o, a, r, i, s, l, c;

    function d(e) {
        var t = e.data.getTarget();
        if (t.is("input")) {
            var n = t.getAttribute("type");
            "submit" != n && "reset" != n || e.data.preventDefault()
        }
    }

    function E(n) {
        return e(n) && t(n)
    }

    function u(e, t, n) {
        return !1 !== e.config.autoParagraph && e.activeEnterMode != CKEDITOR.ENTER_BR && (e.editable().equals(n) && !t || t && "true" == t.getAttribute("contenteditable"))
    }

    function T(e) {
        return e.activeEnterMode != CKEDITOR.ENTER_BR && !1 !== e.config.autoParagraph && (e.activeEnterMode == CKEDITOR.ENTER_DIV ? "div" : "p")
    }

    function m(e) {
        var t = e.editor;
        t.getSelection().scrollIntoView(), setTimeout(function() {
            t.fire("saveSnapshot")
        }, 0)
    }

    function h(e, t, n) {
        for (var o = e.getCommonAncestor(t), a = n ? t : e, r = a;
            (a = a.getParent()) && !o.equals(a) && 1 == a.getChildCount();) r = a;
        r.remove()
    }
    CKEDITOR.editable = CKEDITOR.tools.createClass({
        base: CKEDITOR.dom.element,
        $: function(e, t) {
            this.base(t.$ || t), this.editor = e, this.status = "unloaded", this.hasFocus = !1, this.setup()
        },
        proto: {
            focus: function() {
                var e;
                if (CKEDITOR.env.webkit && !this.hasFocus && (e = this.editor._.previousActive || this.getDocument().getActive(), this.contains(e))) e.focus();
                else {
                    CKEDITOR.env.edge && CKEDITOR.env.version > 14 && !this.hasFocus && this.getDocument().equals(CKEDITOR.document) && (this.editor._.previousScrollTop = this.$.scrollTop);
                    try {
                        if (!CKEDITOR.env.ie || CKEDITOR.env.edge && CKEDITOR.env.version > 14 || !this.getDocument().equals(CKEDITOR.document))
                            if (CKEDITOR.env.chrome) {
                                var t = this.$.scrollTop;
                                this.$.focus(), this.$.scrollTop = t
                            } else this.$.focus();
                        else this.$.setActive()
                    } catch (e) {
                        if (!CKEDITOR.env.ie) throw e
                    }
                    CKEDITOR.env.safari && !this.isInline() && ((e = CKEDITOR.document.getActive()).equals(this.getWindow().getFrame()) || this.getWindow().focus())
                }
            },
            on: function(e, t) {
                var n = Array.prototype.slice.call(arguments, 0);
                return CKEDITOR.env.ie && /^focus|blur$/.exec(e) && (e = "focus" == e ? "focusin" : "focusout", t = function(e, t) {
                    return function(n) {
                        var o = n.data.$.toElement || n.data.$.fromElement || n.data.$.relatedTarget;
                        (o = o && o.nodeType == CKEDITOR.NODE_ELEMENT ? new CKEDITOR.dom.element(o) : null) && (t.equals(o) || t.contains(o)) || e.call(this, n)
                    }
                }(t, this), n[0] = e, n[1] = t), CKEDITOR.dom.element.prototype.on.apply(this, n)
            },
            attachListener: function(e) {
                !this._.listeners && (this._.listeners = []);
                var t = Array.prototype.slice.call(arguments, 1),
                    n = e.on.apply(e, t);
                return this._.listeners.push(n), n
            },
            clearListeners: function() {
                var e = this._.listeners;
                try {
                    for (; e.length;) e.pop().removeListener()
                } catch (e) {}
            },
            restoreAttrs: function() {
                var e, t = this._.attrChanges;
                for (var n in t) t.hasOwnProperty(n) && (null !== (e = t[n]) ? this.setAttribute(n, e) : this.removeAttribute(n))
            },
            attachClass: function(e) {
                var t = this.getCustomData("classes");
                this.hasClass(e) || (!t && (t = []), t.push(e), this.setCustomData("classes", t), this.addClass(e))
            },
            changeAttr: function(e, t) {
                var n = this.getAttribute(e);
                t !== n && (!this._.attrChanges && (this._.attrChanges = {}), e in this._.attrChanges || (this._.attrChanges[e] = n), this.setAttribute(e, t))
            },
            insertText: function(e) {
                this.editor.focus(), this.insertHtml(this.transformPlainTextToHtml(e), "text")
            },
            transformPlainTextToHtml: function(e) {
                var t = this.editor.getSelection().getStartElement().hasAscendant("pre", !0) ? CKEDITOR.ENTER_BR : this.editor.activeEnterMode;
                return CKEDITOR.tools.transformPlainTextToHtml(e, t)
            },
            insertHtml: function(e, t, n) {
                var o = this.editor;
                o.focus(), o.fire("saveSnapshot"), n || (n = o.getSelection().getRanges()[0]), r(this, t || "html", e, n), n.select(), m(this), this.editor.fire("afterInsertHtml", {})
            },
            insertHtmlIntoRange: function(e, t, n) {
                r(this, n || "html", e, t), this.editor.fire("afterInsertHtml", {
                    intoRange: t
                })
            },
            insertElement: function(e, t) {
                var n = this.editor;
                n.focus(), n.fire("saveSnapshot");
                var a = n.activeEnterMode,
                    r = n.getSelection(),
                    i = e.getName(),
                    s = CKEDITOR.dtd.$block[i];
                if (t || (t = r.getRanges()[0]), this.insertElementIntoRange(e, t) && (t.moveToPosition(e, CKEDITOR.POSITION_AFTER_END), s)) {
                    var l = e.getNext(function(e) {
                        return E(e) && !o(e)
                    });
                    l && l.type == CKEDITOR.NODE_ELEMENT && l.is(CKEDITOR.dtd.$block) ? l.getDtd()["#"] ? t.moveToElementEditStart(l) : t.moveToElementEditEnd(e) : l || a == CKEDITOR.ENTER_BR || (l = t.fixBlock(!0, a == CKEDITOR.ENTER_DIV ? "div" : "p"), t.moveToElementEditStart(l))
                }
                r.selectRanges([t]), m(this)
            },
            insertElementIntoSelection: function(e) {
                this.insertElement(e)
            },
            insertElementIntoRange: function(e, t) {
                var n, o, a = this.editor,
                    r = a.config.enterMode,
                    l = e.getName(),
                    c = CKEDITOR.dtd.$block[l];
                if (t.checkReadOnly()) return !1;
                if (t.deleteContents(1), t.startContainer.type == CKEDITOR.NODE_ELEMENT && (t.startContainer.is({
                        tr: 1,
                        table: 1,
                        tbody: 1,
                        thead: 1,
                        tfoot: 1
                    }) ? i(t) : t.startContainer.is(CKEDITOR.dtd.$list) && s(t)), c)
                    for (;
                        (n = t.getCommonAncestor(0, 1)) && (o = CKEDITOR.dtd[n.getName()]) && (!o || !o[l]);) n.getName() in CKEDITOR.dtd.span ? t.splitElement(n) : t.checkStartOfBlock() && t.checkEndOfBlock() ? (t.setStartBefore(n), t.collapse(!0), n.remove()) : t.splitBlock(r == CKEDITOR.ENTER_DIV ? "div" : "p", a.editable());
                return t.insertNode(e), !0
            },
            setData: function(e, t) {
                t || (e = this.editor.dataProcessor.toHtml(e)), this.setHtml(e), this.fixInitialSelection(), "unloaded" == this.status && (this.status = "ready"), this.editor.fire("dataReady")
            },
            getData: function(e) {
                var t = this.getHtml();
                return e || (t = this.editor.dataProcessor.toDataFormat(t)), t
            },
            setReadOnly: function(e) {
                this.setAttribute("contenteditable", !e)
            },
            detach: function() {
                this.removeClass("cke_editable"), this.status = "detached";
                var e = this.editor;
                this._.detach(), delete e.document, delete e.window
            },
            isInline: function() {
                return this.getDocument().equals(CKEDITOR.document)
            },
            fixInitialSelection: function() {
                var e = this;

                function t() {
                    var t = e.getDocument().$,
                        n = t.getSelection();
                    if (function(t) {
                            if (t.anchorNode && t.anchorNode == e.$) return !0;
                            if (CKEDITOR.env.webkit) {
                                var n = e.getDocument().getActive();
                                if (n && n.equals(e) && !t.anchorNode) return !0
                            }
                        }(n)) {
                        var o = new CKEDITOR.dom.range(e);
                        o.moveToElementEditStart(e);
                        var a = t.createRange();
                        a.setStart(o.startContainer.$, o.startOffset), a.collapse(!0), n.removeAllRanges(), n.addRange(a)
                    }
                }
                CKEDITOR.env.ie && (CKEDITOR.env.version < 9 || CKEDITOR.env.quirks) ? this.hasFocus && (this.focus(), function() {
                    var t = e.getDocument().$,
                        n = t.selection,
                        o = e.getDocument().getActive();
                    if ("None" == n.type && o.equals(e)) {
                        var a, r = new CKEDITOR.dom.range(e),
                            i = t.body.createTextRange();
                        r.moveToElementEditStart(e), (a = r.startContainer).type != CKEDITOR.NODE_ELEMENT && (a = a.getParent()), i.moveToElementText(a.$), i.collapse(!0), i.select()
                    }
                }()) : this.hasFocus ? (this.focus(), t()) : this.once("focus", function() {
                    t()
                }, null, null, -999)
            },
            getHtmlFromRange: function(e) {
                if (e.collapsed) return new CKEDITOR.dom.documentFragment(e.document);
                var t = {
                    doc: this.getDocument(),
                    range: e.clone()
                };
                return l.eol.detect(t, this), l.bogus.exclude(t), l.cell.shrink(t), t.fragment = t.range.cloneContents(), l.tree.rebuild(t, this), l.eol.fix(t, this), new CKEDITOR.dom.documentFragment(t.fragment.$)
            },
            extractHtmlFromRange: function(e, o) {
                var a = c,
                    r = {
                        range: e,
                        doc: e.document
                    },
                    i = this.getHtmlFromRange(e);
                if (e.collapsed) return e.optimize(), i;
                e.enlarge(CKEDITOR.ENLARGE_INLINE, 1), a.table.detectPurge(r), r.bookmark = e.createBookmark(), delete r.range;
                var s = this.editor.createRange();
                if (s.moveToPosition(r.bookmark.startNode, CKEDITOR.POSITION_BEFORE_START), r.targetBookmark = s.createBookmark(), a.list.detectMerge(r, this), a.table.detectRanges(r, this), a.block.detectMerge(r, this), r.tableContentsRanges ? (a.table.deleteRanges(r), e.moveToBookmark(r.bookmark), r.range = e) : (e.moveToBookmark(r.bookmark), r.range = e, e.extractContents(a.detectExtractMerge(r))), e.moveToBookmark(r.targetBookmark), e.optimize(), a.fixUneditableRangePosition(e), a.list.merge(r, this), a.table.purge(r, this), a.block.merge(r, this), o) {
                    var l = e.startPath();
                    e.checkStartOfBlock() && e.checkEndOfBlock() && l.block && !e.root.equals(l.block) && ! function(e) {
                        var n, o = e.getElementsByTag("span"),
                            a = 0;
                        if (o)
                            for (; n = o.getItem(a++);)
                                if (!t(n)) return !0;
                        return !1
                    }(l.block) && (e.moveToPosition(l.block, CKEDITOR.POSITION_BEFORE_START), l.block.remove())
                } else a.autoParagraph(this.editor, e), n(e.startContainer) && e.startContainer.appendBogus();
                return e.startContainer.mergeSiblings(), i
            },
            setup: function() {
                var t = this.editor;
                if (this.attachListener(t, "beforeGetData", function() {
                        var e = this.getData();
                        this.is("textarea") || !1 !== t.config.ignoreEmptyParagraph && (e = e.replace(a, function(e, t) {
                            return t
                        })), t.setData(e, null, 1)
                    }, this), this.attachListener(t, "getSnapshot", function(e) {
                        e.data = this.getData(1)
                    }, this), this.attachListener(t, "afterSetData", function() {
                        this.setData(t.getData(1))
                    }, this), this.attachListener(t, "loadSnapshot", function(e) {
                        this.setData(e.data, 1)
                    }, this), this.attachListener(t, "beforeFocus", function() {
                        var e = t.getSelection(),
                            n = e && e.getNative();
                        n && "Control" == n.type || this.focus()
                    }, this), this.attachListener(t, "insertHtml", function(e) {
                        this.insertHtml(e.data.dataValue, e.data.mode, e.data.range)
                    }, this), this.attachListener(t, "insertElement", function(e) {
                        this.insertElement(e.data)
                    }, this), this.attachListener(t, "insertText", function(e) {
                        this.insertText(e.data)
                    }, this), this.setReadOnly(t.readOnly), this.attachClass("cke_editable"), t.elementMode == CKEDITOR.ELEMENT_MODE_INLINE ? this.attachClass("cke_editable_inline") : t.elementMode != CKEDITOR.ELEMENT_MODE_REPLACE && t.elementMode != CKEDITOR.ELEMENT_MODE_APPENDTO || this.attachClass("cke_editable_themed"), this.attachClass("cke_contents_" + t.config.contentsLangDirection), t.keystrokeHandler.blockedKeystrokes[8] = +t.readOnly, t.keystrokeHandler.attach(this), this.on("blur", function() {
                        this.hasFocus = !1
                    }, null, null, -1), this.on("focus", function() {
                        this.hasFocus = !0
                    }, null, null, -1), CKEDITOR.env.webkit && this.on("scroll", function() {
                        t._.previousScrollTop = t.editable().$.scrollTop
                    }, null, null, -1), CKEDITOR.env.edge && CKEDITOR.env.version > 14) {
                    var n = function() {
                        var e = t.editable();
                        null != t._.previousScrollTop && e.getDocument().equals(CKEDITOR.document) && (e.$.scrollTop = t._.previousScrollTop, t._.previousScrollTop = null, this.removeListener("scroll", n))
                    };
                    this.on("scroll", n)
                }
                if (t.focusManager.add(this), this.equals(CKEDITOR.document.getActive()) && (this.hasFocus = !0, t.once("contentDom", function() {
                        t.focusManager.focus(this)
                    }, this)), this.isInline() && this.changeAttr("tabindex", t.tabIndex), !this.is("textarea")) {
                    t.document = this.getDocument(), t.window = this.getWindow();
                    var r = t.document;
                    this.changeAttr("spellcheck", !t.config.disableNativeSpellChecker);
                    var i = t.config.contentsLangDirection;
                    this.getDirection(1) != i && this.changeAttr("dir", i);
                    var s = CKEDITOR.getCss();
                    if (s) {
                        var l = r.getHead(),
                            c = l.getCustomData("stylesheet");
                        if (c) s != c.getText() && (CKEDITOR.env.ie && CKEDITOR.env.version < 9 ? c.$.styleSheet.cssText = s : c.setText(s));
                        else {
                            var u = r.appendStyleText(s);
                            u = new CKEDITOR.dom.element(u.ownerNode || u.owningElement), l.setCustomData("stylesheet", u), u.data("cke-temp", 1)
                        }
                    }
                    var T = r.getCustomData("stylesheet_ref") || 0;
                    r.setCustomData("stylesheet_ref", T + 1), this.setCustomData("cke_includeReadonly", !t.config.disableReadonlyStyling), this.attachListener(this, "click", function(e) {
                        e = e.data;
                        var t = new CKEDITOR.dom.elementPath(e.getTarget(), this).contains("a");
                        t && 2 != e.$.button && t.isReadOnly() && e.preventDefault()
                    });
                    var m = {
                        8: 1,
                        46: 1
                    };
                    this.attachListener(t, "key", function(n) {
                        if (t.readOnly) return !0;
                        var a, r = n.data.domEvent.getKey(),
                            i = t.getSelection();
                        if (0 !== i.getRanges().length) {
                            if (r in m) {
                                var s, l, c, d, u = i.getRanges()[0],
                                    T = u.startPath(),
                                    h = 8 == r;
                                CKEDITOR.env.ie && CKEDITOR.env.version < 11 && (s = i.getSelectedElement()) || (s = function(e) {
                                    var t, n = e.getRanges()[0],
                                        a = e.root,
                                        r = n.startPath(),
                                        i = {
                                            table: 1,
                                            ul: 1,
                                            ol: 1,
                                            dl: 1
                                        };
                                    if (r.contains(i)) {
                                        var s = n.clone();
                                        s.collapse(1), s.setStartAt(a, CKEDITOR.POSITION_AFTER_START);
                                        var l = new CKEDITOR.dom.walker(s);
                                        if (l.guard = c(), l.checkBackward(), t) return (s = n.clone()).collapse(), s.setEndAt(t, CKEDITOR.POSITION_AFTER_END), (l = new CKEDITOR.dom.walker(s)).guard = c(!0), t = !1, l.checkForward(), t
                                    }
                                    return null;

                                    function c(e) {
                                        return function(n, a) {
                                            if (a && n.type == CKEDITOR.NODE_ELEMENT && n.is(i) && (t = n), !a && E(n) && (!e || !o(n))) return !1
                                        }
                                    }
                                }(i)) ? (t.fire("saveSnapshot"), u.moveToPosition(s, CKEDITOR.POSITION_BEFORE_START), s.remove(), u.select(), t.fire("saveSnapshot"), a = 1) : u.collapsed && ((l = T.block) && (d = l[h ? "getPrevious" : "getNext"](e)) && d.type == CKEDITOR.NODE_ELEMENT && d.is("table") && u[h ? "checkStartOfBlock" : "checkEndOfBlock"]() ? (t.fire("saveSnapshot"), u[h ? "checkEndOfBlock" : "checkStartOfBlock"]() && l.remove(), u["moveToElementEdit" + (h ? "End" : "Start")](d), u.select(), t.fire("saveSnapshot"), a = 1) : T.blockLimit && T.blockLimit.is("td") && (c = T.blockLimit.getAscendant("table")) && u.checkBoundaryOfElement(c, h ? CKEDITOR.START : CKEDITOR.END) && (d = c[h ? "getPrevious" : "getNext"](e)) ? (t.fire("saveSnapshot"), u["moveToElementEdit" + (h ? "End" : "Start")](d), u.checkStartOfBlock() && u.checkEndOfBlock() ? d.remove() : u.select(), t.fire("saveSnapshot"), a = 1) : (c = T.contains(["td", "th", "caption"])) && u.checkBoundaryOfElement(c, h ? CKEDITOR.START : CKEDITOR.END) && (a = 1))
                            }
                            return !a
                        }
                    }), t.blockless && CKEDITOR.env.ie && CKEDITOR.env.needsBrFiller && this.attachListener(this, "keyup", function(e) {
                        if (e.data.getKeystroke() in m && !this.getFirst(E)) {
                            this.appendBogus();
                            var n = t.createRange();
                            n.moveToPosition(this, CKEDITOR.POSITION_AFTER_START), n.select()
                        }
                    }), this.attachListener(this, "dblclick", function(e) {
                        if (t.readOnly) return !1;
                        var n = {
                            element: e.data.getTarget()
                        };
                        t.fire("doubleclick", n)
                    }), CKEDITOR.env.ie && this.attachListener(this, "click", d), CKEDITOR.env.ie && !CKEDITOR.env.edge || this.attachListener(this, "mousedown", function(e) {
                        var n = e.data.getTarget();
                        n.is("img", "hr", "input", "textarea", "select") && !n.isReadOnly() && (t.getSelection().selectElement(n), n.is("input", "textarea", "select") && e.data.preventDefault())
                    }), CKEDITOR.env.edge && this.attachListener(this, "mouseup", function(e) {
                        var n = e.data.getTarget();
                        n && n.is("img") && !n.isReadOnly() && t.getSelection().selectElement(n)
                    }), CKEDITOR.env.gecko && this.attachListener(this, "mouseup", function(e) {
                        if (2 == e.data.$.button) {
                            var n = e.data.getTarget();
                            if (!n.getAscendant("table") && !n.getOuterHtml().replace(a, "")) {
                                var o = t.createRange();
                                o.moveToElementEditStart(n), o.select(!0)
                            }
                        }
                    }), CKEDITOR.env.webkit && (this.attachListener(this, "click", function(e) {
                        e.data.getTarget().is("input", "select") && e.data.preventDefault()
                    }), this.attachListener(this, "mouseup", function(e) {
                        e.data.getTarget().is("input", "textarea") && e.data.preventDefault()
                    })), CKEDITOR.env.webkit && this.attachListener(t, "key", function(e) {
                        if (t.readOnly) return !0;
                        var n = e.data.domEvent.getKey();
                        if (n in m) {
                            var o = t.getSelection();
                            if (0 !== o.getRanges().length) {
                                var a = 8 == n,
                                    r = o.getRanges()[0],
                                    i = r.startPath();
                                if (r.collapsed) {
                                    if (! function(e, t, n, o) {
                                            var a = o.block;
                                            if (!a) return !1;
                                            if (!t[n ? "checkStartOfBlock" : "checkEndOfBlock"]()) return !1;
                                            if (!t.moveToClosestEditablePosition(a, !n) || !t.collapsed) return !1;
                                            if (t.startContainer.type == CKEDITOR.NODE_ELEMENT) {
                                                var r = t.startContainer.getChild(t.startOffset - (n ? 1 : 0));
                                                if (r && r.type == CKEDITOR.NODE_ELEMENT && r.is("hr")) return e.fire("saveSnapshot"), r.remove(), !0
                                            }
                                            var i, s = t.startPath().block;
                                            if (!s || s && s.contains(a)) return;
                                            e.fire("saveSnapshot"), (i = (n ? s : a).getBogus()) && i.remove();
                                            var l = e.getSelection(),
                                                c = l.createBookmarks();
                                            return (n ? a : s).moveChildren(n ? s : a, !1), o.lastElement.mergeSiblings(), h(a, s, !n), l.selectBookmarks(c), !0
                                        }(t, r, a, i)) return
                                } else if (! function(e, t, n) {
                                        var o, a = n.block,
                                            r = t.endPath().block;
                                        if (!a || !r || a.equals(r)) return !1;
                                        e.fire("saveSnapshot"), (o = a.getBogus()) && o.remove();
                                        t.enlarge(CKEDITOR.ENLARGE_INLINE), t.deleteContents(), r.getParent() && (r.moveChildren(a, !1), n.lastElement.mergeSiblings(), h(a, r, !0));
                                        (t = e.getSelection().getRanges()[0]).collapse(1), t.optimize(), "" === t.startContainer.getHtml() && t.startContainer.appendBogus();
                                        return t.select(), !0
                                    }(t, r, i)) return;
                                return t.getSelection().scrollIntoView(), t.fire("saveSnapshot"), !1
                            }
                        }
                    }, this, null, 100)
                }
            }
        },
        _: {
            detach: function() {
                var e;
                if (this.editor.setData(this.editor.getData(), 0, 1), this.clearListeners(), this.restoreAttrs(), e = this.removeCustomData("classes"))
                    for (; e.length;) this.removeClass(e.pop());
                if (!this.is("textarea")) {
                    var t = this.getDocument(),
                        n = t.getHead();
                    if (n.getCustomData("stylesheet")) {
                        var o = t.getCustomData("stylesheet_ref");
                        if (--o) t.setCustomData("stylesheet_ref", o);
                        else t.removeCustomData("stylesheet_ref"), n.removeCustomData("stylesheet").remove()
                    }
                }
                this.editor.fire("contentDomUnload"), delete this.editor
            }
        }
    }), CKEDITOR.editor.prototype.editable = function(e) {
        var t = this._.editable;
        return t && e ? 0 : (arguments.length && (t = this._.editable = e ? e instanceof CKEDITOR.editable ? e : new CKEDITOR.editable(this, e) : (t && t.detach(), null)), t)
    }, CKEDITOR.on("instanceLoaded", function(e) {
        var t = e.editor;
        t.on("insertElement", function(e) {
            var t = e.data;
            t.type == CKEDITOR.NODE_ELEMENT && (t.is("input") || t.is("textarea")) && ("false" != t.getAttribute("contentEditable") && t.data("cke-editable", t.hasAttribute("contenteditable") ? "true" : "1"), t.setAttribute("contentEditable", !1))
        }), t.on("selectionChange", function(e) {
            if (!t.readOnly) {
                var n = t.getSelection();
                if (n && !n.isLocked) {
                    var o = t.checkDirty();
                    t.fire("lockSnapshot"),
                        function(e) {
                            var t, n = e.editor,
                                o = e.data.path,
                                a = o.blockLimit,
                                r = e.data.selection,
                                i = r.getRanges()[0];
                            if (CKEDITOR.env.gecko || CKEDITOR.env.ie && CKEDITOR.env.needsBrFiller) {
                                var s = function(e, t) {
                                    if (e.isFake) return 0;
                                    var n = t.block || t.blockLimit,
                                        o = n && n.getLast(E);
                                    if (n && n.isBlockBoundary() && (!o || o.type != CKEDITOR.NODE_ELEMENT || !o.isBlockBoundary()) && !n.is("pre") && !n.getBogus()) return n
                                }(r, o);
                                s && (s.appendBogus(), t = CKEDITOR.env.ie)
                            }
                            if (u(n, o.block, a) && i.collapsed && !i.getCommonAncestor().isReadOnly()) {
                                var l = i.clone();
                                l.enlarge(CKEDITOR.ENLARGE_BLOCK_CONTENTS);
                                var c = new CKEDITOR.dom.walker(l);
                                if (c.guard = function(e) {
                                        return !E(e) || e.type == CKEDITOR.NODE_COMMENT || e.isReadOnly()
                                    }, !c.checkForward() || l.checkStartOfBlock() && l.checkEndOfBlock()) {
                                    var d = i.fixBlock(!0, n.activeEnterMode == CKEDITOR.ENTER_DIV ? "div" : "p");
                                    if (!CKEDITOR.env.needsBrFiller) {
                                        var T = d.getFirst(E);
                                        T && ((m = T).type == CKEDITOR.NODE_TEXT && CKEDITOR.tools.trim(m.getText()).match(/^(?:&nbsp;|\xa0)$/)) && T.remove()
                                    }
                                    t = 1, e.cancel()
                                }
                            }
                            var m;
                            t && i.select()
                        }(e), t.fire("unlockSnapshot"), !o && t.resetDirty()
                }
            }
        })
    }), CKEDITOR.on("instanceCreated", function(e) {
        var t = e.editor;
        t.on("mode", function() {
            var e = t.editable();
            if (e && e.isInline()) {
                var n = t.title;
                e.changeAttr("role", "textbox"), e.changeAttr("aria-multiline", "true"), e.changeAttr("aria-label", n), n && e.changeAttr("title", n);
                var o = t.fire("ariaEditorHelpLabel", {}).label;
                if (o) {
                    var a = this.ui.space(this.elementMode == CKEDITOR.ELEMENT_MODE_INLINE ? "top" : "contents");
                    if (a) {
                        var r = CKEDITOR.tools.getNextId(),
                            i = CKEDITOR.dom.element.createFromHtml('<span id="' + r + '" class="cke_voice_label">' + o + "</span>");
                        a.append(i), e.changeAttr("aria-describedby", r)
                    }
                }
            }
        })
    }), CKEDITOR.addCss(".cke_editable{cursor:text}.cke_editable img,.cke_editable input,.cke_editable textarea{cursor:default}"), e = CKEDITOR.dom.walker.whitespaces(!0), t = CKEDITOR.dom.walker.bookmark(!1, !0), n = CKEDITOR.dom.walker.empty(), o = CKEDITOR.dom.walker.bogus(), a = /(^|<body\b[^>]*>)\s*<(p|div|address|h\d|center|pre)[^>]*>\s*(?:<br[^>]*>|&nbsp;|\u00A0|&#160;)?\s*(:?<\/\2>)?\s*(?=$|<\/body>)/gi, r = function() {
        "use strict";
        var e = CKEDITOR.dtd;

        function t(e) {
            return e.type == CKEDITOR.NODE_ELEMENT
        }

        function n(n, o, a, r) {
            for (var i, s = function n(o, a) {
                    var r, i = [],
                        s = o.getChildren(),
                        l = s.count(),
                        c = 0,
                        d = e[a],
                        E = !o.is(e.$inline) || o.is("br");
                    E && i.push(" ");
                    for (; c < l; c++) t(r = s.getItem(c)) && !r.is(d) ? i = i.concat(n(r, a)) : i.push(r);
                    E && i.push(" ");
                    return i
                }(n, o), l = [], c = s.length, d = 0, E = 0, u = -1; d < c; d++) " " == (i = s[d]) ? (E || a && !d || (l.push(new CKEDITOR.dom.text(" ")), u = l.length), E = 1) : (l.push(i), E = 0);
            return r && u == l.length && l.pop(), l
        }

        function o(e) {
            return t(e.startContainer) && e.startContainer.getChild(e.startOffset - 1)
        }

        function a(n) {
            return n && t(n) && (n.is(e.$removeEmpty) || n.is("a") && !n.isBlockBoundary())
        }
        var r = {
            p: 1,
            div: 1,
            h1: 1,
            h2: 1,
            h3: 1,
            h4: 1,
            h5: 1,
            h6: 1,
            ul: 1,
            ol: 1,
            li: 1,
            pre: 1,
            dl: 1,
            blockquote: 1
        };

        function i(t, n, o) {
            var a, r;
            if (o.hasBlockSibling) return 1;
            if (!(a = t.startContainer.getAscendant(e.$block, 1)) || !a.is({
                    div: 1,
                    p: 1
                })) return 0;
            if ((r = a.getPosition(n)) == CKEDITOR.POSITION_IDENTICAL || r == CKEDITOR.POSITION_CONTAINS) return 0;
            var i = t.splitElement(a);
            return t.moveToPosition(i, CKEDITOR.POSITION_AFTER_START), 1
        }
        var s = {
                p: 1,
                div: 1,
                h1: 1,
                h2: 1,
                h3: 1,
                h4: 1,
                h5: 1,
                h6: 1
            },
            l = CKEDITOR.tools.extend({}, e.$inline);
        return delete l.br,
            function(c, d, m, h) {
                var g = c.editor,
                    f = !1;
                if ("unfiltered_html" == d && (d = "html", f = !0), !h.checkReadOnly()) {
                    var O = {
                        type: d,
                        dontFilter: f,
                        editable: c,
                        editor: g,
                        range: h,
                        blockLimit: new CKEDITOR.dom.elementPath(h.startContainer, h.root).blockLimit || h.root,
                        mergeCandidates: [],
                        zombies: []
                    };
                    ! function(e) {
                        var n, i, s, l, c, d, u, T = e.range,
                            m = e.mergeCandidates;
                        if ("text" == e.type && T.shrink(CKEDITOR.SHRINK_ELEMENT, !0, !1) && (i = CKEDITOR.dom.element.createFromHtml("<span>&nbsp;</span>", T.document), T.insertNode(i), T.setStartAfter(i)), l = new CKEDITOR.dom.elementPath(T.startContainer), e.endPath = c = new CKEDITOR.dom.elementPath(T.endContainer), !T.collapsed) {
                            n = c.block || c.blockLimit;
                            var h = T.getCommonAncestor();
                            n && !n.equals(h) && !n.contains(h) && T.checkEndOfBlock() && e.zombies.push(n), T.deleteContents()
                        }
                        for (;
                            (d = o(T)) && t(d) && d.isBlockBoundary() && l.contains(d);) T.moveToPosition(d, CKEDITOR.POSITION_BEFORE_END);
                        for (function e(n, o, a, i) {
                                var s, l, c, d = n.clone();
                                d.setEndAt(o, CKEDITOR.POSITION_BEFORE_END), s = new CKEDITOR.dom.walker(d), (l = s.next()) && t(l) && r[l.getName()] && (c = l.getPrevious()) && t(c) && !c.getParent().equals(n.startContainer) && a.contains(c) && i.contains(l) && l.isIdentical(c) && (l.moveChildren(c), l.remove(), e(n, o, a, i))
                            }(T, e.blockLimit, l, c), i && (T.setEndBefore(i), T.collapse(), i.remove()), s = T.startPath(), (n = s.contains(a, !1, 1)) && (T.splitElement(n), e.inlineStylesRoot = n, e.inlineStylesPeak = s.lastElement), u = T.createBookmark(), (n = u.startNode.getPrevious(E)) && t(n) && a(n) && m.push(n), (n = u.startNode.getNext(E)) && t(n) && a(n) && m.push(n), n = u.startNode;
                            (n = n.getParent()) && a(n);) m.push(n);
                        T.moveToBookmark(u)
                    }(O), m && function(e, n) {
                            var o = e.range;
                            "text" == e.type && e.inlineStylesRoot && (n = function(e, t) {
                                for (var n = t.inlineStylesPeak, o = n.getDocument().createText("{cke-peak}"), a = t.inlineStylesRoot.getParent(); !n.equals(a);) o = o.appendTo(n.clone()), n = n.getParent();
                                return o.getOuterHtml().split("{cke-peak}").join(e)
                            }(n, e));
                            var a = e.blockLimit.getName();
                            if (/^\s+|\s+$/.test(n) && "span" in CKEDITOR.dtd[a]) {
                                var r = '<span data-cke-marker="1">&nbsp;</span>';
                                n = r + n + r
                            }
                            n = e.editor.dataProcessor.toHtml(n, {
                                context: null,
                                fixForBody: !1,
                                protectedWhitespaces: !!r,
                                dontFilter: e.dontFilter,
                                filter: e.editor.activeFilter,
                                enterMode: e.editor.activeEnterMode
                            });
                            var i = o.document.createElement("body");
                            i.setHtml(n), r && (i.getFirst().remove(), i.getLast().remove());
                            var c = o.startPath().block;
                            return !c || 1 == c.getChildCount() && c.getBogus() || function(e) {
                                var n, o;
                                if (1 == e.getChildCount() && t(n = e.getFirst()) && n.is(s) && !n.hasAttribute("contenteditable")) {
                                    o = n.getElementsByTag("*");
                                    for (var a = 0, r = o.count(); a < r; a++)
                                        if (!o.getItem(a).is(l)) return;
                                    n.moveChildren(n.getParent(1)), n.remove()
                                }
                            }(i), e.dataWrapper = i, n
                        }(O, m) && function(o) {
                            var a, r, s, l, c, d, E, m, h, g, f, O = o.range,
                                I = O.document,
                                C = o.blockLimit,
                                R = 0,
                                v = [],
                                D = 0,
                                k = 0,
                                p = O.startContainer,
                                K = o.endPath.elements[0],
                                b = K.getPosition(p),
                                N = !(!K.getCommonAncestor(p) || b == CKEDITOR.POSITION_IDENTICAL || b & CKEDITOR.POSITION_CONTAINS + CKEDITOR.POSITION_IS_CONTAINED);
                            for (function(e, n) {
                                    var o = n.endContainer.getChild(n.endOffset),
                                        a = n.endContainer.getChild(n.endOffset - 1);

                                    function r(e, n) {
                                        if (n.isBlock && n.isElement && !n.node.is("br") && t(e) && e.is("br")) return e.remove(), 1
                                    }
                                    o && r(o, e[e.length - 1]), a && r(a, e[0]) && (n.setEnd(n.endContainer, n.endOffset - 1), n.collapse())
                                }(r = function n(o, a) {
                                    for (var r, i, s, l, c, d = [], E = a.range.startContainer, u = a.range.startPath(), T = e[E.getName()], m = 0, h = o.getChildren(), g = h.count(), f = -1, O = -1, I = 0, C = u.contains(e.$list); m < g; ++m)
                                        if (t(r = h.getItem(m))) {
                                            if (s = r.getName(), C && s in CKEDITOR.dtd.$list) {
                                                d = d.concat(n(r, a));
                                                continue
                                            }
                                            l = !!T[s], "br" != s || !r.data("cke-eol") || m && m != g - 1 || (i = m ? d[m - 1].node : h.getItem(m + 1), I = i && (!t(i) || !i.is("br")), c = i && t(i) && e.$block[i.getName()]), -1 != f || l || (f = m), l || (O = m), d.push({
                                                isElement: 1,
                                                isLineBreak: I,
                                                isBlock: r.isBlockBoundary(),
                                                hasBlockSibling: c,
                                                node: r,
                                                name: s,
                                                allowed: l
                                            }), I = 0, c = 0
                                        } else d.push({
                                            isElement: 0,
                                            node: r,
                                            allowed: 1
                                        });
                                    return f > -1 && (d[f].firstNotAllowed = 1), O > -1 && (d[O].lastNotAllowed = 1), d
                                }(o.dataWrapper, o), O); R < r.length; R++)
                                if ((s = r[R]).isLineBreak && i(O, C, s)) k = R > 0;
                                else {
                                    if (a = O.startPath(), !s.isBlock && u(o.editor, a.block, a.blockLimit) && (E = T(o.editor)) && ((E = I.createElement(E)).appendBogus(), O.insertNode(E), CKEDITOR.env.needsBrFiller && (c = E.getBogus()) && c.remove(), O.moveToPosition(E, CKEDITOR.POSITION_BEFORE_END)), (l = O.startPath().block) && !l.equals(d) && ((c = l.getBogus()) && (c.remove(), v.push(l)), d = l), s.firstNotAllowed && (D = 1), D && s.isElement) {
                                        for (m = O.startContainer, h = null; m && !e[m.getName()][s.name];) {
                                            if (m.equals(C)) {
                                                m = null;
                                                break
                                            }
                                            h = m, m = m.getParent()
                                        }
                                        m ? h && (g = O.splitElement(h), o.zombies.push(g), o.zombies.push(h)) : f = n(s.node, C.getName(), !R, R == r.length - 1)
                                    }
                                    if (f) {
                                        for (; l = f.pop();) O.insertNode(l);
                                        f = 0
                                    } else O.insertNode(s.node);
                                    s.lastNotAllowed && R < r.length - 1 && ((g = N ? K : g) && O.setEndAt(g, CKEDITOR.POSITION_AFTER_START), D = 0), O.collapse()
                                }(function(e) {
                                    if (1 != e.length) return !1;
                                    var t = e[0];
                                    return t.isElement && "false" == t.node.getAttribute("contenteditable")
                                })(r) && (k = !0, l = r[0].node, O.setStartAt(l, CKEDITOR.POSITION_BEFORE_START), O.setEndAt(l, CKEDITOR.POSITION_AFTER_END)), o.dontMoveCaret = k, o.bogusNeededBlocks = v
                        }(O),
                        function(n) {
                            for (var r, i, s, l = n.range, c = n.bogusNeededBlocks, d = l.createBookmark(); r = n.zombies.pop();) r.getParent() && ((i = l.clone()).moveToElementEditStart(r), i.removeEmptyBlocksAtEnd());
                            if (c)
                                for (; r = c.pop();) CKEDITOR.env.needsBrFiller ? r.appendBogus() : r.append(l.document.createText("�"));
                            for (; r = n.mergeCandidates.pop();) r.mergeSiblings();
                            if (l.moveToBookmark(d), !n.dontMoveCaret) {
                                for (r = o(l); r && t(r) && !r.is(e.$empty);) {
                                    if (r.isBlockBoundary()) l.moveToPosition(r, CKEDITOR.POSITION_BEFORE_END);
                                    else {
                                        if (a(r) && r.getHtml().match(/(\s|&nbsp;)$/g)) {
                                            s = null;
                                            break
                                        }(s = l.clone()).moveToPosition(r, CKEDITOR.POSITION_BEFORE_END)
                                    }
                                    r = r.getLast(E)
                                }
                                s && l.moveToRange(s)
                            }
                        }(O)
                }
            }
    }(), i = function() {
        function e(e) {
            var t = new CKEDITOR.dom.walker(e);
            return t.guard = function(e, t) {
                return !t && (e.type == CKEDITOR.NODE_ELEMENT ? e.is(CKEDITOR.dtd.$tableContent) : void 0)
            }, t.evaluator = function(e) {
                return e.type == CKEDITOR.NODE_ELEMENT
            }, t
        }

        function t(e, t, n) {
            var o = e.getDocument().createElement(t);
            return e.append(o, n), o
        }

        function n(e) {
            for (var t, n = e.count(); n-- > 0;) t = e.getItem(n), CKEDITOR.tools.trim(t.getHtml()) || (t.appendBogus(), CKEDITOR.env.ie && CKEDITOR.env.version < 9 && t.getChildCount() && t.getFirst().remove())
        }
        return function(o) {
            var a, r, i = o.startContainer,
                s = i.getAscendant("table", 1),
                l = !1;
            if (n(s.getElementsByTag("td")), n(s.getElementsByTag("th")), (a = o.clone()).setStart(i, 0), (r = e(a).lastBackward()) || ((a = o.clone()).setEndAt(i, CKEDITOR.POSITION_BEFORE_END), r = e(a).lastForward(), l = !0), r || (r = i), r.is("table")) return o.setStartAt(r, CKEDITOR.POSITION_BEFORE_START), o.collapse(!0), void r.remove();
            r.is({
                tbody: 1,
                thead: 1,
                tfoot: 1
            }) && (r = t(r, "tr", l)), r.is("tr") && (r = t(r, r.getParent().is("thead") ? "th" : "td", l));
            var c = r.getBogus();
            c && c.remove(), o.moveToPosition(r, l ? CKEDITOR.POSITION_AFTER_START : CKEDITOR.POSITION_BEFORE_END)
        }
    }(), s = function() {
        function e(e) {
            var t = new CKEDITOR.dom.walker(e);
            return t.guard = function(e, t) {
                return !t && (e.type == CKEDITOR.NODE_ELEMENT ? e.is(CKEDITOR.dtd.$list) || e.is(CKEDITOR.dtd.$listItem) : void 0)
            }, t.evaluator = function(e) {
                return e.type == CKEDITOR.NODE_ELEMENT && e.is(CKEDITOR.dtd.$listItem)
            }, t
        }
        return function(t) {
            var n, o, a = t.startContainer,
                r = !1;
            if ((n = t.clone()).setStart(a, 0), (o = e(n).lastBackward()) || ((n = t.clone()).setEndAt(a, CKEDITOR.POSITION_BEFORE_END), o = e(n).lastForward(), r = !0), o || (o = a), o.is(CKEDITOR.dtd.$list)) return t.setStartAt(o, CKEDITOR.POSITION_BEFORE_START), t.collapse(!0), void o.remove();
            var i = o.getBogus();
            i && i.remove(), t.moveToPosition(o, r ? CKEDITOR.POSITION_AFTER_START : CKEDITOR.POSITION_BEFORE_END), t.select()
        }
    }(), l = {
        eol: {
            detect: function(e, t) {
                var n = e.range,
                    o = n.clone(),
                    a = n.clone(),
                    r = new CKEDITOR.dom.elementPath(n.startContainer, t),
                    i = new CKEDITOR.dom.elementPath(n.endContainer, t);
                o.collapse(1), a.collapse(), r.block && o.checkBoundaryOfElement(r.block, CKEDITOR.END) && (n.setStartAfter(r.block), e.prependEolBr = 1), i.block && a.checkBoundaryOfElement(i.block, CKEDITOR.START) && (n.setEndBefore(i.block), e.appendEolBr = 1)
            },
            fix: function(e, t) {
                var n, o = t.getDocument();
                e.appendEolBr && (n = this.createEolBr(o), e.fragment.append(n)), !e.prependEolBr || n && !n.getPrevious() || e.fragment.append(this.createEolBr(o), 1)
            },
            createEolBr: function(e) {
                return e.createElement("br", {
                    attributes: {
                        "data-cke-eol": 1
                    }
                })
            }
        },
        bogus: {
            exclude: function(e) {
                var t = e.range.getBoundaryNodes(),
                    n = t.startNode,
                    a = t.endNode;
                !a || !o(a) || n && n.equals(a) || e.range.setEndBefore(a)
            }
        },
        tree: {
            rebuild: function(e, t) {
                var n, o = e.range,
                    a = o.getCommonAncestor(),
                    r = new CKEDITOR.dom.elementPath(a, t),
                    i = new CKEDITOR.dom.elementPath(o.startContainer, t),
                    s = new CKEDITOR.dom.elementPath(o.endContainer, t);
                if (a.type == CKEDITOR.NODE_TEXT && (a = a.getParent()), r.blockLimit.is({
                        tr: 1,
                        table: 1
                    })) {
                    var l = r.contains("table").getParent();
                    n = function(e) {
                        return !e.equals(l)
                    }
                } else if (r.block && r.block.is(CKEDITOR.dtd.$listItem)) {
                    var c = i.contains(CKEDITOR.dtd.$list),
                        d = s.contains(CKEDITOR.dtd.$list);
                    if (!c.equals(d)) {
                        var E = r.contains(CKEDITOR.dtd.$list).getParent();
                        n = function(e) {
                            return !e.equals(E)
                        }
                    }
                }
                n || (n = function(e) {
                    return !e.equals(r.block) && !e.equals(r.blockLimit)
                }), this.rebuildFragment(e, t, a, n)
            },
            rebuildFragment: function(e, t, n, o) {
                for (var a; n && !n.equals(t) && o(n);) a = n.clone(0, 1), e.fragment.appendTo(a), e.fragment = a, n = n.getParent()
            }
        },
        cell: {
            shrink: function(e) {
                var t = e.range,
                    n = t.startContainer,
                    o = t.endContainer,
                    a = t.startOffset,
                    r = t.endOffset;
                n.type == CKEDITOR.NODE_ELEMENT && n.equals(o) && n.is("tr") && ++a == r && t.shrink(CKEDITOR.SHRINK_TEXT)
            }
        }
    }, c = function() {
        function e(e, t) {
            var n = e.getParent();
            n.is(CKEDITOR.dtd.$inline) && e[t ? "insertBefore" : "insertAfter"](n)
        }

        function t(t, o, a) {
            var r;
            for (e(o), e(a, 1); r = a.getNext();) r.insertAfter(o), o = r;
            n(t) && t.remove()
        }

        function o(e, t) {
            return new CKEDITOR.dom.elementPath(e, t)
        }

        function a(e, t) {
            var n = new CKEDITOR.dom.range(e);
            return n.setStartAfter(t.startNode), n.setEndBefore(t.endNode), n
        }
        var r = {
                detectMerge: function(e, t) {
                    var n = a(t, e.bookmark),
                        o = n.startPath(),
                        r = n.endPath(),
                        i = o.contains(CKEDITOR.dtd.$list),
                        s = r.contains(CKEDITOR.dtd.$list);
                    if (e.mergeList = i && s && i.getParent().equals(s.getParent()) && !i.equals(s), e.mergeListItems = o.block && r.block && o.block.is(CKEDITOR.dtd.$listItem) && r.block.is(CKEDITOR.dtd.$listItem), e.mergeList || e.mergeListItems) {
                        var l = n.clone();
                        l.setStartBefore(e.bookmark.startNode), l.setEndAfter(e.bookmark.endNode), e.mergeListBookmark = l.createBookmark()
                    }
                },
                merge: function(e, n) {
                    if (e.mergeListBookmark) {
                        var a = e.mergeListBookmark.startNode,
                            r = e.mergeListBookmark.endNode,
                            i = o(a, n),
                            s = o(r, n);
                        if (e.mergeList) {
                            var l = i.contains(CKEDITOR.dtd.$list),
                                c = s.contains(CKEDITOR.dtd.$list);
                            l.equals(c) || (c.moveChildren(l), c.remove())
                        }
                        if (e.mergeListItems) {
                            var d = i.contains(CKEDITOR.dtd.$listItem),
                                E = s.contains(CKEDITOR.dtd.$listItem);
                            d.equals(E) || t(E, a, r)
                        }
                        a.remove(), r.remove()
                    }
                }
            },
            i = {
                detectMerge: function(e, t) {
                    if (!e.tableContentsRanges && !e.mergeListBookmark) {
                        var n = new CKEDITOR.dom.range(t);
                        n.setStartBefore(e.bookmark.startNode), n.setEndAfter(e.bookmark.endNode), e.mergeBlockBookmark = n.createBookmark()
                    }
                },
                merge: function(e, n) {
                    if (e.mergeBlockBookmark && !e.purgeTableBookmark) {
                        var a = e.mergeBlockBookmark.startNode,
                            r = e.mergeBlockBookmark.endNode,
                            i = o(a, n),
                            s = o(r, n),
                            l = i.block,
                            c = s.block;
                        l && c && !l.equals(c) && t(c, a, r), a.remove(), r.remove()
                    }
                }
            },
            s = function() {
                var e = {
                    td: 1,
                    th: 1,
                    caption: 1
                };

                function t(t) {
                    var n, a = [],
                        r = new CKEDITOR.dom.walker(t),
                        i = t.startPath().contains(e),
                        s = t.endPath().contains(e),
                        l = {};
                    return r.guard = function(r, c) {
                        if (r.type == CKEDITOR.NODE_ELEMENT) {
                            var d = "visited_" + (c ? "out" : "in");
                            if (r.getCustomData(d)) return;
                            CKEDITOR.dom.element.setMarker(l, r, d, 1)
                        }
                        return c && i && r.equals(i) ? ((n = t.clone()).setEndAt(i, CKEDITOR.POSITION_BEFORE_END), void a.push(n)) : !c && s && r.equals(s) ? ((n = t.clone()).setStartAt(s, CKEDITOR.POSITION_AFTER_START), void a.push(n)) : void((!c && function(t) {
                            return t.type == CKEDITOR.NODE_ELEMENT && t.is(e) && (!i || o(t, i)) && (!s || o(t, s))
                        }(r) || c && function(t) {
                            if (!t.is(e)) return;
                            var n = i && i.getAscendant("table", !0),
                                o = s && s.getAscendant("table", !0),
                                a = t.getAscendant("table", !0);
                            return n && n.contains(a) || o && o.contains(a)
                        }(r)) && ((n = t.clone()).selectNodeContents(r), a.push(n)))
                    }, r.lastForward(), CKEDITOR.dom.element.clearAllMarkers(l), a
                }

                function o(e, t) {
                    var n = CKEDITOR.POSITION_CONTAINS + CKEDITOR.POSITION_IS_CONTAINED,
                        o = e.getPosition(t);
                    return o !== CKEDITOR.POSITION_IDENTICAL && 0 == (o & n)
                }
                return {
                    detectPurge: function(t) {
                        var n = t.range,
                            o = n.clone();
                        o.enlarge(CKEDITOR.ENLARGE_ELEMENT);
                        var a = new CKEDITOR.dom.walker(o),
                            r = 0;
                        if (a.evaluator = function(t) {
                                t.type == CKEDITOR.NODE_ELEMENT && t.is(e) && ++r
                            }, a.checkForward(), r > 1) {
                            var i = n.startPath().contains("table"),
                                s = n.endPath().contains("table");
                            if (i && s && n.checkBoundaryOfElement(i, CKEDITOR.START) && n.checkBoundaryOfElement(s, CKEDITOR.END)) {
                                var l = t.range.clone();
                                l.setStartBefore(i), l.setEndAfter(s), t.purgeTableBookmark = l.createBookmark()
                            }
                        }
                    },
                    detectRanges: function(n, r) {
                        var i, s, l, c = a(r, n.bookmark),
                            d = c.clone(),
                            E = function(t) {
                                var n = t.getCommonAncestor();
                                return n.is(CKEDITOR.dtd.$tableContent) && !n.is(e) && (n = n.getAscendant("table", !0)), n
                            }(c),
                            u = new CKEDITOR.dom.elementPath(c.startContainer, E),
                            T = new CKEDITOR.dom.elementPath(c.endContainer, E),
                            m = u.contains("table"),
                            h = T.contains("table");
                        (m || h) && (m && h && o(m, h) ? (n.tableSurroundingRange = d, d.setStartAt(m, CKEDITOR.POSITION_AFTER_END), d.setEndAt(h, CKEDITOR.POSITION_BEFORE_START), (i = c.clone()).setEndAt(m, CKEDITOR.POSITION_AFTER_END), (s = c.clone()).setStartAt(h, CKEDITOR.POSITION_BEFORE_START), l = t(i).concat(t(s))) : m ? h || (n.tableSurroundingRange = d, d.setStartAt(m, CKEDITOR.POSITION_AFTER_END), c.setEndAt(m, CKEDITOR.POSITION_AFTER_END)) : (n.tableSurroundingRange = d, d.setEndAt(h, CKEDITOR.POSITION_BEFORE_START), c.setStartAt(h, CKEDITOR.POSITION_AFTER_START)), n.tableContentsRanges = l || t(c))
                    },
                    deleteRanges: function(e) {
                        for (var t; t = e.tableContentsRanges.pop();) t.extractContents(), n(t.startContainer) && t.startContainer.appendBogus();
                        e.tableSurroundingRange && e.tableSurroundingRange.extractContents()
                    },
                    purge: function(e) {
                        if (e.purgeTableBookmark) {
                            var t = e.doc,
                                n = e.range.clone(),
                                o = t.createElement("p");
                            o.insertBefore(e.purgeTableBookmark.startNode), n.moveToBookmark(e.purgeTableBookmark), n.deleteContents(), e.range.moveToPosition(o, CKEDITOR.POSITION_AFTER_START)
                        }
                    }
                }
            }();
        return {
            list: r,
            block: i,
            table: s,
            detectExtractMerge: function(e) {
                return !(e.range.startPath().contains(CKEDITOR.dtd.$listItem) && e.range.endPath().contains(CKEDITOR.dtd.$listItem))
            },
            fixUneditableRangePosition: function(e) {
                e.startContainer.getDtd()["#"] || e.moveToClosestEditablePosition(null, !0)
            },
            autoParagraph: function(e, t) {
                var n, o = t.startPath();
                u(e, o.block, o.blockLimit) && (n = T(e)) && ((n = t.document.createElement(n)).appendBogus(), t.insertNode(n), t.moveToPosition(n, CKEDITOR.POSITION_AFTER_START))
            }
        }
    }()
}();