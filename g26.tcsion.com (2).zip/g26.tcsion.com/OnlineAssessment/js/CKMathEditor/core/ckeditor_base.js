window.CKEDITOR || (window.CKEDITOR = function() {
    var t = /(^|.*[\\\/])ckeditor\.js(?:\?.*|;.*)?$/i,
        e = {
            timestamp: "",
            version: "%VERSION%",
            revision: "%REV%",
            rnd: Math.floor(900 * Math.random()) + 100,
            _: {
                pending: [],
                basePathSrcPattern: t
            },
            status: "unloaded",
            basePath: function() {
                var e = window.CKEDITOR_BASEPATH || "";
                if (!e)
                    for (var n = document.getElementsByTagName("script"), a = 0; a < n.length; a++) {
                        var o = n[a].src.match(t);
                        if (o) {
                            e = o[1];
                            break
                        }
                    }
                if (-1 == e.indexOf(":/") && "//" != e.slice(0, 2) && (e = 0 === e.indexOf("/") ? location.href.match(/^.*?:\/\/[^\/]*/)[0] + e : location.href.match(/^[^\?]*\/(?:)/)[0] + e), !e) throw 'The CKEditor installation path could not be automatically detected. Please set the global variable "CKEDITOR_BASEPATH" before creating editor instances.';
                return e
            }(),
            getUrl: function(t) {
                return -1 == t.indexOf(":/") && 0 !== t.indexOf("/") && (t = this.basePath + t), this.timestamp && "/" != t.charAt(t.length - 1) && !/[&?]t=/.test(t) && (t += (t.indexOf("?") >= 0 ? "&" : "?") + "t=" + this.timestamp), t
            },
            domReady: function() {
                var t = [];

                function e() {
                    try {
                        document.addEventListener ? (document.removeEventListener("DOMContentLoaded", e, !1), n()) : document.attachEvent && "complete" === document.readyState && (document.detachEvent("onreadystatechange", e), n())
                    } catch (t) {}
                }

                function n() {
                    for (var e; e = t.shift();) e()
                }
                return function(n) {
                    if (t.push(n), "complete" === document.readyState && setTimeout(e, 1), 1 == t.length)
                        if (document.addEventListener) document.addEventListener("DOMContentLoaded", e, !1), window.addEventListener("load", e, !1);
                        else if (document.attachEvent) {
                        document.attachEvent("onreadystatechange", e), window.attachEvent("onload", e);
                        var a = !1;
                        try {
                            a = !window.frameElement
                        } catch (t) {}
                        document.documentElement.doScroll && a && function t() {
                            try {
                                document.documentElement.doScroll("left")
                            } catch (e) {
                                return void setTimeout(t, 1)
                            }
                            e()
                        }()
                    }
                }
            }()
        },
        n = window.CKEDITOR_GETURL;
    if (n) {
        var a = e.getUrl;
        e.getUrl = function(t) {
            return n.call(e, t) || a.call(e, t)
        }
    }
    return e
}());