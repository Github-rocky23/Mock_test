! function() {
    var t = '<a id="{id}" class="cke_button cke_button__{name} cke_button_{state} {cls}"' + (CKEDITOR.env.gecko && !CKEDITOR.env.hc ? "" : " href=\"javascript:void('{titleJs}')\"") + ' title="{title}" tabindex="-1" hidefocus="true" role="button" aria-labelledby="{id}_label" aria-describedby="{id}_description" aria-haspopup="{hasArrow}" aria-disabled="{ariaDisabled}"';
    CKEDITOR.env.gecko && CKEDITOR.env.mac && (t += ' onkeypress="return false;"'), CKEDITOR.env.gecko && (t += ' onblur="this.style.cssText = this.style.cssText;"'), t += ' onkeydown="return CKEDITOR.tools.callFunction({keydownFn},event);" onfocus="return CKEDITOR.tools.callFunction({focusFn},event);" ' + (CKEDITOR.env.ie ? 'onclick="return false;" onmouseup' : "onclick") + '="CKEDITOR.tools.callFunction({clickFn},this);return false;"><span class="cke_button_icon cke_button__{iconName}_icon" style="{style}"', t += '>&nbsp;</span><span id="{id}_label" class="cke_button_label cke_button__{name}_label" aria-hidden="false">{label}</span><span id="{id}_description" class="cke_button_label" aria-hidden="false">{ariaShortcut}</span>{arrowHtml}</a>';
    var e = '<span class="cke_button_arrow">' + (CKEDITOR.env.hc ? "&#9660;" : "") + "</span>",
        n = CKEDITOR.addTemplate("buttonArrow", e),
        i = CKEDITOR.addTemplate("button", t);
    CKEDITOR.plugins.add("button", {
        beforeInit: function(t) {
            t.ui.addHandler(CKEDITOR.UI_BUTTON, CKEDITOR.ui.button.handler)
        }
    }), CKEDITOR.UI_BUTTON = "button", CKEDITOR.ui.button = function(t) {
        CKEDITOR.tools.extend(this, t, {
            title: t.label,
            click: t.click || function(e) {
                e.execCommand(t.command)
            }
        }), this._ = {}
    }, CKEDITOR.ui.button.handler = {
        create: function(t) {
            return new CKEDITOR.ui.button(t)
        }
    }, CKEDITOR.ui.button.prototype = {
        render: function(t, e) {
            var o = null;

            function s() {
                var e = t.mode;
                if (e) {
                    var n = this.modes[e] ? void 0 !== o[e] ? o[e] : CKEDITOR.TRISTATE_OFF : CKEDITOR.TRISTATE_DISABLED;
                    n = t.readOnly && !this.readOnly ? CKEDITOR.TRISTATE_DISABLED : n, this.setState(n), this.refresh && this.refresh()
                }
            }
            var a, r, c, l = CKEDITOR.env,
                u = this._.id = CKEDITOR.tools.getNextId(),
                d = "",
                h = this.command;
            this._.editor = t;
            var T, I = {
                    id: u,
                    button: this,
                    editor: t,
                    focus: function() {
                        CKEDITOR.document.getById(u).focus()
                    },
                    execute: function() {
                        this.button.click(t)
                    },
                    attach: function(t) {
                        this.button.attach(t)
                    }
                },
                D = CKEDITOR.tools.addFunction(function(t) {
                    if (I.onkey) return t = new CKEDITOR.dom.event(t), !1 !== I.onkey(I, t.getKeystroke())
                }),
                E = CKEDITOR.tools.addFunction(function(t) {
                    var e;
                    return I.onfocus && (e = !1 !== I.onfocus(I, new CKEDITOR.dom.event(t))), e
                }),
                O = 0;
            I.clickFn = a = CKEDITOR.tools.addFunction(function() {
                O && (t.unlockSelection(1), O = 0), I.execute(), l.iOS && t.focus()
            }), this.modes ? (o = {}, t.on("beforeModeUnload", function() {
                t.mode && this._.state != CKEDITOR.TRISTATE_DISABLED && (o[t.mode] = this._.state)
            }, this), t.on("activeFilterChange", s, this), t.on("mode", s, this), !this.readOnly && t.on("readOnly", s, this)) : h && (h = t.getCommand(h)) && (h.on("state", function() {
                this.setState(h.state)
            }, this), d += h.state == CKEDITOR.TRISTATE_ON ? "on" : h.state == CKEDITOR.TRISTATE_DISABLED ? "disabled" : "off"), this.directional && t.on("contentDirChanged", function(e) {
                var n = CKEDITOR.document.getById(this._.id),
                    i = n.getFirst(),
                    o = e.data;
                o != t.lang.dir ? n.addClass("cke_" + o) : n.removeClass("cke_ltr").removeClass("cke_rtl"), i.setAttribute("style", CKEDITOR.skin.getIconStyle(T, "rtl" == o, this.icon, this.iconOffset))
            }, this), h ? (r = t.getCommandKeystroke(h)) && (c = CKEDITOR.tools.keystrokeToString(t.lang.common.keyboard, r)) : d += "off";
            var C = this.name || this.command,
                R = null,
                f = this.icon;
            T = C, this.icon && !/\./.test(this.icon) ? (T = this.icon, f = null) : (this.icon && (R = this.icon), CKEDITOR.env.hidpi && this.iconHiDpi && (R = this.iconHiDpi)), R ? (CKEDITOR.skin.addIcon(R, R), f = null) : R = T;
            var _ = {
                id: u,
                name: C,
                iconName: T,
                label: this.label,
                cls: (this.hasArrow ? "cke_button_expandable " : "") + (this.className || ""),
                state: d,
                ariaDisabled: "disabled" == d ? "true" : "false",
                title: this.title,
                ariaShortcut: c ? t.lang.common.keyboardShortcut + " " + c.aria : "",
                titleJs: l.gecko && !l.hc ? "" : (this.title || "").replace("'", ""),
                hasArrow: "string" == typeof this.hasArrow && this.hasArrow || (this.hasArrow ? "true" : "false"),
                keydownFn: D,
                focusFn: E,
                clickFn: a,
                style: CKEDITOR.skin.getIconStyle(R, "rtl" == t.lang.dir, f, this.iconOffset),
                arrowHtml: this.hasArrow ? n.output() : ""
            };
            return i.output(_, e), this.onRender && this.onRender(), I
        },
        setState: function(t) {
            if (this._.state == t) return !1;
            this._.state = t;
            var e = CKEDITOR.document.getById(this._.id);
            return !!e && (e.setState(t, "cke_button"), e.setAttribute("aria-disabled", t == CKEDITOR.TRISTATE_DISABLED), this.hasArrow ? e.setAttribute("aria-expanded", t == CKEDITOR.TRISTATE_ON) : t === CKEDITOR.TRISTATE_ON ? e.setAttribute("aria-pressed", !0) : e.removeAttribute("aria-pressed"), !0)
        },
        getState: function() {
            return this._.state
        },
        toFeature: function(t) {
            if (this._.feature) return this._.feature;
            var e = this;
            return this.allowedContent || this.requiredContent || !this.command || (e = t.getCommand(this.command) || e), this._.feature = e
        }
    }, CKEDITOR.ui.prototype.addButton = function(t, e) {
        this.add(t, CKEDITOR.UI_BUTTON, e)
    }
}();