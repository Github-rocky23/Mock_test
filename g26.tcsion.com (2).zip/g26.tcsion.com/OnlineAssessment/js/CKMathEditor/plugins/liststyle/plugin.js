CKEDITOR.plugins.liststyle = {
    requires: "dialog,contextmenu",
    lang: "af,ar,az,bg,bn,bs,ca,cs,cy,da,de,de-ch,el,en,en-au,en-ca,en-gb,eo,es,es-mx,et,eu,fa,fi,fo,fr,fr-ca,gl,gu,he,hi,hr,hu,id,is,it,ja,ka,km,ko,ku,lt,lv,mk,mn,ms,nb,nl,no,oc,pl,pt,pt-br,ro,ru,si,sk,sl,sq,sr,sr-latn,sv,th,tr,tt,ug,uk,vi,zh,zh-cn",
    init: function(e) {
        var t, l;
        e.blockless || (t = new CKEDITOR.dialogCommand("numberedListStyle", {
            requiredContent: "ol",
            allowedContent: "ol{list-style-type}[start]; li{list-style-type}[value]",
            contentTransformations: [
                ["ol: listTypeToStyle"]
            ]
        }), l = e.addCommand("numberedListStyle", t), e.addFeature(l), CKEDITOR.dialog.add("numberedListStyle", this.path + "dialogs/liststyle.js"), t = new CKEDITOR.dialogCommand("bulletedListStyle", {
            requiredContent: "ul",
            allowedContent: "ul{list-style-type}",
            contentTransformations: [
                ["ul: listTypeToStyle"]
            ]
        }), l = e.addCommand("bulletedListStyle", t), e.addFeature(l), CKEDITOR.dialog.add("bulletedListStyle", this.path + "dialogs/liststyle.js"), e.addMenuGroup("list", 108), e.addMenuItems({
            numberedlist: {
                label: e.lang.liststyle.numberedTitle,
                group: "list",
                command: "numberedListStyle"
            },
            bulletedlist: {
                label: e.lang.liststyle.bulletedTitle,
                group: "list",
                command: "bulletedListStyle"
            }
        }), e.contextMenu.addListener(function(e) {
            if (!e || e.isReadOnly()) return null;
            for (; e;) {
                var t = e.getName();
                if ("ol" == t) return {
                    numberedlist: CKEDITOR.TRISTATE_OFF
                };
                if ("ul" == t) return {
                    bulletedlist: CKEDITOR.TRISTATE_OFF
                };
                e = e.getParent()
            }
            return null
        }))
    }
}, CKEDITOR.plugins.add("liststyle", CKEDITOR.plugins.liststyle);