CKEDITOR.plugins.add("popup"), CKEDITOR.tools.extend(CKEDITOR.editor.prototype, {
    popup: function(e, n, t, o) {
        t = t || "70%", "string" == typeof(n = n || "80%") && n.length > 1 && "%" == n.substr(n.length - 1, 1) && (n = parseInt(window.screen.width * parseInt(n, 10) / 100, 10)), "string" == typeof t && t.length > 1 && "%" == t.substr(t.length - 1, 1) && (t = parseInt(window.screen.height * parseInt(t, 10) / 100, 10)), n < 640 && (n = 640), t < 420 && (t = 420);
        var r = parseInt((window.screen.height - t) / 2, 10),
            s = parseInt((window.screen.width - n) / 2, 10);
        o = (o || "location=no,menubar=no,toolbar=no,dependent=yes,minimizable=no,modal=yes,alwaysRaised=yes,resizable=yes,scrollbars=yes") + ",width=" + n + ",height=" + t + ",top=" + r + ",left=" + s;
        var i = window.open("", null, o, !0);
        if (!i) return !1;
        try {
            -1 == navigator.userAgent.toLowerCase().indexOf(" chrome/") && (i.moveTo(s, r), i.resizeTo(n, t)), i.focus(), i.location.href = e
        } catch (n) {
            i = window.open(e, null, o, !0)
        }
        return !0
    }
});