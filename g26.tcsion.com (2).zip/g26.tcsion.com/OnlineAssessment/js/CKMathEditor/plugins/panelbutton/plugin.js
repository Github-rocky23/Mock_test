CKEDITOR.plugins.add("panelbutton", {
    requires: "button",
    onLoad: function() {
        function t(t) {
            var e = this._;
            e.state != CKEDITOR.TRISTATE_DISABLED && (this.createPanel(t), e.on ? e.panel.hide() : e.panel.showBlock(this._.id, this.document.getById(this._.id), 4))
        }
        CKEDITOR.ui.panelButton = CKEDITOR.tools.createClass({
            base: CKEDITOR.ui.button,
            $: function(e) {
                var n = e.panel || {};
                delete e.panel, this.base(e), this.document = n.parent && n.parent.getDocument() || CKEDITOR.document, n.block = {
                    attributes: n.attributes
                }, n.toolbarRelated = !0, this.hasArrow = "listbox", this.click = t, this._ = {
                    panelDefinition: n
                }
            },
            statics: {
                handler: {
                    create: function(t) {
                        return new CKEDITOR.ui.panelButton(t)
                    }
                }
            },
            proto: {
                createPanel: function(t) {
                    var e = this._;
                    if (!e.panel) {
                        var n = this._.panelDefinition,
                            o = this._.panelDefinition.block,
                            a = n.parent || CKEDITOR.document.getBody(),
                            i = this._.panel = new CKEDITOR.ui.floatPanel(t, a, n),
                            s = i.addBlock(e.id, o),
                            l = this;
                        i.onShow = function() {
                            l.className && this.element.addClass(l.className + "_panel"), l.setState(CKEDITOR.TRISTATE_ON), e.on = 1, l.editorFocus && t.focus(), l.onOpen && l.onOpen()
                        }, i.onHide = function(n) {
                            l.className && this.element.getFirst().removeClass(l.className + "_panel"), l.setState(l.modes && l.modes[t.mode] ? CKEDITOR.TRISTATE_OFF : CKEDITOR.TRISTATE_DISABLED), e.on = 0, !n && l.onClose && l.onClose()
                        }, i.onEscape = function() {
                            i.hide(1), l.document.getById(e.id).focus()
                        }, this.onBlock && this.onBlock(i, s), s.onHide = function() {
                            e.on = 0, l.setState(CKEDITOR.TRISTATE_OFF)
                        }
                    }
                }
            }
        })
    },
    beforeInit: function(t) {
        t.ui.addHandler(CKEDITOR.UI_PANELBUTTON, CKEDITOR.ui.panelButton.handler)
    }
}), CKEDITOR.UI_PANELBUTTON = "panelbutton";