CKEDITOR.plugins.add("menu", {
        requires: "floatpanel",
        beforeInit: function(e) {
            for (var t = e.config.menu_groups.split(","), i = e._.menuGroups = {}, n = e._.menuItems = {}, o = 0; o < t.length; o++) i[t[o]] = o + 1;
            e.addMenuGroup = function(e, t) {
                i[e] = t || 100
            }, e.addMenuItem = function(e, t) {
                i[t.group] && (n[e] = new CKEDITOR.menuItem(this, e, t))
            }, e.addMenuItems = function(e) {
                for (var t in e) this.addMenuItem(t, e[t])
            }, e.getMenuItem = function(e) {
                return n[e]
            }, e.removeMenuItem = function(e) {
                delete n[e]
            }
        }
    }),
    function() {
        var e = '<span class="cke_menuitem"><a id="{id}" class="cke_menubutton cke_menubutton__{name} cke_menubutton_{state} {cls}" href="{href}" title="{title}" tabindex="-1" _cke_focus=1 hidefocus="true" role="{role}" aria-label="{label}" aria-describedby="{id}_description" aria-haspopup="{hasPopup}" aria-disabled="{disabled}" {ariaChecked} draggable="false"';
        CKEDITOR.env.gecko && CKEDITOR.env.mac && (e += ' onkeypress="return false;"'), CKEDITOR.env.gecko && (e += ' onblur="this.style.cssText = this.style.cssText;" ondragstart="return false;"'), e += ' onmouseover="CKEDITOR.tools.callFunction({hoverFn},{index});" onmouseout="CKEDITOR.tools.callFunction({moveOutFn},{index});" ' + (CKEDITOR.env.ie ? 'onclick="return false;" onmouseup' : "onclick") + '="CKEDITOR.tools.callFunction({clickFn},{index}); return false;">', e += '<span class="cke_menubutton_inner"><span class="cke_menubutton_icon"><span class="cke_button_icon cke_button__{iconName}_icon" style="{iconStyle}"></span></span><span class="cke_menubutton_label">{label}</span>{shortcutHtml}{arrowHtml}</span></a><span id="{id}_description" class="cke_voice_label" aria-hidden="false">{ariaShortcut}</span></span>';
        var t = CKEDITOR.addTemplate("menuItem", e),
            i = CKEDITOR.addTemplate("menuArrow", '<span class="cke_menuarrow"><span>{label}</span></span>'),
            n = CKEDITOR.addTemplate("menuShortcut", '<span class="cke_menubutton_label cke_menubutton_shortcut">{shortcut}</span>');
        CKEDITOR.menu = CKEDITOR.tools.createClass({
            $: function(e, t) {
                t = this._.definition = t || {}, this.id = CKEDITOR.tools.getNextId(), this.editor = e, this.items = [], this._.listeners = [], this._.level = t.level || 1;
                var i = CKEDITOR.tools.extend({}, t.panel, {
                        css: [CKEDITOR.skin.getPath("editor")],
                        level: this._.level - 1,
                        block: {}
                    }),
                    n = i.block.attributes = i.attributes || {};
                !n.role && (n.role = "menu"), this._.panelDefinition = i
            },
            _: {
                onShow: function() {
                    var e = this.editor.getSelection(),
                        t = e && e.getStartElement(),
                        i = this.editor.elementPath(),
                        n = this._.listeners;
                    this.removeAll();
                    for (var o = 0; o < n.length; o++) {
                        var s = n[o](t, e, i);
                        if (s)
                            for (var a in s) {
                                var l = this.editor.getMenuItem(a);
                                !l || l.command && !this.editor.getCommand(l.command).state || (l.state = s[a], this.add(l))
                            }
                    }
                },
                onClick: function(e) {
                    this.hide(), e.onClick ? e.onClick() : e.command && this.editor.execCommand(e.command)
                },
                onEscape: function(e) {
                    var t = this.parent;
                    return t ? t._.panel.hideChild(1) : 27 == e && this.hide(1), !1
                },
                onHide: function() {
                    this.onHide && this.onHide()
                },
                showSubMenu: function(e) {
                    var t = this._.subMenu,
                        i = this.items[e],
                        n = i.getItems && i.getItems();
                    if (n) {
                        for (var o in t ? t.removeAll() : ((t = this._.subMenu = new CKEDITOR.menu(this.editor, CKEDITOR.tools.extend({}, this._.definition, {
                                level: this._.level + 1
                            }, !0))).parent = this, t._.onClick = CKEDITOR.tools.bind(this._.onClick, this)), n) {
                            var s = this.editor.getMenuItem(o);
                            s && (s.state = n[o], t.add(s))
                        }
                        var a = this._.panel.getBlock(this.id).element.getDocument().getById(this.id + String(e));
                        setTimeout(function() {
                            t.show(a, 2)
                        }, 0)
                    } else this._.panel.hideChild(1)
                }
            },
            proto: {
                add: function(e) {
                    e.order || (e.order = this.items.length), this.items.push(e)
                },
                removeAll: function() {
                    this.items = []
                },
                show: function(e, t, i, n) {
                    if (this.parent || (this._.onShow(), this.items.length)) {
                        t = t || ("rtl" == this.editor.lang.dir ? 2 : 1);
                        var o = this.items,
                            s = this.editor,
                            a = this._.panel,
                            l = this._.element;
                        if (!a) {
                            (a = this._.panel = new CKEDITOR.ui.floatPanel(this.editor, CKEDITOR.document.getBody(), this._.panelDefinition, this._.level)).onEscape = CKEDITOR.tools.bind(function(e) {
                                if (!1 === this._.onEscape(e)) return !1
                            }, this), a.onShow = function() {
                                a._.panel.getHolderElement().getParent().addClass("cke").addClass("cke_reset_all")
                            }, a.onHide = CKEDITOR.tools.bind(function() {
                                this._.onHide && this._.onHide()
                            }, this);
                            var r = a.addBlock(this.id, this._.panelDefinition.block);
                            r.autoSize = !0;
                            var u = r.keys;
                            u[40] = "next", u[9] = "next", u[38] = "prev", u[CKEDITOR.SHIFT + 9] = "prev", u["rtl" == s.lang.dir ? 37 : 39] = CKEDITOR.env.ie ? "mouseup" : "click", u[32] = CKEDITOR.env.ie ? "mouseup" : "click", CKEDITOR.env.ie && (u[13] = "mouseup");
                            var h = (l = this._.element = r.element).getDocument();
                            h.getBody().setStyle("overflow", "hidden"), h.getElementsByTag("html").getItem(0).setStyle("overflow", "hidden"), this._.itemOverFn = CKEDITOR.tools.addFunction(function(e) {
                                clearTimeout(this._.showSubTimeout), this._.showSubTimeout = CKEDITOR.tools.setTimeout(this._.showSubMenu, s.config.menu_subMenuDelay || 400, this, [e])
                            }, this), this._.itemOutFn = CKEDITOR.tools.addFunction(function() {
                                clearTimeout(this._.showSubTimeout)
                            }, this), this._.itemClickFn = CKEDITOR.tools.addFunction(function(e) {
                                var t = this.items[e];
                                t.state != CKEDITOR.TRISTATE_DISABLED ? t.getItems ? this._.showSubMenu(e) : this._.onClick(t) : this.hide(1)
                            }, this)
                        }! function(e) {
                            e.sort(function(e, t) {
                                return e.group < t.group ? -1 : e.group > t.group ? 1 : e.order < t.order ? -1 : e.order > t.order ? 1 : 0
                            })
                        }(o);
                        for (var c = s.elementPath(), d = ['<div class="cke_menu' + (c && c.direction() != s.lang.dir ? " cke_mixed_dir_content" : "") + '" role="presentation">'], m = o.length, _ = m && o[0].group, p = 0; p < m; p++) {
                            var f = o[p];
                            _ != f.group && (d.push('<div class="cke_menuseparator" role="separator"></div>'), _ = f.group), f.render(this, p, d)
                        }
                        d.push("</div>"), l.setHtml(d.join("")), CKEDITOR.ui.fire("ready", this), this.parent ? this.parent._.panel.showAsChild(a, this.id, e, t, i, n) : a.showBlock(this.id, e, t, i, n);
                        var T = [a];
                        s.fire("menuShow", T)
                    }
                },
                addListener: function(e) {
                    this._.listeners.push(e)
                },
                hide: function(e) {
                    this._.onHide && this._.onHide(), this._.panel && this._.panel.hide(e)
                },
                findItemByCommandName: function(e) {
                    var t = CKEDITOR.tools.array.filter(this.items, function(t) {
                        return e === t.command
                    });
                    if (t.length) {
                        var i = t[0];
                        return {
                            item: i,
                            element: this._.element.findOne("." + i.className)
                        }
                    }
                    return null
                }
            }
        }), CKEDITOR.menuItem = CKEDITOR.tools.createClass({
            $: function(e, t, i) {
                CKEDITOR.tools.extend(this, i, {
                    order: 0,
                    className: "cke_menubutton__" + t
                }), this.group = e._.menuGroups[this.group], this.editor = e, this.name = t
            },
            proto: {
                render: function(e, o, s) {
                    var a, l, r, u = e.id + String(o),
                        h = void 0 === this.state ? CKEDITOR.TRISTATE_OFF : this.state,
                        c = "",
                        d = this.editor,
                        m = h == CKEDITOR.TRISTATE_ON ? "on" : h == CKEDITOR.TRISTATE_DISABLED ? "disabled" : "off";
                    this.role in {
                        menuitemcheckbox: 1,
                        menuitemradio: 1
                    } && (c = ' aria-checked="' + (h == CKEDITOR.TRISTATE_ON ? "true" : "false") + '"');
                    var _ = this.getItems,
                        p = "&#" + ("rtl" == this.editor.lang.dir ? "9668" : "9658") + ";",
                        f = this.name;
                    this.icon && !/\./.test(this.icon) && (f = this.icon), this.command && (l = d.getCommand(this.command), (a = d.getCommandKeystroke(l)) && (r = CKEDITOR.tools.keystrokeToString(d.lang.common.keyboard, a)));
                    var T = {
                        id: u,
                        name: this.name,
                        iconName: f,
                        label: this.label,
                        cls: this.className || "",
                        state: m,
                        hasPopup: _ ? "true" : "false",
                        disabled: h == CKEDITOR.TRISTATE_DISABLED,
                        title: this.label + (r ? " (" + r.display + ")" : ""),
                        ariaShortcut: r ? d.lang.common.keyboardShortcut + " " + r.aria : "",
                        href: "javascript:void('" + (this.label || "").replace("'") + "')",
                        hoverFn: e._.itemOverFn,
                        moveOutFn: e._.itemOutFn,
                        clickFn: e._.itemClickFn,
                        index: o,
                        iconStyle: CKEDITOR.skin.getIconStyle(f, "rtl" == this.editor.lang.dir, f == this.icon ? null : this.icon, this.iconOffset),
                        shortcutHtml: r ? n.output({
                            shortcut: r.display
                        }) : "",
                        arrowHtml: _ ? i.output({
                            label: p
                        }) : "",
                        role: this.role ? this.role : "menuitem",
                        ariaChecked: c
                    };
                    t.output(T, s)
                }
            }
        })
    }(), CKEDITOR.config.menu_groups = "clipboard,form,tablecell,tablecellproperties,tablerow,tablecolumn,table,anchor,link,image,flash,checkbox,radio,textfield,hiddenfield,imagebutton,button,select,textarea,div";