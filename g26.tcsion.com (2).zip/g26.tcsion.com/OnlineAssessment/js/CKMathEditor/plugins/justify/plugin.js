! function() {
    function t(t, e) {
        var s;
        if (e = void 0 === e || e) s = t.getComputedStyle("text-align");
        else {
            for (; !t.hasAttribute || !t.hasAttribute("align") && !t.getStyle("text-align");) {
                var a = t.getParent();
                if (!a) break;
                t = a
            }
            s = t.getStyle("text-align") || t.getAttribute("align") || ""
        }
        return s && (s = s.replace(/(?:-(?:moz|webkit)-)?(?:start|auto)/i, "")), !s && e && (s = "rtl" == t.getComputedStyle("direction") ? "right" : "left"), s
    }

    function e(t, e, s) {
        this.editor = t, this.name = e, this.value = s, this.context = "p";
        var a = t.config.justifyClasses,
            i = t.config.enterMode == CKEDITOR.ENTER_P ? "p" : "div";
        if (a) {
            switch (s) {
                case "left":
                    this.cssClassName = a[0];
                    break;
                case "center":
                    this.cssClassName = a[1];
                    break;
                case "right":
                    this.cssClassName = a[2];
                    break;
                case "justify":
                    this.cssClassName = a[3]
            }
            this.cssClassRegex = new RegExp("(?:^|\\s+)(?:" + a.join("|") + ")(?=$|\\s)"), this.requiredContent = i + "(" + this.cssClassName + ")"
        } else this.requiredContent = i + "{text-align}";
        this.allowedContent = {
            "caption div h1 h2 h3 h4 h5 h6 p pre td th li": {
                propertiesOnly: !0,
                styles: this.cssClassName ? null : "text-align",
                classes: this.cssClassName || null
            }
        }, t.config.enterMode == CKEDITOR.ENTER_BR && (this.allowedContent.div = !0)
    }

    function s(t) {
        var e = t.editor,
            s = e.createRange();
        s.setStartBefore(t.data.node), s.setEndAfter(t.data.node);
        for (var a, i = new CKEDITOR.dom.walker(s); a = i.next();)
            if (a.type == CKEDITOR.NODE_ELEMENT) {
                if (!a.equals(t.data.node) && a.getDirection()) {
                    s.setStartAfter(a), i = new CKEDITOR.dom.walker(s);
                    continue
                }
                var l = e.config.justifyClasses;
                l && (a.hasClass(l[0]) ? (a.removeClass(l[0]), a.addClass(l[2])) : a.hasClass(l[2]) && (a.removeClass(l[2]), a.addClass(l[0])));
                var n = "text-align",
                    o = a.getStyle(n);
                "left" == o ? a.setStyle(n, "right") : "right" == o && a.setStyle(n, "left")
            }
    }
    e.prototype = {
        exec: function(e) {
            var s = e.getSelection(),
                a = e.config.enterMode;
            if (s) {
                var i, l, n = s.createBookmarks(),
                    o = s.getRanges(),
                    r = this.cssClassName,
                    c = e.config.useComputedState;
                c = void 0 === c || c;
                for (var d = o.length - 1; d >= 0; d--)
                    for ((i = o[d].createIterator()).enlargeBr = a != CKEDITOR.ENTER_BR; l = i.getNextParagraph(a == CKEDITOR.ENTER_P ? "p" : "div");)
                        if (!l.isReadOnly()) {
                            var f, u, g = l.getName();
                            if (f = e.activeFilter.check(g + "{text-align}"), (u = e.activeFilter.check(g + "(" + r + ")")) || f) {
                                l.removeAttribute("align"), l.removeStyle("text-align");
                                var h = r && (l.$.className = CKEDITOR.tools.ltrim(l.$.className.replace(this.cssClassRegex, ""))),
                                    m = this.state == CKEDITOR.TRISTATE_OFF && (!c || t(l, !0) != this.value);
                                r && u ? m ? l.addClass(r) : h || l.removeAttribute("class") : m && f && l.setStyle("text-align", this.value)
                            }
                        }
                e.focus(), e.forceNextSelectionCheck(), s.selectBookmarks(n)
            }
        },
        refresh: function(e, s) {
            var a = s.block || s.blockLimit,
                i = a.getName(),
                l = a.equals(e.editable()),
                n = this.cssClassName ? e.activeFilter.check(i + "(" + this.cssClassName + ")") : e.activeFilter.check(i + "{text-align}");
            l && 1 === s.elements.length ? this.setState(CKEDITOR.TRISTATE_OFF) : !l && n ? this.setState(t(a, this.editor.config.useComputedState) == this.value ? CKEDITOR.TRISTATE_ON : CKEDITOR.TRISTATE_OFF) : this.setState(CKEDITOR.TRISTATE_DISABLED)
        }
    }, CKEDITOR.plugins.add("justify", {
        icons: "justifyblock,justifycenter,justifyleft,justifyright",
        hidpi: !0,
        init: function(t) {
            if (!t.blockless) {
                var a = new e(t, "justifyleft", "left"),
                    i = new e(t, "justifycenter", "center"),
                    l = new e(t, "justifyright", "right"),
                    n = new e(t, "justifyblock", "justify");
                t.addCommand("justifyleft", a), t.addCommand("justifycenter", i), t.addCommand("justifyright", l), t.addCommand("justifyblock", n), t.ui.addButton && (t.ui.addButton("JustifyLeft", {
                    label: t.lang.common.alignLeft,
                    command: "justifyleft",
                    toolbar: "align,10"
                }), t.ui.addButton("JustifyCenter", {
                    label: t.lang.common.center,
                    command: "justifycenter",
                    toolbar: "align,20"
                }), t.ui.addButton("JustifyRight", {
                    label: t.lang.common.alignRight,
                    command: "justifyright",
                    toolbar: "align,30"
                }), t.ui.addButton("JustifyBlock", {
                    label: t.lang.common.justify,
                    command: "justifyblock",
                    toolbar: "align,40"
                })), t.on("dirChanged", s)
            }
        }
    })
}();