"use strict";
! function() {
    function t(t, e) {
        CKEDITOR.tools.extend(this, {
            editor: t,
            editable: t.editable(),
            doc: t.document,
            win: t.window
        }, e, !0), this.inline = this.editable.isInline(), this.inline || (this.frame = this.win.getFrame()), this.target = this[this.inline ? "editable" : "doc"]
    }
    var e;

    function i(t, e) {
        CKEDITOR.tools.extend(this, e, {
            editor: t
        }, !0)
    }
    CKEDITOR.plugins.add("lineutils"), CKEDITOR.LINEUTILS_BEFORE = 1, CKEDITOR.LINEUTILS_AFTER = 2, CKEDITOR.LINEUTILS_INSIDE = 4, t.prototype = {
        start: function(t) {
            var e, i, n, s, o = this,
                r = this.editor,
                h = this.doc,
                l = CKEDITOR.tools.eventsBuffer(50, function() {
                    r.readOnly || "wysiwyg" != r.mode || (o.relations = {}, (i = h.$.elementFromPoint(n, s)) && i.nodeType && (e = new CKEDITOR.dom.element(i), o.traverseSearch(e), isNaN(n + s) || o.pixelSearch(e, n, s), t && t(o.relations, n, s)))
                });
            this.listener = this.editable.attachListener(this.target, "mousemove", function(t) {
                n = t.data.$.clientX, s = t.data.$.clientY, l.input()
            }), this.editable.attachListener(this.inline ? this.editable : this.frame, "mouseout", function() {
                l.reset()
            })
        },
        stop: function() {
            this.listener && this.listener.removeListener()
        },
        getRange: (e = {}, e[CKEDITOR.LINEUTILS_BEFORE] = CKEDITOR.POSITION_BEFORE_START, e[CKEDITOR.LINEUTILS_AFTER] = CKEDITOR.POSITION_AFTER_END, e[CKEDITOR.LINEUTILS_INSIDE] = CKEDITOR.POSITION_AFTER_START, function(t) {
            var i = this.editor.createRange();
            return i.moveToPosition(this.relations[t.uid].element, e[t.type]), i
        }),
        store: function() {
            function t(t, e, i) {
                var n = t.getUniqueId();
                n in i ? i[n].type |= e : i[n] = {
                    element: t,
                    type: e
                }
            }
            return function(e, i) {
                var n;
                h(i, CKEDITOR.LINEUTILS_AFTER) && d(n = e.getNext()) && n.isVisible() && (t(n, CKEDITOR.LINEUTILS_BEFORE, this.relations), i ^= CKEDITOR.LINEUTILS_AFTER), h(i, CKEDITOR.LINEUTILS_INSIDE) && d(n = e.getFirst()) && n.isVisible() && (t(n, CKEDITOR.LINEUTILS_BEFORE, this.relations), i ^= CKEDITOR.LINEUTILS_INSIDE), t(e, i, this.relations)
            }
        }(),
        traverseSearch: function(t) {
            var e, i, n, s;
            do {
                if (!((n = t.$["data-cke-expando"]) && n in this.relations)) {
                    if (t.equals(this.editable)) return;
                    if (d(t))
                        for (e in this.lookups)(i = this.lookups[e](t)) && this.store(t, i)
                }
            } while ((!c(s = t) || "true" != s.getAttribute("contenteditable")) && (t = t.getParent()))
        },
        pixelSearch: function() {
            var t = CKEDITOR.env.ie || CKEDITOR.env.webkit ? function(t, e) {
                return t.contains(e)
            } : function(t, e) {
                return !!(16 & t.compareDocumentPosition(e))
            };

            function e(e, i, n, s, o) {
                for (var r, h = n, l = 0; o(h);) {
                    if (h += s, 25 == ++l) return;
                    if (r = this.doc.$.elementFromPoint(i, h))
                        if (r != e) {
                            if (t(e, r) && (l = 0, d(r = new CKEDITOR.dom.element(r)))) return r
                        } else l = 0
                }
            }
            return function(t, i, n) {
                var s = this.win.getViewPaneSize().height,
                    o = e.call(this, t.$, i, n, -1, function(t) {
                        return t > 0
                    }),
                    r = e.call(this, t.$, i, n, 1, function(t) {
                        return t < s
                    });
                if (o)
                    for (this.traverseSearch(o); !o.getParent().equals(t);) o = o.getParent();
                if (r)
                    for (this.traverseSearch(r); !r.getParent().equals(t);) r = r.getParent();
                for (;
                    (o || r) && (o && (o = o.getNext(d)), o && !o.equals(r)) && (this.traverseSearch(o), r && (r = r.getPrevious(d)), r && !r.equals(o));) this.traverseSearch(r)
            }
        }(),
        greedySearch: function() {
            this.relations = {};
            for (var t, e, i, n = this.editable.getElementsByTag("*"), s = 0; t = n.getItem(s++);)
                if (!t.equals(this.editable) && t.type == CKEDITOR.NODE_ELEMENT && (t.hasAttribute("contenteditable") || !t.isReadOnly()) && d(t) && t.isVisible())
                    for (i in this.lookups)(e = this.lookups[i](t)) && this.store(t, e);
            return this.relations
        }
    }, i.prototype = {
        locate: function() {
            function t(t, e) {
                var i = t.element[e === CKEDITOR.LINEUTILS_BEFORE ? "getPrevious" : "getNext"]();
                return i && d(i) ? (t.siblingRect = i.getClientRect(), e == CKEDITOR.LINEUTILS_BEFORE ? (t.siblingRect.bottom + t.elementRect.top) / 2 : (t.elementRect.bottom + t.siblingRect.top) / 2) : e == CKEDITOR.LINEUTILS_BEFORE ? t.elementRect.top : t.elementRect.bottom
            }
            return function(e) {
                var i;
                for (var n in this.locations = {}, e)(i = e[n]).elementRect = i.element.getClientRect(), h(i.type, CKEDITOR.LINEUTILS_BEFORE) && this.store(n, CKEDITOR.LINEUTILS_BEFORE, t(i, CKEDITOR.LINEUTILS_BEFORE)), h(i.type, CKEDITOR.LINEUTILS_AFTER) && this.store(n, CKEDITOR.LINEUTILS_AFTER, t(i, CKEDITOR.LINEUTILS_AFTER)), h(i.type, CKEDITOR.LINEUTILS_INSIDE) && this.store(n, CKEDITOR.LINEUTILS_INSIDE, (i.elementRect.top + i.elementRect.bottom) / 2);
                return this.locations
            }
        }(),
        sort: function() {
            var t, e, i, n;

            function s(e, i, n) {
                return Math.abs(e - t[i][n])
            }
            return function(o, r) {
                for (var h in t = this.locations, e = [], t)
                    for (var l in t[h])
                        if (i = s(o, h, l), e.length) {
                            for (n = 0; n < e.length; n++)
                                if (i < e[n].dist) {
                                    e.splice(n, 0, {
                                        uid: +h,
                                        type: l,
                                        dist: i
                                    });
                                    break
                                }
                            n == e.length && e.push({
                                uid: +h,
                                type: l,
                                dist: i
                            })
                        } else e.push({
                            uid: +h,
                            type: l,
                            dist: i
                        });
                return void 0 !== r ? e.slice(0, r) : e
            }
        }(),
        store: function(t, e, i) {
            this.locations[t] || (this.locations[t] = {}), this.locations[t][e] = i
        }
    };
    var n = {
            display: "block",
            width: "0px",
            height: "0px",
            "border-color": "transparent",
            "border-style": "solid",
            position: "absolute",
            top: "-6px"
        },
        s = {
            height: "0px",
            "border-top": "1px dashed red",
            position: "absolute",
            "z-index": 9999
        },
        o = '<div data-cke-lineutils-line="1" class="cke_reset_all" style="{lineStyle}"><span style="{tipLeftStyle}">&nbsp;</span><span style="{tipRightStyle}">&nbsp;</span></div>';

    function r(t, e) {
        var i = t.editable();
        CKEDITOR.tools.extend(this, {
            editor: t,
            editable: i,
            inline: i.isInline(),
            doc: t.document,
            win: t.window,
            container: CKEDITOR.document.getBody(),
            winTop: CKEDITOR.document.getWindow()
        }, e, !0), this.hidden = {}, this.visible = {}, this.inline || (this.frame = this.win.getFrame()), this.queryViewport();
        var r = CKEDITOR.tools.bind(this.queryViewport, this),
            h = CKEDITOR.tools.bind(this.hideVisible, this),
            l = CKEDITOR.tools.bind(this.removeAll, this);
        i.attachListener(this.winTop, "resize", r), i.attachListener(this.winTop, "scroll", r), i.attachListener(this.winTop, "resize", h), i.attachListener(this.win, "scroll", h), i.attachListener(this.inline ? i : this.frame, "mouseout", function(t) {
            var e = t.data.$.clientX,
                i = t.data.$.clientY;
            this.queryViewport(), (e <= this.rect.left || e >= this.rect.right || i <= this.rect.top || i >= this.rect.bottom) && this.hideVisible(), (e <= 0 || e >= this.winTopPane.width || i <= 0 || i >= this.winTopPane.height) && this.hideVisible()
        }, this), i.attachListener(t, "resize", r), i.attachListener(t, "mode", l), t.on("destroy", l), this.lineTpl = new CKEDITOR.template(o).output({
            lineStyle: CKEDITOR.tools.writeCssText(CKEDITOR.tools.extend({}, s, this.lineStyle, !0)),
            tipLeftStyle: CKEDITOR.tools.writeCssText(CKEDITOR.tools.extend({}, n, {
                left: "0px",
                "border-left-color": "red",
                "border-width": "6px 0 6px 6px"
            }, this.tipCss, this.tipLeftStyle, !0)),
            tipRightStyle: CKEDITOR.tools.writeCssText(CKEDITOR.tools.extend({}, n, {
                right: "0px",
                "border-right-color": "red",
                "border-width": "6px 6px 6px 0"
            }, this.tipCss, this.tipRightStyle, !0))
        })
    }

    function h(t, e) {
        return t & e
    }
    r.prototype = {
        removeAll: function() {
            var t;
            for (t in this.hidden) this.hidden[t].remove(), delete this.hidden[t];
            for (t in this.visible) this.visible[t].remove(), delete this.visible[t]
        },
        hideLine: function(t) {
            var e = t.getUniqueId();
            t.hide(), this.hidden[e] = t, delete this.visible[e]
        },
        showLine: function(t) {
            var e = t.getUniqueId();
            t.show(), this.visible[e] = t, delete this.hidden[e]
        },
        hideVisible: function() {
            for (var t in this.visible) this.hideLine(this.visible[t])
        },
        placeLine: function(t, e) {
            var i, n, s;
            if (i = this.getStyle(t.uid, t.type)) {
                for (s in this.visible)
                    if (this.visible[s].getCustomData("hash") !== this.hash) {
                        n = this.visible[s];
                        break
                    }
                if (!n)
                    for (s in this.hidden)
                        if (this.hidden[s].getCustomData("hash") !== this.hash) {
                            this.showLine(n = this.hidden[s]);
                            break
                        }
                n || this.showLine(n = this.addLine()), n.setCustomData("hash", this.hash), this.visible[n.getUniqueId()] = n, n.setStyles(i), e && e(n)
            }
        },
        getStyle: function(t, e) {
            var i, n = this.relations[t],
                s = this.locations[t][e],
                o = {};
            if (n.siblingRect ? o.width = Math.max(n.siblingRect.width, n.elementRect.width) : o.width = n.elementRect.width, this.inline ? o.top = s + this.winTopScroll.y - this.rect.relativeY : o.top = this.rect.top + this.winTopScroll.y + s, o.top - this.winTopScroll.y < this.rect.top || o.top - this.winTopScroll.y > this.rect.bottom) return !1;
            for (var r in this.inline ? o.left = n.elementRect.left - this.rect.relativeX : (n.elementRect.left > 0 ? o.left = this.rect.left + n.elementRect.left : (o.width += n.elementRect.left, o.left = this.rect.left), (i = o.left + o.width - (this.rect.left + this.winPane.width)) > 0 && (o.width -= i)), o.left += this.winTopScroll.x, o) o[r] = CKEDITOR.tools.cssLength(o[r]);
            return o
        },
        addLine: function() {
            var t = CKEDITOR.dom.element.createFromHtml(this.lineTpl);
            return t.appendTo(this.container), t
        },
        prepare: function(t, e) {
            this.relations = t, this.locations = e, this.hash = Math.random()
        },
        cleanup: function() {
            var t;
            for (var e in this.visible)(t = this.visible[e]).getCustomData("hash") !== this.hash && this.hideLine(t)
        },
        queryViewport: function() {
            this.winPane = this.win.getViewPaneSize(), this.winTopScroll = this.winTop.getScrollPosition(), this.winTopPane = this.winTop.getViewPaneSize(), this.rect = this.getClientRect(this.inline ? this.editable : this.frame)
        },
        getClientRect: function(t) {
            var e = t.getClientRect(),
                i = this.container.getDocumentPosition(),
                n = this.container.getComputedStyle("position");
            return e.relativeX = e.relativeY = 0, "static" != n && (e.relativeY = i.y, e.relativeX = i.x, e.top -= e.relativeY, e.bottom -= e.relativeY, e.left -= e.relativeX, e.right -= e.relativeX), e
        }
    };
    var l = {
            left: 1,
            right: 1,
            center: 1
        },
        a = {
            absolute: 1,
            fixed: 1
        };

    function c(t) {
        return t && t.type == CKEDITOR.NODE_ELEMENT
    }

    function d(t) {
        return c(t) && !(l[(e = t).getComputedStyle("float")] || l[e.getAttribute("align")]) && ! function(t) {
            return !!a[t.getComputedStyle("position")]
        }(t);
        var e
    }
    CKEDITOR.plugins.lineutils = {
        finder: t,
        locator: i,
        liner: r
    }
}();