CKEDITOR.plugins.add("resize", {
    init: function(e) {
        function i(i) {
            var t = i.data.$.screenX - s.x,
                r = i.data.$.screenY - s.y,
                a = m.width,
                u = m.height,
                c = a + t * ("rtl" == o ? -1 : 1),
                z = u + r;
            d && (a = Math.max(n.resize_minWidth, Math.min(c, n.resize_maxWidth))), h && (u = Math.max(n.resize_minHeight, Math.min(z, n.resize_maxHeight))), e.resize(d ? a : null, u)
        }

        function t() {
            CKEDITOR.document.removeListener("mousemove", i), CKEDITOR.document.removeListener("mouseup", t), e.document && (e.document.removeListener("mousemove", i), e.document.removeListener("mouseup", t))
        }
        var n = e.config,
            r = e.ui.spaceId("resizer"),
            o = e.element ? e.element.getDirection(1) : "ltr";
        if (!n.resize_dir && (n.resize_dir = "vertical"), void 0 === n.resize_maxWidth && (n.resize_maxWidth = 3e3), void 0 === n.resize_maxHeight && (n.resize_maxHeight = 3e3), void 0 === n.resize_minWidth && (n.resize_minWidth = 750), void 0 === n.resize_minHeight && (n.resize_minHeight = 250), !1 !== n.resize_enabled) {
            var s, m, a = null,
                d = ("both" == n.resize_dir || "horizontal" == n.resize_dir) && n.resize_minWidth != n.resize_maxWidth,
                h = ("both" == n.resize_dir || "vertical" == n.resize_dir) && n.resize_minHeight != n.resize_maxHeight,
                u = CKEDITOR.tools.addFunction(function(r) {
                    a || (a = e.getResizable()), m = {
                        width: a.$.offsetWidth || 0,
                        height: a.$.offsetHeight || 0
                    }, s = {
                        x: r.screenX,
                        y: r.screenY
                    }, n.resize_minWidth > m.width && (n.resize_minWidth = m.width), n.resize_minHeight > m.height && (n.resize_minHeight = m.height), CKEDITOR.document.on("mousemove", i), CKEDITOR.document.on("mouseup", t), e.document && (e.document.on("mousemove", i), e.document.on("mouseup", t)), r.preventDefault && r.preventDefault()
                });
            e.on("destroy", function() {
                CKEDITOR.tools.removeFunction(u)
            }), e.on("uiSpace", function(i) {
                if ("bottom" == i.data.space) {
                    var t = "";
                    d && !h && (t = " cke_resizer_horizontal"), !d && h && (t = " cke_resizer_vertical");
                    var n = '<span id="' + r + '" class="cke_resizer' + t + " cke_resizer_" + o + '" title="' + CKEDITOR.tools.htmlEncode(e.lang.common.resize) + '" onmousedown="CKEDITOR.tools.callFunction(' + u + ', event)">' + ("ltr" == o ? "◢" : "◣") + "</span>";
                    "ltr" == o && "ltr" == t ? i.data.html += n : i.data.html = n + i.data.html
                }
            }, e, null, 100), e.on("maximize", function(i) {
                e.ui.space("resizer")[i.data == CKEDITOR.TRISTATE_ON ? "hide" : "show"]()
            })
        }
    }
});