! function() {
    "use strict";

    function t(t, i, e) {
        this.editor = t, this.notification = null, this._message = new CKEDITOR.template(i), this._singularMessage = e ? new CKEDITOR.template(e) : null, this._tasks = [], this._totalWeights = 0, this._doneWeights = 0, this._doneTasks = 0
    }

    function i(t) {
        this._weight = t || 1, this._doneWeight = 0, this._isCanceled = !1
    }
    CKEDITOR.plugins.add("notificationaggregator", {
        requires: "notification"
    }), t.prototype = {
        createTask: function(t) {
            t = t || {};
            var i, e = !this.notification;
            return e && (this.notification = this._createNotification()), (i = this._addTask(t)).on("updated", this._onTaskUpdate, this), i.on("done", this._onTaskDone, this), i.on("canceled", function() {
                this._removeTask(i)
            }, this), this.update(), e && this.notification.show(), i
        },
        update: function() {
            this._updateNotification(), this.isFinished() && this.fire("finished")
        },
        getPercentage: function() {
            return 0 === this.getTaskCount() ? 1 : this._doneWeights / this._totalWeights
        },
        isFinished: function() {
            return this.getDoneTaskCount() === this.getTaskCount()
        },
        getTaskCount: function() {
            return this._tasks.length
        },
        getDoneTaskCount: function() {
            return this._doneTasks
        },
        _updateNotification: function() {
            this.notification.update({
                message: this._getNotificationMessage(),
                progress: this.getPercentage()
            })
        },
        _getNotificationMessage: function() {
            var t = this.getTaskCount(),
                i = {
                    current: this.getDoneTaskCount(),
                    max: t,
                    percentage: Math.round(100 * this.getPercentage())
                };
            return (1 == t && this._singularMessage ? this._singularMessage : this._message).output(i)
        },
        _createNotification: function() {
            return new CKEDITOR.plugins.notification(this.editor, {
                type: "progress"
            })
        },
        _addTask: function(t) {
            var e = new i(t.weight);
            return this._tasks.push(e), this._totalWeights += e._weight, e
        },
        _removeTask: function(t) {
            var i = CKEDITOR.tools.indexOf(this._tasks, t); - 1 !== i && (t._doneWeight && (this._doneWeights -= t._doneWeight), this._totalWeights -= t._weight, this._tasks.splice(i, 1), this.update())
        },
        _onTaskUpdate: function(t) {
            this._doneWeights += t.data, this.update()
        },
        _onTaskDone: function() {
            this._doneTasks += 1, this.update()
        }
    }, CKEDITOR.event.implementOn(t.prototype), i.prototype = {
        done: function() {
            this.update(this._weight)
        },
        update: function(t) {
            if (!this.isDone() && !this.isCanceled()) {
                var i = Math.min(this._weight, t),
                    e = i - this._doneWeight;
                this._doneWeight = i, this.fire("updated", e), this.isDone() && this.fire("done")
            }
        },
        cancel: function() {
            this.isDone() || this.isCanceled() || (this._isCanceled = !0, this.fire("canceled"))
        },
        isDone: function() {
            return this._weight === this._doneWeight
        },
        isCanceled: function() {
            return this._isCanceled
        }
    }, CKEDITOR.event.implementOn(i.prototype), CKEDITOR.plugins.notificationAggregator = t, CKEDITOR.plugins.notificationAggregator.task = i
}();