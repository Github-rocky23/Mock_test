CKEDITOR.plugins.add("dialogui", {
    onLoad: function() {
        var e, t, i, l = function(e) {
                this._ || (this._ = {}), this._.default = this._.initValue = e.default || "", this._.required = e.required || !1;
                for (var t = [this._], i = 1; i < arguments.length; i++) t.push(arguments[i]);
                return t.push(!0), CKEDITOR.tools.extend.apply(CKEDITOR.tools, t), this._
            },
            n = {
                build: function(e, t, i) {
                    return new CKEDITOR.ui.dialog.textInput(e, t, i)
                }
            },
            o = {
                build: function(e, t, i) {
                    return new CKEDITOR.ui.dialog[t.type](e, t, i)
                }
            },
            a = {
                build: function(e, t, i) {
                    for (var l, n = t.children, o = [], a = [], s = 0; s < n.length && (l = n[s]); s++) {
                        var u = [];
                        o.push(u), a.push(CKEDITOR.dialog._.uiElementBuilders[l.type].build(e, l, u))
                    }
                    return new CKEDITOR.ui.dialog[t.type](e, a, o, i, t)
                }
            },
            s = {
                isChanged: function() {
                    return this.getValue() != this.getInitValue()
                },
                reset: function(e) {
                    this.setValue(this.getInitValue(), e)
                },
                setInitValue: function() {
                    this._.initValue = this.getValue()
                },
                resetInitValue: function() {
                    this._.initValue = this._.default
                },
                getInitValue: function() {
                    return this._.initValue
                }
            },
            u = CKEDITOR.tools.extend({}, CKEDITOR.ui.dialog.uiElement.prototype.eventProcessors, {
                onChange: function(e, t) {
                    this._.domOnChangeRegistered || (e.on("load", function() {
                        this.getInputElement().on("change", function() {
                            e.parts.dialog.isVisible() && this.fire("change", {
                                value: this.getValue()
                            })
                        }, this)
                    }, this), this._.domOnChangeRegistered = !0), this.on("change", t)
                }
            }, !0),
            d = /^on([A-Z]\w+)/,
            r = function(e) {
                for (var t in e)(d.test(t) || "title" == t || "type" == t) && delete e[t];
                return e
            },
            c = function(e) {
                var t = e.data.getKeystroke();
                t == CKEDITOR.SHIFT + CKEDITOR.ALT + 36 ? this.setDirectionMarker("ltr") : t == CKEDITOR.SHIFT + CKEDITOR.ALT + 35 && this.setDirectionMarker("rtl")
            };
        CKEDITOR.tools.extend(CKEDITOR.ui.dialog, {
            labeledElement: function(e, t, i, n) {
                if (!(arguments.length < 4)) {
                    var o = l.call(this, t);
                    o.labelId = CKEDITOR.tools.getNextId() + "_label", this._.children = [];
                    var a = {
                        role: t.role || "presentation"
                    };
                    t.includeLabel && (a["aria-labelledby"] = o.labelId), CKEDITOR.ui.dialog.uiElement.call(this, e, t, i, "div", null, a, function() {
                        var i = [],
                            l = t.required ? " cke_required" : "";
                        if ("horizontal" != t.labelLayout) i.push('<label class="cke_dialog_ui_labeled_label' + l + '" ', ' id="' + o.labelId + '"', o.inputId ? ' for="' + o.inputId + '"' : "", (t.labelStyle ? ' style="' + t.labelStyle + '"' : "") + ">", t.label, "</label>", '<div class="cke_dialog_ui_labeled_content"', t.controlStyle ? ' style="' + t.controlStyle + '"' : "", ' role="presentation">', n.call(this, e, t), "</div>");
                        else {
                            var a = {
                                type: "hbox",
                                widths: t.widths,
                                padding: 0,
                                children: [{
                                    type: "html",
                                    html: '<label class="cke_dialog_ui_labeled_label' + l + '" id="' + o.labelId + '" for="' + o.inputId + '"' + (t.labelStyle ? ' style="' + t.labelStyle + '"' : "") + ">" + CKEDITOR.tools.htmlEncode(t.label) + "</label>"
                                }, {
                                    type: "html",
                                    html: '<span class="cke_dialog_ui_labeled_content"' + (t.controlStyle ? ' style="' + t.controlStyle + '"' : "") + ">" + n.call(this, e, t) + "</span>"
                                }]
                            };
                            CKEDITOR.dialog._.uiElementBuilders.hbox.build(e, a, i)
                        }
                        return i.join("")
                    })
                }
            },
            textInput: function(e, t, i) {
                if (!(arguments.length < 3)) {
                    l.call(this, t);
                    var n = this._.inputId = CKEDITOR.tools.getNextId() + "_textInput",
                        o = {
                            class: "cke_dialog_ui_input_" + t.type,
                            id: n,
                            type: t.type
                        };
                    t.validate && (this.validate = t.validate), t.maxLength && (o.maxlength = t.maxLength), t.size && (o.size = t.size), t.inputStyle && (o.style = t.inputStyle);
                    var a = this,
                        s = !1;
                    e.on("load", function() {
                        a.getInputElement().on("keydown", function(e) {
                            13 == e.data.getKeystroke() && (s = !0)
                        }), a.getInputElement().on("keyup", function(t) {
                            13 == t.data.getKeystroke() && s && (e.getButton("ok") && setTimeout(function() {
                                e.getButton("ok").click()
                            }, 0), s = !1), a.bidi && c.call(a, t)
                        }, null, null, 1e3)
                    });
                    CKEDITOR.ui.dialog.labeledElement.call(this, e, t, i, function() {
                        var e = ['<div class="cke_dialog_ui_input_', t.type, '" role="presentation"'];
                        for (var i in t.width && e.push('style="width:' + t.width + '" '), e.push("><input "), o["aria-labelledby"] = this._.labelId, this._.required && (o["aria-required"] = this._.required), o) e.push(i + '="' + o[i] + '" ');
                        return e.push(" /></div>"), e.join("")
                    })
                }
            },
            textarea: function(e, t, i) {
                if (!(arguments.length < 3)) {
                    l.call(this, t);
                    var n = this,
                        o = this._.inputId = CKEDITOR.tools.getNextId() + "_textarea",
                        a = {};
                    t.validate && (this.validate = t.validate), a.rows = t.rows || 5, a.cols = t.cols || 20, a.class = "cke_dialog_ui_input_textarea " + (t.class || ""), void 0 !== t.inputStyle && (a.style = t.inputStyle), t.dir && (a.dir = t.dir), n.bidi && e.on("load", function() {
                        n.getInputElement().on("keyup", c)
                    }, n);
                    CKEDITOR.ui.dialog.labeledElement.call(this, e, t, i, function() {
                        a["aria-labelledby"] = this._.labelId, this._.required && (a["aria-required"] = this._.required);
                        var e = ['<div class="cke_dialog_ui_input_textarea" role="presentation"><textarea id="', o, '" '];
                        for (var t in a) e.push(t + '="' + CKEDITOR.tools.htmlEncode(a[t]) + '" ');
                        return e.push(">", CKEDITOR.tools.htmlEncode(n._.default), "</textarea></div>"), e.join("")
                    })
                }
            },
            checkbox: function(e, t, i) {
                if (!(arguments.length < 3)) {
                    var n = l.call(this, t, {
                        default: !!t.default
                    });
                    t.validate && (this.validate = t.validate);
                    CKEDITOR.ui.dialog.uiElement.call(this, e, t, i, "span", null, null, function() {
                        var i = CKEDITOR.tools.extend({}, t, {
                                id: t.id ? t.id + "_checkbox" : CKEDITOR.tools.getNextId() + "_checkbox"
                            }, !0),
                            l = [],
                            o = CKEDITOR.tools.getNextId() + "_label",
                            a = {
                                class: "cke_dialog_ui_checkbox_input",
                                type: "checkbox",
                                "aria-labelledby": o
                            };
                        return r(i), t.default && (a.checked = "checked"), void 0 !== i.inputStyle && (i.style = i.inputStyle), n.checkbox = new CKEDITOR.ui.dialog.uiElement(e, i, l, "input", null, a), l.push(' <label id="', o, '" for="', a.id, '"' + (t.labelStyle ? ' style="' + t.labelStyle + '"' : "") + ">", CKEDITOR.tools.htmlEncode(t.label), "</label>"), l.join("")
                    })
                }
            },
            radio: function(e, t, i) {
                if (!(arguments.length < 3)) {
                    l.call(this, t), this._.default || (this._.default = this._.initValue = t.items[0][1]), t.validate && (this.validate = t.validate);
                    var n = [],
                        o = this;
                    t.role = "radiogroup", t.includeLabel = !0, CKEDITOR.ui.dialog.labeledElement.call(this, e, t, i, function() {
                        for (var i = [], l = [], a = (t.id ? t.id : CKEDITOR.tools.getNextId()) + "_radio", s = 0; s < t.items.length; s++) {
                            var u = t.items[s],
                                d = void 0 !== u[2] ? u[2] : u[0],
                                c = void 0 !== u[1] ? u[1] : u[0],
                                h = CKEDITOR.tools.getNextId() + "_radio_input",
                                g = h + "_label",
                                E = CKEDITOR.tools.extend({}, t, {
                                    id: h,
                                    title: null,
                                    type: null
                                }, !0),
                                I = CKEDITOR.tools.extend({}, E, {
                                    title: d
                                }, !0),
                                f = {
                                    type: "radio",
                                    class: "cke_dialog_ui_radio_input",
                                    name: a,
                                    value: c,
                                    "aria-labelledby": g
                                },
                                p = [];
                            o._.default == c && (f.checked = "checked"), r(E), r(I), void 0 !== E.inputStyle && (E.style = E.inputStyle), E.keyboardFocusable = !0, n.push(new CKEDITOR.ui.dialog.uiElement(e, E, p, "input", null, f)), p.push(" "), new CKEDITOR.ui.dialog.uiElement(e, I, p, "label", null, {
                                id: g,
                                for: f.id
                            }, u[0]), i.push(p.join(""))
                        }
                        return new CKEDITOR.ui.dialog.hbox(e, n, i, l), l.join("")
                    }), this._.children = n
                }
            },
            button: function(e, t, i) {
                if (arguments.length) {
                    "function" == typeof t && (t = t(e.getParentEditor())), l.call(this, t, {
                        disabled: t.disabled || !1
                    }), CKEDITOR.event.implementOn(this);
                    var n = this;
                    e.on("load", function() {
                        var e = this.getElement();
                        e.on("click", function(e) {
                            n.click(), e.data.preventDefault()
                        }), e.on("keydown", function(e) {
                            e.data.getKeystroke() in {
                                32: 1
                            } && (n.click(), e.data.preventDefault())
                        }), e.unselectable()
                    }, this);
                    var o = CKEDITOR.tools.extend({}, t);
                    delete o.style;
                    var a = CKEDITOR.tools.getNextId() + "_label";
                    CKEDITOR.ui.dialog.uiElement.call(this, e, o, i, "a", null, {
                        style: t.style,
                        href: "javascript:void(0)",
                        title: t.label,
                        hidefocus: "true",
                        class: t.class,
                        role: "button",
                        "aria-labelledby": a
                    }, '<span id="' + a + '" class="cke_dialog_ui_button">' + CKEDITOR.tools.htmlEncode(t.label) + "</span>")
                }
            },
            select: function(e, t, i) {
                if (!(arguments.length < 3)) {
                    var n = l.call(this, t);
                    t.validate && (this.validate = t.validate), n.inputId = CKEDITOR.tools.getNextId() + "_select";
                    CKEDITOR.ui.dialog.labeledElement.call(this, e, t, i, function() {
                        var i = CKEDITOR.tools.extend({}, t, {
                                id: t.id ? t.id + "_select" : CKEDITOR.tools.getNextId() + "_select"
                            }, !0),
                            l = [],
                            o = [],
                            a = {
                                id: n.inputId,
                                class: "cke_dialog_ui_input_select",
                                "aria-labelledby": this._.labelId
                            };
                        l.push('<div class="cke_dialog_ui_input_', t.type, '" role="presentation"'), t.width && l.push('style="width:' + t.width + '" '), l.push(">"), void 0 !== t.size && (a.size = t.size), void 0 !== t.multiple && (a.multiple = t.multiple), r(i);
                        for (var s, u = 0; u < t.items.length && (s = t.items[u]); u++) o.push('<option value="', CKEDITOR.tools.htmlEncode(void 0 !== s[1] ? s[1] : s[0]).replace(/"/g, "&quot;"), '" /> ', CKEDITOR.tools.htmlEncode(s[0]));
                        return void 0 !== i.inputStyle && (i.style = i.inputStyle), n.select = new CKEDITOR.ui.dialog.uiElement(e, i, l, "select", null, a, o.join("")), l.push("</div>"), l.join("")
                    })
                }
            },
            file: function(e, t, i) {
                if (!(arguments.length < 3)) {
                    void 0 === t.default && (t.default = "");
                    var n = CKEDITOR.tools.extend(l.call(this, t), {
                        definition: t,
                        buttons: []
                    });
                    t.validate && (this.validate = t.validate);
                    e.on("load", function() {
                        CKEDITOR.document.getById(n.frameId).getParent().addClass("cke_dialog_ui_input_file")
                    }), CKEDITOR.ui.dialog.labeledElement.call(this, e, t, i, function() {
                        n.frameId = CKEDITOR.tools.getNextId() + "_fileInput";
                        var e = ['<iframe frameborder="0" allowtransparency="0" class="cke_dialog_ui_input_file" role="presentation" id="', n.frameId, '" title="', t.label, '" src="javascript:void('];
                        return e.push(CKEDITOR.env.ie ? "(function(){" + encodeURIComponent("document.open();(" + CKEDITOR.tools.fixDomain + ")();document.close();") + "})()" : "0"), e.push(')"></iframe>'), e.join("")
                    })
                }
            },
            fileButton: function(e, t, i) {
                var n = this;
                if (!(arguments.length < 3)) {
                    l.call(this, t), t.validate && (this.validate = t.validate);
                    var o = CKEDITOR.tools.extend({}, t),
                        a = o.onClick;
                    o.className = (o.className ? o.className + " " : "") + "cke_dialog_ui_button", o.onClick = function(i) {
                        var l = t.for,
                            n = !!a && a.call(this, i);
                        !1 !== n && ("xhr" !== n && e.getContentElement(l[0], l[1]).submit(), this.disable())
                    }, e.on("load", function() {
                        e.getContentElement(t.for[0], t.for[1])._.buttons.push(n)
                    }), CKEDITOR.ui.dialog.button.call(this, e, o, i)
                }
            },
            html: (e = /^\s*<[\w:]+\s+([^>]*)?>/, t = /^(\s*<[\w:]+(?:\s+[^>]*)?)((?:.|\r|\n)+)$/, i = /\/$/, function(l, n, o) {
                if (!(arguments.length < 3)) {
                    var a, s, u = [],
                        d = n.html;
                    "<" != d.charAt(0) && (d = "<span>" + d + "</span>");
                    var r = n.focus;
                    if (r) {
                        var c = this.focus;
                        if (this.focus = function() {
                                ("function" == typeof r ? r : c).call(this), this.fire("focus")
                            }, n.isFocusable) {
                            var h = this.isFocusable;
                            this.isFocusable = h
                        }
                        this.keyboardFocusable = !0
                    }
                    CKEDITOR.ui.dialog.uiElement.call(this, l, n, u, "span", null, null, ""), a = u.join("").match(e), s = d.match(t) || ["", "", ""], i.test(s[1]) && (s[1] = s[1].slice(0, -1), s[2] = "/" + s[2]), o.push([s[1], " ", a[1] || "", s[2]].join(""))
                }
            }),
            fieldset: function(e, t, i, l, n) {
                var o = n.label;
                this._ = {
                    children: t
                }, CKEDITOR.ui.dialog.uiElement.call(this, e, n, l, "fieldset", null, null, function() {
                    var e = [];
                    o && e.push("<legend" + (n.labelStyle ? ' style="' + n.labelStyle + '"' : "") + ">" + o + "</legend>");
                    for (var t = 0; t < i.length; t++) e.push(i[t]);
                    return e.join("")
                })
            }
        }, !0), CKEDITOR.ui.dialog.html.prototype = new CKEDITOR.ui.dialog.uiElement, CKEDITOR.ui.dialog.labeledElement.prototype = CKEDITOR.tools.extend(new CKEDITOR.ui.dialog.uiElement, {
            setLabel: function(e) {
                var t = CKEDITOR.document.getById(this._.labelId);
                return t.getChildCount() < 1 ? new CKEDITOR.dom.text(e, CKEDITOR.document).appendTo(t) : t.getChild(0).$.nodeValue = e, this
            },
            getLabel: function() {
                var e = CKEDITOR.document.getById(this._.labelId);
                return !e || e.getChildCount() < 1 ? "" : e.getChild(0).getText()
            },
            eventProcessors: u
        }, !0), CKEDITOR.ui.dialog.button.prototype = CKEDITOR.tools.extend(new CKEDITOR.ui.dialog.uiElement, {
            click: function() {
                return !this._.disabled && this.fire("click", {
                    dialog: this._.dialog
                })
            },
            enable: function() {
                this._.disabled = !1;
                var e = this.getElement();
                e && e.removeClass("cke_disabled")
            },
            disable: function() {
                this._.disabled = !0, this.getElement().addClass("cke_disabled")
            },
            isVisible: function() {
                return this.getElement().getFirst().isVisible()
            },
            isEnabled: function() {
                return !this._.disabled
            },
            eventProcessors: CKEDITOR.tools.extend({}, CKEDITOR.ui.dialog.uiElement.prototype.eventProcessors, {
                onClick: function(e, t) {
                    this.on("click", function() {
                        t.apply(this, arguments)
                    })
                }
            }, !0),
            accessKeyUp: function() {
                this.click()
            },
            accessKeyDown: function() {
                this.focus()
            },
            keyboardFocusable: !0
        }, !0), CKEDITOR.ui.dialog.textInput.prototype = CKEDITOR.tools.extend(new CKEDITOR.ui.dialog.labeledElement, {
            getInputElement: function() {
                return CKEDITOR.document.getById(this._.inputId)
            },
            focus: function() {
                var e = this.selectParentTab();
                setTimeout(function() {
                    var t = e.getInputElement();
                    t && t.$.focus()
                }, 0)
            },
            select: function() {
                var e = this.selectParentTab();
                setTimeout(function() {
                    var t = e.getInputElement();
                    t && (t.$.focus(), t.$.select())
                }, 0)
            },
            accessKeyUp: function() {
                this.select()
            },
            setValue: function(e) {
                if (this.bidi) {
                    var t = e && e.charAt(0),
                        i = "‪" == t ? "ltr" : "‫" == t ? "rtl" : null;
                    i && (e = e.slice(1)), this.setDirectionMarker(i)
                }
                return e || (e = ""), CKEDITOR.ui.dialog.uiElement.prototype.setValue.apply(this, arguments)
            },
            getValue: function() {
                var e = CKEDITOR.ui.dialog.uiElement.prototype.getValue.call(this);
                if (this.bidi && e) {
                    var t = this.getDirectionMarker();
                    t && (e = ("ltr" == t ? "‪" : "‫") + e)
                }
                return e
            },
            setDirectionMarker: function(e) {
                var t = this.getInputElement();
                e ? t.setAttributes({
                    dir: e,
                    "data-cke-dir-marker": e
                }) : this.getDirectionMarker() && t.removeAttributes(["dir", "data-cke-dir-marker"])
            },
            getDirectionMarker: function() {
                return this.getInputElement().data("cke-dir-marker")
            },
            keyboardFocusable: !0
        }, s, !0), CKEDITOR.ui.dialog.textarea.prototype = new CKEDITOR.ui.dialog.textInput, CKEDITOR.ui.dialog.select.prototype = CKEDITOR.tools.extend(new CKEDITOR.ui.dialog.labeledElement, {
            getInputElement: function() {
                return this._.select.getElement()
            },
            add: function(e, t, i) {
                var l = new CKEDITOR.dom.element("option", this.getDialog().getParentEditor().document),
                    n = this.getInputElement().$;
                return l.$.text = e, l.$.value = null == t ? e : t, null == i ? CKEDITOR.env.ie ? n.add(l.$) : n.add(l.$, null) : n.add(l.$, i), this
            },
            remove: function(e) {
                return this.getInputElement().$.remove(e), this
            },
            clear: function() {
                for (var e = this.getInputElement().$; e.length > 0;) e.remove(0);
                return this
            },
            keyboardFocusable: !0
        }, s, !0), CKEDITOR.ui.dialog.checkbox.prototype = CKEDITOR.tools.extend(new CKEDITOR.ui.dialog.uiElement, {
            getInputElement: function() {
                return this._.checkbox.getElement()
            },
            setValue: function(e, t) {
                this.getInputElement().$.checked = e, !t && this.fire("change", {
                    value: e
                })
            },
            getValue: function() {
                return this.getInputElement().$.checked
            },
            accessKeyUp: function() {
                this.setValue(!this.getValue())
            },
            eventProcessors: {
                onChange: function(e, t) {
                    return !CKEDITOR.env.ie || CKEDITOR.env.version > 8 ? u.onChange.apply(this, arguments) : (e.on("load", function() {
                        var e = this._.checkbox.getElement();
                        e.on("propertychange", function(t) {
                            "checked" == (t = t.data.$).propertyName && this.fire("change", {
                                value: e.$.checked
                            })
                        }, this)
                    }, this), this.on("change", t), null)
                }
            },
            keyboardFocusable: !0
        }, s, !0), CKEDITOR.ui.dialog.radio.prototype = CKEDITOR.tools.extend(new CKEDITOR.ui.dialog.uiElement, {
            setValue: function(e, t) {
                for (var i, l = this._.children, n = 0; n < l.length && (i = l[n]); n++) i.getElement().$.checked = i.getValue() == e;
                !t && this.fire("change", {
                    value: e
                })
            },
            getValue: function() {
                for (var e = this._.children, t = 0; t < e.length; t++)
                    if (e[t].getElement().$.checked) return e[t].getValue();
                return null
            },
            accessKeyUp: function() {
                var e, t = this._.children;
                for (e = 0; e < t.length; e++)
                    if (t[e].getElement().$.checked) return void t[e].getElement().focus();
                t[0].getElement().focus()
            },
            eventProcessors: {
                onChange: function(e, t) {
                    return !CKEDITOR.env.ie || CKEDITOR.env.version > 8 ? u.onChange.apply(this, arguments) : (e.on("load", function() {
                        for (var e = this._.children, t = this, i = 0; i < e.length; i++) {
                            e[i].getElement().on("propertychange", function(e) {
                                "checked" == (e = e.data.$).propertyName && this.$.checked && t.fire("change", {
                                    value: this.getAttribute("value")
                                })
                            })
                        }
                    }, this), this.on("change", t), null)
                }
            }
        }, s, !0), CKEDITOR.ui.dialog.file.prototype = CKEDITOR.tools.extend(new CKEDITOR.ui.dialog.labeledElement, s, {
            getInputElement: function() {
                var e = CKEDITOR.document.getById(this._.frameId).getFrameDocument();
                return e.$.forms.length > 0 ? new CKEDITOR.dom.element(e.$.forms[0].elements[0]) : this.getElement()
            },
            submit: function() {
                return this.getInputElement().getParent().$.submit(), this
            },
            getAction: function() {
                return this.getInputElement().getParent().$.action
            },
            registerEvents: function(e) {
                var t, i = /^on([A-Z]\w+)/,
                    l = function(e, t, i, l) {
                        e.on("formLoaded", function() {
                            e.getInputElement().on(i, l, e)
                        })
                    };
                for (var n in e)(t = n.match(i)) && (this.eventProcessors[n] ? this.eventProcessors[n].call(this, this._.dialog, e[n]) : l(this, this._.dialog, t[1].toLowerCase(), e[n]));
                return this
            },
            reset: function() {
                var e = this._,
                    t = CKEDITOR.document.getById(e.frameId).getFrameDocument(),
                    i = e.definition,
                    l = e.buttons,
                    n = this.formLoadedNumber,
                    o = this.formUnloadNumber,
                    a = e.dialog._.editor.lang.dir,
                    s = e.dialog._.editor.langCode;

                function u() {
                    t.$.open();
                    var u = "";
                    i.size && (u = i.size - (CKEDITOR.env.ie ? 7 : 0));
                    var d = e.frameId + "_input";
                    t.$.write(['<html dir="' + a + '" lang="' + s + '"><head><title></title></head><body style="margin: 0; overflow: hidden; background: transparent;">', '<form enctype="multipart/form-data" method="POST" dir="' + a + '" lang="' + s + '" action="', CKEDITOR.tools.htmlEncode(i.action), '">', '<label id="', e.labelId, '" for="', d, '" style="display:none">', CKEDITOR.tools.htmlEncode(i.label), "</label>", '<input style="width:100%" id="', d, '" aria-labelledby="', e.labelId, '" type="file" name="', CKEDITOR.tools.htmlEncode(i.id || "cke_upload"), '" size="', CKEDITOR.tools.htmlEncode(u > 0 ? u : ""), '" />', "</form>", "</body></html>", "<script>", CKEDITOR.env.ie ? "(" + CKEDITOR.tools.fixDomain + ")();" : "", "window.parent.CKEDITOR.tools.callFunction(" + n + ");", "window.onbeforeunload = function() {window.parent.CKEDITOR.tools.callFunction(" + o + ")}", "<\/script>"].join("")), t.$.close();
                    for (var r = 0; r < l.length; r++) l[r].enable()
                }
                n || (n = this.formLoadedNumber = CKEDITOR.tools.addFunction(function() {
                    this.fire("formLoaded")
                }, this), o = this.formUnloadNumber = CKEDITOR.tools.addFunction(function() {
                    this.getInputElement().clearCustomData()
                }, this), this.getDialog()._.editor.on("destroy", function() {
                    CKEDITOR.tools.removeFunction(n), CKEDITOR.tools.removeFunction(o)
                })), CKEDITOR.env.gecko ? setTimeout(u, 500) : u()
            },
            getValue: function() {
                return this.getInputElement().$.value || ""
            },
            setInitValue: function() {
                this._.initValue = ""
            },
            eventProcessors: {
                onChange: function(e, t) {
                    this._.domOnChangeRegistered || (this.on("formLoaded", function() {
                        this.getInputElement().on("change", function() {
                            this.fire("change", {
                                value: this.getValue()
                            })
                        }, this)
                    }, this), this._.domOnChangeRegistered = !0), this.on("change", t)
                }
            },
            keyboardFocusable: !0
        }, !0), CKEDITOR.ui.dialog.fileButton.prototype = new CKEDITOR.ui.dialog.button, CKEDITOR.ui.dialog.fieldset.prototype = CKEDITOR.tools.clone(CKEDITOR.ui.dialog.hbox.prototype), CKEDITOR.dialog.addUIElement("text", n), CKEDITOR.dialog.addUIElement("password", n), CKEDITOR.dialog.addUIElement("tel", n), CKEDITOR.dialog.addUIElement("textarea", o), CKEDITOR.dialog.addUIElement("checkbox", o), CKEDITOR.dialog.addUIElement("radio", o), CKEDITOR.dialog.addUIElement("button", o), CKEDITOR.dialog.addUIElement("select", o), CKEDITOR.dialog.addUIElement("file", o), CKEDITOR.dialog.addUIElement("fileButton", o), CKEDITOR.dialog.addUIElement("html", o), CKEDITOR.dialog.addUIElement("fieldset", a)
    }
});