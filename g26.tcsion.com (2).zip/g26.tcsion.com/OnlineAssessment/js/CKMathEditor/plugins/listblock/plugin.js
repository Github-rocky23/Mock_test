CKEDITOR.plugins.add("listblock", {
    requires: "panel",
    onLoad: function() {
        var t = CKEDITOR.addTemplate("panel-list", '<ul role="presentation" class="cke_panel_list">{items}</ul>'),
            e = CKEDITOR.addTemplate("panel-list-item", '<li id="{id}" class="cke_panel_listItem" role=presentation><a id="{id}_option" _cke_focus=1 hidefocus=true title="{title}" draggable="false" ondragstart="return false;" href="javascript:void(\'{val}\')"  {onclick}="CKEDITOR.tools.callFunction({clickFn},\'{val}\'); return false;" role="option">{text}</a></li>'),
            i = CKEDITOR.addTemplate("panel-list-group", '<h1 id="{id}" draggable="false" ondragstart="return false;" class="cke_panel_grouptitle" role="presentation" >{label}</h1>'),
            s = /\'/g;
        CKEDITOR.ui.panel.prototype.addListBlock = function(t, e) {
            return this.addBlock(t, new CKEDITOR.ui.listBlock(this.getHolderElement(), e))
        }, CKEDITOR.ui.listBlock = CKEDITOR.tools.createClass({
            base: CKEDITOR.ui.panel.block,
            $: function(t, e) {
                var i = (e = e || {}).attributes || (e.attributes = {});
                (this.multiSelect = !!e.multiSelect) && (i["aria-multiselectable"] = !0), !i.role && (i.role = "listbox"), this.base.apply(this, arguments), this.element.setAttribute("role", i.role);
                var s = this.keys;
                s[40] = "next", s[9] = "next", s[38] = "prev", s[CKEDITOR.SHIFT + 9] = "prev", s[32] = CKEDITOR.env.ie ? "mouseup" : "click", CKEDITOR.env.ie && (s[13] = "mouseup"), this._.pendingHtml = [], this._.pendingList = [], this._.items = {}, this._.groups = {}
            },
            _: {
                close: function() {
                    if (this._.started) {
                        var e = t.output({
                            items: this._.pendingList.join("")
                        });
                        this._.pendingList = [], this._.pendingHtml.push(e), delete this._.started
                    }
                },
                getClick: function() {
                    return this._.click || (this._.click = CKEDITOR.tools.addFunction(function(t) {
                        var e = this.toggle(t);
                        this.onClick && this.onClick(t, e)
                    }, this)), this._.click
                }
            },
            proto: {
                add: function(t, i, l) {
                    var n = CKEDITOR.tools.getNextId();
                    this._.started || (this._.started = 1, this._.size = this._.size || 0), this._.items[t] = n;
                    var o, a = {
                        id: n,
                        val: (o = CKEDITOR.tools.htmlEncodeAttr(t), o.replace(s, "\\'")),
                        onclick: CKEDITOR.env.ie ? 'onclick="return false;" onmouseup' : "onclick",
                        clickFn: this._.getClick(),
                        title: CKEDITOR.tools.htmlEncodeAttr(l || t),
                        text: i || t
                    };
                    this._.pendingList.push(e.output(a))
                },
                startGroup: function(t) {
                    this._.close();
                    var e = CKEDITOR.tools.getNextId();
                    this._.groups[t] = e, this._.pendingHtml.push(i.output({
                        id: e,
                        label: t
                    }))
                },
                commit: function() {
                    this._.close(), this.element.appendHtml(this._.pendingHtml.join("")), delete this._.size, this._.pendingHtml = []
                },
                toggle: function(t) {
                    var e = this.isMarked(t);
                    return e ? this.unmark(t) : this.mark(t), !e
                },
                hideGroup: function(t) {
                    var e = this.element.getDocument().getById(this._.groups[t]),
                        i = e && e.getNext();
                    e && (e.setStyle("display", "none"), i && "ul" == i.getName() && i.setStyle("display", "none"))
                },
                hideItem: function(t) {
                    this.element.getDocument().getById(this._.items[t]).setStyle("display", "none")
                },
                showAll: function() {
                    var t = this._.items,
                        e = this._.groups,
                        i = this.element.getDocument();
                    for (var s in t) i.getById(t[s]).setStyle("display", "");
                    for (var l in e) {
                        var n = i.getById(e[l]),
                            o = n.getNext();
                        n.setStyle("display", ""), o && "ul" == o.getName() && o.setStyle("display", "")
                    }
                },
                mark: function(t) {
                    this.multiSelect || this.unmarkAll();
                    var e = this._.items[t],
                        i = this.element.getDocument().getById(e);
                    i.addClass("cke_selected"), this.element.getDocument().getById(e + "_option").setAttribute("aria-selected", !0), this.onMark && this.onMark(i)
                },
                markFirstDisplayed: function() {
                    var t = this;
                    this._.markFirstDisplayed(function() {
                        t.multiSelect || t.unmarkAll()
                    })
                },
                unmark: function(t) {
                    var e = this.element.getDocument(),
                        i = this._.items[t],
                        s = e.getById(i);
                    s.removeClass("cke_selected"), e.getById(i + "_option").removeAttribute("aria-selected"), this.onUnmark && this.onUnmark(s)
                },
                unmarkAll: function() {
                    var t = this._.items,
                        e = this.element.getDocument();
                    for (var i in t) {
                        var s = t[i];
                        e.getById(s).removeClass("cke_selected"), e.getById(s + "_option").removeAttribute("aria-selected")
                    }
                    this.onUnmark && this.onUnmark()
                },
                isMarked: function(t) {
                    return this.element.getDocument().getById(this._.items[t]).hasClass("cke_selected")
                },
                focus: function(t) {
                    this._.focusIndex = -1;
                    var e, i, s = this.element.getElementsByTag("a"),
                        l = -1;
                    if (t) {
                        for (i = this.element.getDocument().getById(this._.items[t]).getFirst(); e = s.getItem(++l);)
                            if (e.equals(i)) {
                                this._.focusIndex = l;
                                break
                            }
                    } else this.element.focus();
                    i && setTimeout(function() {
                        i.focus()
                    }, 0)
                }
            }
        })
    }
});