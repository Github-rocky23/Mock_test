! function() {
    CKEDITOR.plugins.add("panel", {
        beforeInit: function(e) {
            e.ui.addHandler(CKEDITOR.UI_PANEL, CKEDITOR.ui.panel.handler)
        }
    }), CKEDITOR.UI_PANEL = "panel", CKEDITOR.ui.panel = function(e, t) {
        t && CKEDITOR.tools.extend(this, t), CKEDITOR.tools.extend(this, {
            className: "",
            css: []
        }), this.id = CKEDITOR.tools.getNextId(), this.document = e, this.isFramed = this.forceIFrame || this.css.length, this._ = {
            blocks: {}
        }
    }, CKEDITOR.ui.panel.handler = {
        create: function(e) {
            return new CKEDITOR.ui.panel(e)
        }
    };
    var e = CKEDITOR.addTemplate("panel", '<div lang="{langCode}" id="{id}" dir={dir} class="cke cke_reset_all {editorId} cke_panel cke_panel {cls} cke_{dir}" style="z-index:{z-index}" role="presentation">{frame}</div>'),
        t = CKEDITOR.addTemplate("panel-frame", '<iframe id="{id}" class="cke_panel_frame" role="presentation" frameborder="0" src="{src}"></iframe>'),
        i = CKEDITOR.addTemplate("panel-frame-inner", '<!DOCTYPE html><html class="cke_panel_container {env}" dir="{dir}" lang="{langCode}"><head>{css}</head><body class="cke_{dir}" style="margin:0;padding:0" onload="{onload}"></body></html>');
    CKEDITOR.ui.panel.prototype = {
        render: function(n, s) {
            var o = {
                editorId: n.id,
                id: this.id,
                langCode: n.langCode,
                dir: n.lang.dir,
                cls: this.className,
                frame: "",
                env: CKEDITOR.env.cssClass,
                "z-index": n.config.baseFloatZIndex + 1
            };
            if (this.getHolderElement = function() {
                    var e = this._.holder;
                    if (!e) {
                        if (this.isFramed) {
                            var t = this.document.getById(this.id + "_frame"),
                                n = t.getParent(),
                                s = t.getFrameDocument();
                            CKEDITOR.env.iOS && n.setStyles({
                                overflow: "scroll",
                                "-webkit-overflow-scrolling": "touch"
                            });
                            var a = CKEDITOR.tools.addFunction(CKEDITOR.tools.bind(function() {
                                this.isLoaded = !0, this.onLoad && this.onLoad()
                            }, this));
                            s.write(i.output(CKEDITOR.tools.extend({
                                css: CKEDITOR.tools.buildStyleHtml(this.css),
                                onload: "window.parent.CKEDITOR.tools.callFunction(" + a + ");"
                            }, o))), s.getWindow().$.CKEDITOR = CKEDITOR, s.on("keydown", function(e) {
                                var t = e.data.getKeystroke(),
                                    i = this.document.getById(this.id).getAttribute("dir");
                                ("input" !== e.data.getTarget().getName() || 37 !== t && 39 !== t) && (this._.onKeyDown && !1 === this._.onKeyDown(t) ? "input" === e.data.getTarget().getName() && 32 === t || e.data.preventDefault() : 27 != t && t != ("rtl" == i ? 39 : 37) || this.onEscape && !1 === this.onEscape(t) && e.data.preventDefault())
                            }, this), (e = s.getBody()).unselectable(), CKEDITOR.env.air && CKEDITOR.tools.callFunction(a)
                        } else e = this.document.getById(this.id);
                        this._.holder = e
                    }
                    return e
                }, this.isFramed) {
                var a = CKEDITOR.env.air ? "javascript:void(0)" : CKEDITOR.env.ie && !CKEDITOR.env.edge ? "javascript:void(function(){" + encodeURIComponent("document.open();(" + CKEDITOR.tools.fixDomain + ")();document.close();") + "}())" : "";
                o.frame = t.output({
                    id: this.id + "_frame",
                    src: a
                })
            }
            var r = e.output(o);
            return s && s.push(r), r
        },
        addBlock: function(e, t) {
            return t = this._.blocks[e] = t instanceof CKEDITOR.ui.panel.block ? t : new CKEDITOR.ui.panel.block(this.getHolderElement(), t), this._.currentBlock || this.showBlock(e), t
        },
        getBlock: function(e) {
            return this._.blocks[e]
        },
        showBlock: function(e) {
            var t = this._.blocks[e],
                i = this._.currentBlock,
                n = !this.forceIFrame || CKEDITOR.env.ie ? this._.holder : this.document.getById(this.id + "_frame");
            return i && i.hide(), this._.currentBlock = t, CKEDITOR.fire("ariaWidget", n), t._.focusIndex = -1, this._.onKeyDown = t.onKeyDown && CKEDITOR.tools.bind(t.onKeyDown, t), t.show(), t
        },
        destroy: function() {
            this.element && this.element.remove()
        }
    }, CKEDITOR.ui.panel.block = CKEDITOR.tools.createClass({
        $: function(e, t) {
            this.element = e.append(e.getDocument().createElement("div", {
                attributes: {
                    tabindex: -1,
                    class: "cke_panel_block"
                },
                styles: {
                    display: "none"
                }
            })), t && CKEDITOR.tools.extend(this, t), this.element.setAttributes({
                role: this.attributes.role || "presentation",
                "aria-label": this.attributes["aria-label"],
                title: this.attributes.title || this.attributes["aria-label"]
            }), this.keys = {}, this._.focusIndex = -1, this.element.disableContextMenu()
        },
        _: {
            markItem: function(e) {
                if (-1 != e) {
                    var t = this._.getItems().getItem(this._.focusIndex = e);
                    CKEDITOR.env.webkit && t.getDocument().getWindow().focus(), t.focus(), this.onMark && this.onMark(t)
                }
            },
            markFirstDisplayed: function(e) {
                for (var t, i, n = function(e) {
                        return e.type == CKEDITOR.NODE_ELEMENT && "none" == e.getStyle("display")
                    }, s = this._.getItems(), o = s.count() - 1; o >= 0; o--)
                    if ((t = s.getItem(o)).getAscendant(n) || (i = t, this._.focusIndex = o), "true" == t.getAttribute("aria-selected")) {
                        i = t, this._.focusIndex = o;
                        break
                    }
                i && (e && e(), CKEDITOR.env.webkit && i.getDocument().getWindow().focus(), i.focus(), this.onMark && this.onMark(i))
            },
            getItems: function() {
                return this.element.find("a,input")
            }
        },
        proto: {
            show: function() {
                this.element.setStyle("display", "")
            },
            hide: function() {
                this.onHide && !0 === this.onHide.call(this) || this.element.setStyle("display", "none")
            },
            onKeyDown: function(e, t) {
                var i = this.keys[e];
                switch (i) {
                    case "next":
                        for (var n, s = this._.focusIndex, o = this._.getItems(); n = o.getItem(++s);)
                            if (n.getAttribute("_cke_focus") && n.$.offsetWidth) {
                                this._.focusIndex = s, n.focus(!0);
                                break
                            }
                        return !n && !t && (this._.focusIndex = -1, this.onKeyDown(e, 1));
                    case "prev":
                        for (s = this._.focusIndex, o = this._.getItems(); s > 0 && (n = o.getItem(--s));) {
                            if (n.getAttribute("_cke_focus") && n.$.offsetWidth) {
                                this._.focusIndex = s, n.focus(!0);
                                break
                            }
                            n = null
                        }
                        return !n && !t && (this._.focusIndex = o.count(), this.onKeyDown(e, 1));
                    case "click":
                    case "mouseup":
                        return (n = (s = this._.focusIndex) >= 0 && this._.getItems().getItem(s)) && (n.$[i] ? n.$[i]() : n.$["on" + i]()), !1
                }
                return !0
            }
        }
    })
}();