! function() {
    function e(e, t, i, r) {
        if (!e.isReadOnly() && !e.equals(i.editable())) {
            CKEDITOR.dom.element.setMarker(r, e, "bidi_processed", 1), r = e;
            for (var o = i.editable();
                (r = r.getParent()) && !r.equals(o);)
                if (r.getCustomData("bidi_processed")) return e.removeStyle("direction"), void e.removeAttribute("dir");
            ((r = "useComputedState" in i.config ? i.config.useComputedState : 1) ? e.getComputedStyle("direction") : e.getStyle("direction") || e.hasAttribute("dir")) != t && (e.removeStyle("direction"), r ? (e.removeAttribute("dir"), t != e.getComputedStyle("direction") && e.setAttribute("dir", t)) : e.setAttribute("dir", t), i.forceNextSelectionCheck())
        }
    }

    function t(e, t, i) {
        var r = e.getCommonAncestor(!1, !0);
        if ((e = e.clone()).enlarge(i == CKEDITOR.ENTER_BR ? CKEDITOR.ENLARGE_LIST_ITEM_CONTENTS : CKEDITOR.ENLARGE_BLOCK_CONTENTS), e.checkBoundaryOfElement(r, CKEDITOR.START) && e.checkBoundaryOfElement(r, CKEDITOR.END)) {
            for (var o; r && r.type == CKEDITOR.NODE_ELEMENT && (o = r.getParent()) && 1 == o.getChildCount() && !(r.getName() in t);) r = o;
            return r.type == CKEDITOR.NODE_ELEMENT && r.getName() in t && r
        }
    }

    function i(i) {
        return {
            context: "p",
            allowedContent: {
                "h1 h2 h3 h4 h5 h6 table ul ol blockquote div tr p div li td": {
                    propertiesOnly: !0,
                    attributes: "dir"
                }
            },
            requiredContent: "p[dir]",
            refresh: function(e, t) {
                var i, r;
                if (!(r = void 0 === (r = e.config.useComputedState) || r)) {
                    i = t.lastElement;
                    for (var o = e.editable(); i && !(i.getName() in a || i.equals(o));) {
                        var n = i.getParent();
                        if (!n) break;
                        i = n
                    }
                }(i = i || t.block || t.blockLimit).equals(e.editable()) && (o = e.getSelection().getRanges()[0].getEnclosedNode()) && o.type == CKEDITOR.NODE_ELEMENT && (i = o), i && (r = r ? i.getComputedStyle("direction") : i.getStyle("direction") || i.getAttribute("dir"), e.getCommand("bidirtl").setState("rtl" == r ? CKEDITOR.TRISTATE_ON : CKEDITOR.TRISTATE_OFF), e.getCommand("bidiltr").setState("ltr" == r ? CKEDITOR.TRISTATE_ON : CKEDITOR.TRISTATE_OFF)), (r = (t.block || t.blockLimit || e.editable()).getDirection(1)) != (e._.selDir || e.lang.dir) && (e._.selDir = r, e.fire("contentDirChanged", r))
            },
            exec: function(r) {
                var a = r.getSelection(),
                    d = r.config.enterMode;
                if ((s = a.getRanges()) && s.length) {
                    for (var l, c = {}, E = a.createBookmarks(), s = s.createIterator(), u = 0; l = s.getNextRange(1);) {
                        var g = l.getEnclosedNode();
                        g && (!g || g.type == CKEDITOR.NODE_ELEMENT && g.getName() in n) || (g = t(l, o, d)), g && e(g, i, r, c);
                        var T = new CKEDITOR.dom.walker(l),
                            C = E[u].startNode,
                            O = E[u++].endNode;
                        for (T.evaluator = function(e) {
                                var t, i = d == CKEDITOR.ENTER_P ? "p" : "div";
                                return (t = !!e && e.type == CKEDITOR.NODE_ELEMENT && e.getName() in o) && ((i = e.is(i)) && (i = !!(i = e.getParent()) && i.type == CKEDITOR.NODE_ELEMENT), t = !(i && e.getParent().is("blockquote"))), !!(t && e.getPosition(C) & CKEDITOR.POSITION_FOLLOWING && (e.getPosition(O) & CKEDITOR.POSITION_PRECEDING + CKEDITOR.POSITION_CONTAINS) == CKEDITOR.POSITION_PRECEDING)
                            }; g = T.next();) e(g, i, r, c);
                        for ((l = l.createIterator()).enlargeBr = d != CKEDITOR.ENTER_BR; g = l.getNextParagraph(d == CKEDITOR.ENTER_P ? "p" : "div");) e(g, i, r, c)
                    }
                    CKEDITOR.dom.element.clearAllMarkers(c), r.forceNextSelectionCheck(), a.selectBookmarks(E), r.focus()
                }
            }
        }
    }

    function r(e) {
        var t = e == d.setAttribute,
            i = e == d.removeAttribute,
            r = /\bdirection\s*:\s*(.*?)\s*(:?$|;)/;
        return function(o, n) {
            if (!this.isReadOnly()) {
                var a;
                if (a = o == (t || i ? "dir" : "direction") || "style" == o && (i || r.test(n))) {
                    e: {
                        for (var d = (a = this).getDocument().getBody().getParent(); a;) {
                            if (a.equals(d)) {
                                a = !1;
                                break e
                            }
                            a = a.getParent()
                        }
                        a = !0
                    }
                    a = !a
                }
                if (a && (a = this.getDirection(1), d = e.apply(this, arguments), a != this.getDirection(1))) return this.getDocument().fire("dirChanged", this), d
            }
            return e.apply(this, arguments)
        }
    }
    var o = {
            table: 1,
            ul: 1,
            ol: 1,
            blockquote: 1,
            div: 1
        },
        n = {},
        a = {};
    CKEDITOR.tools.extend(n, o, {
        tr: 1,
        p: 1,
        div: 1,
        li: 1
    }), CKEDITOR.tools.extend(a, n, {
        td: 1
    }), CKEDITOR.plugins.add("bidi", {
        lang: "af,ar,az,bg,bn,bs,ca,cs,cy,da,de,de-ch,el,en,en-au,en-ca,en-gb,eo,es,es-mx,et,eu,fa,fi,fo,fr,fr-ca,gl,gu,he,hi,hr,hu,id,is,it,ja,ka,km,ko,ku,lt,lv,mk,mn,ms,nb,nl,no,oc,pl,pt,pt-br,ro,ru,si,sk,sl,sq,sr,sr-latn,sv,th,tr,tt,ug,uk,vi,zh,zh-cn",
        icons: "bidiltr,bidirtl",
        hidpi: !0,
        init: function(e) {
            function t(t, i, r, o, n) {
                e.addCommand(r, new CKEDITOR.command(e, o)), e.ui.addButton && e.ui.addButton(t, {
                    label: i,
                    command: r,
                    toolbar: "bidi," + n
                })
            }
            if (!e.blockless) {
                var r = e.lang.bidi;
                t("BidiLtr", r.ltr, "bidiltr", i("ltr"), 10), t("BidiRtl", r.rtl, "bidirtl", i("rtl"), 20), e.on("contentDom", function() {
                    e.document.on("dirChanged", function(t) {
                        e.fire("dirChanged", {
                            node: t.data,
                            dir: t.data.getDirection(1)
                        })
                    })
                }), e.on("contentDirChanged", function(t) {
                    t = (e.lang.dir != t.data ? "add" : "remove") + "Class";
                    var i = e.ui.space(e.config.toolbarLocation);
                    i && i[t]("cke_mixed_dir_content")
                })
            }
        }
    });
    for (var d = CKEDITOR.dom.element.prototype, l = ["setStyle", "removeStyle", "setAttribute", "removeAttribute"], c = 0; c < l.length; c++) d[l[c]] = CKEDITOR.tools.override(d[l[c]], r)
}();