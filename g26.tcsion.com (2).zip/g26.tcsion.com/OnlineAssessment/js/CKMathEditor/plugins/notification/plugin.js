"use strict";
! function() {
    function t(t, e) {
        CKEDITOR.tools.extend(this, e, {
            editor: t,
            id: "cke-" + CKEDITOR.tools.getUniqueId(),
            area: t._.notificationArea
        }), e.type || (this.type = "info"), this.element = this._createElement(), t.plugins.clipboard && CKEDITOR.plugins.clipboard.preventDefaultDropOnElement(this.element)
    }

    function e(t) {
        var e = this;
        this.editor = t, this.notifications = [], this.element = this._createElement(), this._uiBuffer = CKEDITOR.tools.eventsBuffer(10, this._layout, this), this._changeBuffer = CKEDITOR.tools.eventsBuffer(500, this._layout, this), t.on("destroy", function() {
            e._removeListeners(), e.element.remove()
        })
    }
    CKEDITOR.plugins.add("notification", {
        lang: "az,bg,ca,cs,da,de,de-ch,en,en-au,eo,es,es-mx,et,eu,fa,fr,gl,hr,hu,id,it,ja,km,ko,ku,lv,nb,nl,oc,pl,pt,pt-br,ro,ru,sk,sq,sv,tr,ug,uk,zh,zh-cn",
        init: function(t) {
            t._.notificationArea = new e(t), t.showNotification = function(e, i, o) {
                var s, n;
                "progress" == i ? s = o : n = o;
                var r = new CKEDITOR.plugins.notification(t, {
                    message: e,
                    type: i,
                    progress: s,
                    duration: n
                });
                return r.show(), r
            }, t.on("key", function(e) {
                if (27 == e.data.keyCode) {
                    var i = t._.notificationArea.notifications;
                    if (!i.length) return;
                    o = t.lang.notification.closed, (s = new CKEDITOR.dom.element("div")).setStyles({
                        position: "fixed",
                        "margin-left": "-9999px"
                    }), s.setAttributes({
                        "aria-live": "assertive",
                        "aria-atomic": "true"
                    }), s.setText(o), CKEDITOR.document.getBody().append(s), setTimeout(function() {
                        s.remove()
                    }, 100), i[i.length - 1].hide(), e.cancel()
                }
                var o, s
            })
        }
    }), t.prototype = {
        show: function() {
            !1 !== this.editor.fire("notificationShow", {
                notification: this
            }) && (this.area.add(this), this._hideAfterTimeout())
        },
        update: function(t) {
            var e = !0;
            !1 === this.editor.fire("notificationUpdate", {
                notification: this,
                options: t
            }) && (e = !1);
            var i = this.element,
                o = i.findOne(".cke_notification_message"),
                s = i.findOne(".cke_notification_progress"),
                n = t.type;
            i.removeAttribute("role"), t.progress && "progress" != this.type && (n = "progress"), n && (i.removeClass(this._getClass()), i.removeAttribute("aria-label"), this.type = n, i.addClass(this._getClass()), i.setAttribute("aria-label", this.type), "progress" != this.type || s ? "progress" != this.type && s && s.remove() : (s = this._createProgressElement()).insertBefore(o)), void 0 !== t.message && (this.message = t.message, o.setHtml(this.message)), void 0 !== t.progress && (this.progress = t.progress, s && s.setStyle("width", this._getPercentageProgress())), e && t.important && (i.setAttribute("role", "alert"), this.isVisible() || this.area.add(this)), this.duration = t.duration, this._hideAfterTimeout()
        },
        hide: function() {
            !1 !== this.editor.fire("notificationHide", {
                notification: this
            }) && this.area.remove(this)
        },
        isVisible: function() {
            return CKEDITOR.tools.indexOf(this.area.notifications, this) >= 0
        },
        _createElement: function() {
            var t, e, i, o = this,
                s = this.editor.lang.common.close;
            return (t = new CKEDITOR.dom.element("div")).addClass("cke_notification"), t.addClass(this._getClass()), t.setAttributes({
                id: this.id,
                role: "alert",
                "aria-label": this.type
            }), "progress" == this.type && t.append(this._createProgressElement()), (e = new CKEDITOR.dom.element("p")).addClass("cke_notification_message"), e.setHtml(this.message), t.append(e), i = CKEDITOR.dom.element.createFromHtml('<a class="cke_notification_close" href="javascript:void(0)" title="' + s + '" role="button" tabindex="-1"><span class="cke_label">X</span></a>'), t.append(i), i.on("click", function() {
                o.editor.focus(), o.hide()
            }), t
        },
        _getClass: function() {
            return "progress" == this.type ? "cke_notification_info" : "cke_notification_" + this.type
        },
        _createProgressElement: function() {
            var t = new CKEDITOR.dom.element("span");
            return t.addClass("cke_notification_progress"), t.setStyle("width", this._getPercentageProgress()), t
        },
        _getPercentageProgress: function() {
            return Math.round(100 * (this.progress || 0)) + "%"
        },
        _hideAfterTimeout: function() {
            var t, e = this;
            this._hideTimeoutId && clearTimeout(this._hideTimeoutId), "number" == typeof this.duration ? t = this.duration : "info" != this.type && "success" != this.type || (t = "number" == typeof this.editor.config.notification_duration ? this.editor.config.notification_duration : 5e3), t && (e._hideTimeoutId = setTimeout(function() {
                e.hide()
            }, t))
        }
    }, e.prototype = {
        add: function(t) {
            this.notifications.push(t), this.element.append(t.element), 1 == this.element.getChildCount() && (CKEDITOR.document.getBody().append(this.element), this._attachListeners()), this._layout()
        },
        remove: function(t) {
            var e = CKEDITOR.tools.indexOf(this.notifications, t);
            e < 0 || (this.notifications.splice(e, 1), t.element.remove(), this.element.getChildCount() || (this._removeListeners(), this.element.remove()))
        },
        _createElement: function() {
            var t = this.editor,
                e = t.config,
                i = new CKEDITOR.dom.element("div");
            return i.addClass("cke_notifications_area"), i.setAttribute("id", "cke_notifications_area_" + t.name), i.setStyle("z-index", e.baseFloatZIndex - 2), i
        },
        _attachListeners: function() {
            var t = CKEDITOR.document.getWindow(),
                e = this.editor;
            t.on("scroll", this._uiBuffer.input), t.on("resize", this._uiBuffer.input), e.on("change", this._changeBuffer.input), e.on("floatingSpaceLayout", this._layout, this, null, 20), e.on("blur", this._layout, this, null, 20)
        },
        _removeListeners: function() {
            var t = CKEDITOR.document.getWindow(),
                e = this.editor;
            t.removeListener("scroll", this._uiBuffer.input), t.removeListener("resize", this._uiBuffer.input), e.removeListener("change", this._changeBuffer.input), e.removeListener("floatingSpaceLayout", this._layout), e.removeListener("blur", this._layout)
        },
        _layout: function() {
            var t, e, i, o = this.element,
                s = this.editor,
                n = s.ui.contentsElement.getClientRect(),
                r = s.ui.contentsElement.getDocumentPosition(),
                a = o.getClientRect(),
                h = this._notificationWidth,
                l = this._notificationMargin,
                c = CKEDITOR.document.getWindow(),
                d = c.getScrollPosition(),
                u = c.getViewPaneSize(),
                f = CKEDITOR.document.getBody(),
                m = f.getDocumentPosition(),
                p = CKEDITOR.tools.cssLength;
            h && l || (i = this.element.getChild(0), h = this._notificationWidth = i.getClientRect().width, l = this._notificationMargin = parseInt(i.getComputedStyle("margin-left"), 10) + parseInt(i.getComputedStyle("margin-right"), 10)), s.toolbar && (t = s.ui.space("top"), e = t.getClientRect()), t && t.isVisible() && e.bottom > n.top && e.bottom < n.bottom - a.height ? o.setStyles({
                position: "fixed",
                top: p(e.bottom)
            }) : n.top > 0 ? o.setStyles({
                position: "absolute",
                top: p(r.y)
            }) : r.y + n.height - a.height > d.y ? o.setStyles({
                position: "fixed",
                top: 0
            }) : o.setStyles({
                position: "absolute",
                top: p(r.y + n.height - a.height)
            });
            var g = "fixed" == o.getStyle("position") ? n.left : "static" != f.getComputedStyle("position") ? r.x - m.x : r.x;

            function _() {
                o.setStyle("left", p(g))
            }

            function y() {
                o.setStyle("left", p(g + n.width - h - l))
            }
            n.width < h + l ? r.x + h + l > d.x + u.width ? y() : _() : r.x + h + l > d.x + u.width ? _() : r.x + n.width / 2 + h / 2 + l > d.x + u.width ? o.setStyle("left", p(g - r.x + d.x + u.width - h - l)) : n.left + n.width - h - l < 0 ? y() : n.left + n.width / 2 - h / 2 < 0 ? o.setStyle("left", p(g - r.x + d.x)) : o.setStyle("left", p(g + n.width / 2 - h / 2 - l / 2))
        }
    }, CKEDITOR.plugins.notification = t
}();