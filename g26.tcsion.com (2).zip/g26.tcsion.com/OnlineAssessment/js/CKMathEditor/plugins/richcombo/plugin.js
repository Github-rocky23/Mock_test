CKEDITOR.plugins.add("richcombo", {
        requires: "floatpanel,listblock,button",
        beforeInit: function(t) {
            t.ui.addHandler(CKEDITOR.UI_RICHCOMBO, CKEDITOR.ui.richCombo.handler)
        }
    }),
    function() {
        var t = '<span id="{id}" class="cke_combo cke_combo__{name} {cls}" role="presentation"><span id="{id}_label" class="cke_combo_label">{label}</span><a class="cke_combo_button" title="{title}" tabindex="-1"' + (CKEDITOR.env.gecko && !CKEDITOR.env.hc ? "" : " href=\"javascript:void('{titleJs}')\"") + ' hidefocus="true" role="button" aria-labelledby="{id}_label" aria-haspopup="listbox"';
        CKEDITOR.env.gecko && CKEDITOR.env.mac && (t += ' onkeypress="return false;"'), CKEDITOR.env.gecko && (t += ' onblur="this.style.cssText = this.style.cssText;"'), t += ' onkeydown="return CKEDITOR.tools.callFunction({keydownFn},event,this);" onfocus="return CKEDITOR.tools.callFunction({focusFn},event);" ' + (CKEDITOR.env.ie ? 'onclick="return false;" onmouseup' : "onclick") + '="CKEDITOR.tools.callFunction({clickFn},this);return false;"><span id="{id}_text" class="cke_combo_text cke_combo_inlinelabel">{label}</span><span class="cke_combo_open"><span class="cke_combo_arrow">' + (CKEDITOR.env.hc ? "&#9660;" : CKEDITOR.env.air ? "&nbsp;" : "") + "</span></span></a></span>";
        var e = CKEDITOR.addTemplate("combo", t);
        CKEDITOR.UI_RICHCOMBO = "richcombo", CKEDITOR.ui.richCombo = CKEDITOR.tools.createClass({
            $: function(t) {
                CKEDITOR.tools.extend(this, t, {
                    canGroup: !1,
                    title: t.label,
                    modes: {
                        wysiwyg: 1
                    },
                    editorFocus: 1
                });
                var e = this.panel || {};
                delete this.panel, this.id = CKEDITOR.tools.getNextNumber(), this.document = e.parent && e.parent.getDocument() || CKEDITOR.document, e.className = "cke_combopanel", e.block = {
                    multiSelect: e.multiSelect,
                    attributes: e.attributes
                }, e.toolbarRelated = !0, this._ = {
                    panelDefinition: e,
                    items: {},
                    listeners: []
                }
            },
            proto: {
                renderHtml: function(t) {
                    var e = [];
                    return this.render(t, e), e.join("")
                },
                render: function(t, i) {
                    var n = CKEDITOR.env,
                        s = "cke_" + this.id,
                        o = CKEDITOR.tools.addFunction(function(e) {
                            u && (t.unlockSelection(1), u = 0), l.execute(e)
                        }, this),
                        a = this,
                        l = {
                            id: s,
                            combo: this,
                            focus: function() {
                                CKEDITOR.document.getById(s).getChild(1).focus()
                            },
                            execute: function(e) {
                                var i = a._;
                                if (i.state != CKEDITOR.TRISTATE_DISABLED)
                                    if (a.createPanel(t), i.on) i.panel.hide();
                                    else {
                                        a.commit();
                                        var n = a.getValue();
                                        n ? i.list.mark(n) : i.list.unmarkAll(), i.panel.showBlock(a.id, new CKEDITOR.dom.element(e), 4)
                                    }
                            },
                            clickFn: o
                        };

                    function c() {
                        if (this.getState() != CKEDITOR.TRISTATE_ON) {
                            var e = this.modes[t.mode] ? CKEDITOR.TRISTATE_OFF : CKEDITOR.TRISTATE_DISABLED;
                            t.readOnly && !this.readOnly && (e = CKEDITOR.TRISTATE_DISABLED), this.setState(e), this.setValue(""), e != CKEDITOR.TRISTATE_DISABLED && this.refresh && this.refresh()
                        }
                    }
                    this._.listeners.push(t.on("activeFilterChange", c, this)), this._.listeners.push(t.on("mode", c, this)), this._.listeners.push(t.on("selectionChange", c, this)), !this.readOnly && this._.listeners.push(t.on("readOnly", c, this));
                    var r = CKEDITOR.tools.addFunction(function(t, e) {
                            var i = (t = new CKEDITOR.dom.event(t)).getKeystroke();
                            switch (i) {
                                case 13:
                                case 32:
                                case 40:
                                    CKEDITOR.tools.callFunction(o, e);
                                    break;
                                default:
                                    l.onkey(l, i)
                            }
                            t.preventDefault()
                        }),
                        h = CKEDITOR.tools.addFunction(function() {
                            l.onfocus && l.onfocus()
                        }),
                        u = 0;
                    l.keyDownFn = r;
                    var d = {
                        id: s,
                        name: this.name || this.command,
                        label: this.label,
                        title: this.title,
                        cls: this.className || "",
                        titleJs: n.gecko && !n.hc ? "" : (this.title || "").replace("'", ""),
                        keydownFn: r,
                        focusFn: h,
                        clickFn: o
                    };
                    return e.output(d, i), this.onRender && this.onRender(), l
                },
                createPanel: function(t) {
                    if (!this._.panel) {
                        var e = this._.panelDefinition,
                            i = this._.panelDefinition.block,
                            n = e.parent || CKEDITOR.document.getBody(),
                            s = "cke_combopanel__" + this.name,
                            o = new CKEDITOR.ui.floatPanel(t, n, e),
                            a = o.addListBlock(this.id, i),
                            l = this;
                        o.onShow = function() {
                            this.element.addClass(s), l.setState(CKEDITOR.TRISTATE_ON), l._.on = 1, l.editorFocus && !t.focusManager.hasFocus && t.focus(), l.onOpen && l.onOpen()
                        }, o.onHide = function(e) {
                            this.element.removeClass(s), l.setState(l.modes && l.modes[t.mode] ? CKEDITOR.TRISTATE_OFF : CKEDITOR.TRISTATE_DISABLED), l._.on = 0, !e && l.onClose && l.onClose()
                        }, o.onEscape = function() {
                            o.hide(1)
                        }, a.onClick = function(t, e) {
                            l.onClick && l.onClick.call(l, t, e), o.hide()
                        }, this._.panel = o, this._.list = a, o.getBlock(this.id).onHide = function() {
                            l._.on = 0, l.setState(CKEDITOR.TRISTATE_OFF)
                        }, this.init && this.init()
                    }
                },
                setValue: function(t, e) {
                    this._.value = t;
                    var i = this.document.getById("cke_" + this.id + "_text");
                    i && (t || e ? i.removeClass("cke_combo_inlinelabel") : (e = this.label, i.addClass("cke_combo_inlinelabel")), i.setText(void 0 !== e ? e : t))
                },
                getValue: function() {
                    return this._.value || ""
                },
                unmarkAll: function() {
                    this._.list.unmarkAll()
                },
                mark: function(t) {
                    this._.list.mark(t)
                },
                hideItem: function(t) {
                    this._.list.hideItem(t)
                },
                hideGroup: function(t) {
                    this._.list.hideGroup(t)
                },
                showAll: function() {
                    this._.list.showAll()
                },
                add: function(t, e, i) {
                    this._.items[t] = i || t, this._.list.add(t, e, i)
                },
                startGroup: function(t) {
                    this._.list.startGroup(t)
                },
                commit: function() {
                    this._.committed || (this._.list.commit(), this._.committed = 1, CKEDITOR.ui.fire("ready", this)), this._.committed = 1
                },
                setState: function(t) {
                    if (this._.state != t) {
                        var e = this.document.getById("cke_" + this.id);
                        e.setState(t, "cke_combo"), t == CKEDITOR.TRISTATE_DISABLED ? e.setAttribute("aria-disabled", !0) : e.removeAttribute("aria-disabled"), this._.state = t
                    }
                },
                getState: function() {
                    return this._.state
                },
                enable: function() {
                    this._.state == CKEDITOR.TRISTATE_DISABLED && this.setState(this._.lastState)
                },
                disable: function() {
                    this._.state != CKEDITOR.TRISTATE_DISABLED && (this._.lastState = this._.state, this.setState(CKEDITOR.TRISTATE_DISABLED))
                },
                destroy: function() {
                    CKEDITOR.tools.array.forEach(this._.listeners, function(t) {
                        t.removeListener()
                    }), this._.listeners = []
                }
            },
            statics: {
                handler: {
                    create: function(t) {
                        return new CKEDITOR.ui.richCombo(t)
                    }
                }
            }
        }), CKEDITOR.ui.prototype.addRichCombo = function(t, e) {
            this.add(t, CKEDITOR.UI_RICHCOMBO, e)
        }
    }();