! function() {
    var o = function() {
        this.toolbars = [], this.focusCommandExecuted = !1
    };
    o.prototype.focus = function() {
        for (var o, e = 0; o = this.toolbars[e++];)
            for (var t, s = 0; t = o.items[s++];)
                if (t.focus) return void t.focus()
    };
    var e = {
        toolbarFocus: {
            modes: {
                wysiwyg: 1,
                source: 1
            },
            readOnly: 1,
            exec: function(o) {
                o.toolbox && (o.toolbox.focusCommandExecuted = !0, CKEDITOR.env.ie || CKEDITOR.env.air ? setTimeout(function() {
                    o.toolbox.focus()
                }, 100) : o.toolbox.focus())
            }
        }
    };

    function t(o) {
        return o._.toolbarGroups || (o._.toolbarGroups = [{
            name: "document",
            groups: ["mode", "document", "doctools"]
        }, {
            name: "clipboard",
            groups: ["undo"]
        }, {
            name: "forms"
        }, "/", {
            name: "basicstyles",
            groups: ["basicstyles", "cleanup"]
        }, {
            name: "paragraph",
            groups: ["list", "blocks", "align", "bidi"]
        }, {
            name: "links"
        }, {
            name: "insert"
        }, "/", {
            name: "styles"
        }, {
            name: "colors"
        }, {
            name: "tools"
        }, {
            name: "others"
        }, {
            name: "about"
        }])
    }
    CKEDITOR.plugins.add("toolbar", {
        requires: "button",
        lang: "af,ar,az,bg,bn,bs,ca,cs,cy,da,de,de-ch,el,en,en-au,en-ca,en-gb,eo,es,es-mx,et,eu,fa,fi,fo,fr,fr-ca,gl,gu,he,hi,hr,hu,id,is,it,ja,ka,km,ko,ku,lt,lv,mk,mn,ms,nb,nl,no,oc,pl,pt,pt-br,ro,ru,si,sk,sl,sq,sr,sr-latn,sv,th,tr,tt,ug,uk,vi,zh,zh-cn",
        init: function(s) {
            var a, n = function(o, e) {
                var t, r, l = "rtl" == s.lang.dir,
                    i = s.config.toolbarGroupCycling,
                    u = l ? 37 : 39,
                    c = l ? 39 : 37;
                switch (i = void 0 === i || i, e) {
                    case 9:
                    case CKEDITOR.SHIFT + 9:
                        for (; !r || !r.items.length;)
                            if ((r = 9 == e ? (r ? r.next : o.toolbar.next) || s.toolbox.toolbars[0] : (r ? r.previous : o.toolbar.previous) || s.toolbox.toolbars[s.toolbox.toolbars.length - 1]).items.length)
                                for (o = r.items[a ? r.items.length - 1 : 0]; o && !o.focus;)(o = a ? o.previous : o.next) || (r = 0);
                        return o && o.focus(), !1;
                    case u:
                        t = o;
                        do {
                            !(t = t.next) && i && (t = o.toolbar.items[0])
                        } while (t && !t.focus);
                        return t ? t.focus() : n(o, 9), !1;
                    case 40:
                        return o.button && o.button.hasArrow ? o.execute() : n(o, 40 == e ? u : c), !1;
                    case c:
                    case 38:
                        t = o;
                        do {
                            !(t = t.previous) && i && (t = o.toolbar.items[o.toolbar.items.length - 1])
                        } while (t && !t.focus);
                        return t ? t.focus() : (a = 1, n(o, CKEDITOR.SHIFT + 9), a = 0), !1;
                    case 27:
                        return s.focus(), !1;
                    case 13:
                    case 32:
                        return o.execute(), !1
                }
                return !0
            };
            s.on("uiSpace", function(e) {
                if (e.data.space == s.config.toolbarLocation) {
                    e.removeListener(), s.toolbox = new o;
                    var a, r, l = CKEDITOR.tools.getNextId(),
                        i = ['<span id="', l, '" class="cke_voice_label">', s.lang.toolbar.toolbars, "</span>", '<span id="' + s.ui.spaceId("toolbox") + '" class="cke_toolbox" role="group" aria-labelledby="', l, '" onmousedown="return false;">'],
                        u = !1 !== s.config.toolbarStartupExpanded;
                    s.config.toolbarCanCollapse && s.elementMode != CKEDITOR.ELEMENT_MODE_INLINE && i.push('<span class="cke_toolbox_main"' + (u ? ">" : ' style="display:none">'));
                    for (var c = s.toolbox.toolbars, p = function(o) {
                            var e = o.config.removeButtons;

                            function s(t, s) {
                                var a, n;
                                if (s.length)
                                    for (t.items ? t.items.push(o.ui.create("-")) : t.items = []; a = s.shift();)
                                        if (n = "string" == typeof a ? a : a.name, !e || -1 == CKEDITOR.tools.indexOf(e, n)) {
                                            if (!(a = o.ui.create(n))) continue;
                                            if (!o.addFeature(a)) continue;
                                            t.items.push(a)
                                        }
                            }
                            e = e && e.split(",");
                            var a = o.config.toolbar;
                            "string" == typeof a && (a = o.config["toolbar_" + a]);
                            return o.toolbar = a ? function(o) {
                                var e, t, a, n = [];
                                for (e = 0; e < o.length; ++e) t = o[e], a = {}, "/" == t ? n.push(t) : CKEDITOR.tools.isArray(t) ? (s(a, CKEDITOR.tools.clone(t)), n.push(a)) : t.items && (s(a, CKEDITOR.tools.clone(t.items)), a.name = t.name, n.push(a));
                                return n
                            }(a) : function() {
                                for (var e = function() {
                                        var e, t, s, a, n, r = {};
                                        for (e in o.ui.items) t = o.ui.items[e], (s = t.toolbar || "others") && (s = s.split(","), a = s[0], n = parseInt(s[1] || -1, 10), r[a] || (r[a] = []), r[a].push({
                                            name: e,
                                            order: n
                                        }));
                                        for (a in r) r[a] = r[a].sort(function(o, e) {
                                            return o.order == e.order ? 0 : e.order < 0 ? -1 : o.order < 0 ? 1 : o.order < e.order ? -1 : 1
                                        });
                                        return r
                                    }(), a = CKEDITOR.tools.clone(o.config.toolbarGroups) || t(o), n = 0; n < a.length; n++) {
                                    var r = a[n];
                                    if ("/" != r) {
                                        "string" == typeof r && (r = a[n] = {
                                            name: r
                                        });
                                        var l, i = r.groups;
                                        if (i)
                                            for (var u, c = 0; c < i.length; c++) u = i[c], (l = e[u]) && s(r, l);
                                        (l = e[r.name]) && s(r, l)
                                    }
                                }
                                return a
                            }()
                        }(s), f = p.length, b = 0; b < f; b++) {
                        var d, m, h, g = 0,
                            v = p[b],
                            C = "/" !== v && ("/" === p[b + 1] || b == f - 1);
                        if (v)
                            if (a && (i.push("</span>"), a = 0, r = 0), "/" !== v) {
                                h = v.items || v;
                                for (var E = 0; E < h.length; E++) {
                                    var I, x = h[E];
                                    if (x) {
                                        if (x.type == CKEDITOR.UI_SEPARATOR) {
                                            r = a && x;
                                            continue
                                        }
                                        if (I = !1 !== x.canGroup, !g) {
                                            d = CKEDITOR.tools.getNextId(), g = {
                                                id: d,
                                                items: []
                                            }, m = v.name && (s.lang.toolbar.toolbarGroups[v.name] || v.name), i.push('<span id="', d, '" class="cke_toolbar' + (C ? ' cke_toolbar_last"' : '"'), m ? ' aria-labelledby="' + d + '_label"' : "", ' role="toolbar">'), m && i.push('<span id="', d, '_label" class="cke_voice_label">', m, "</span>"), i.push('<span class="cke_toolbar_start"></span>');
                                            var T = c.push(g) - 1;
                                            T > 0 && (g.previous = c[T - 1], g.previous.next = g)
                                        }

                                        function O(o) {
                                            var e = o.render(s, i);
                                            (T = g.items.push(e) - 1) > 0 && (e.previous = g.items[T - 1], e.previous.next = e), e.toolbar = g, e.onkey = n, e.onfocus = function() {
                                                s.toolbox.focusCommandExecuted || s.focus()
                                            }
                                        }
                                        I ? a || (i.push('<span class="cke_toolgroup" role="presentation">'), a = 1) : a && (i.push("</span>"), a = 0), r && (O(r), r = 0), O(x)
                                    }
                                }
                                a && (i.push("</span>"), a = 0, r = 0), g && i.push('<span class="cke_toolbar_end"></span></span>')
                            } else i.push('<span class="cke_toolbar_break"></span>')
                    }
                    if (s.config.toolbarCanCollapse && i.push("</span>"), s.config.toolbarCanCollapse && s.elementMode != CKEDITOR.ELEMENT_MODE_INLINE) {
                        var _ = CKEDITOR.tools.addFunction(function() {
                            s.execCommand("toolbarCollapse")
                        });
                        s.on("destroy", function() {
                            CKEDITOR.tools.removeFunction(_)
                        }), s.addCommand("toolbarCollapse", {
                            readOnly: 1,
                            exec: function(o) {
                                var e = o.ui.space("toolbar_collapser"),
                                    t = e.getPrevious(),
                                    s = o.ui.space("contents"),
                                    a = t.getParent(),
                                    n = parseInt(s.$.style.height, 10),
                                    r = a.$.offsetHeight,
                                    l = "cke_toolbox_collapser_min",
                                    i = e.hasClass(l);
                                i ? (t.show(), e.removeClass(l), e.setAttribute("title", o.lang.toolbar.toolbarCollapse)) : (t.hide(), e.addClass(l), e.setAttribute("title", o.lang.toolbar.toolbarExpand)), e.getFirst().setText(i ? "▲" : "◀");
                                var u = a.$.offsetHeight - r;
                                s.setStyle("height", n - u + "px"), o.fire("resize", {
                                    outerHeight: o.container.$.offsetHeight,
                                    contentsHeight: s.$.offsetHeight,
                                    outerWidth: o.container.$.offsetWidth
                                })
                            },
                            modes: {
                                wysiwyg: 1,
                                source: 1
                            }
                        }), s.setKeystroke(CKEDITOR.ALT + (CKEDITOR.env.ie || CKEDITOR.env.webkit ? 189 : 109), "toolbarCollapse"), i.push('<a title="' + (u ? s.lang.toolbar.toolbarCollapse : s.lang.toolbar.toolbarExpand) + '" id="' + s.ui.spaceId("toolbar_collapser") + '" tabIndex="-1" class="cke_toolbox_collapser'), u || i.push(" cke_toolbox_collapser_min"), i.push('" onclick="CKEDITOR.tools.callFunction(' + _ + ')">', '<span class="cke_arrow">&#9650;</span>', "</a>")
                    }
                    i.push("</span>"), e.data.html += i.join("")
                }
            }), s.on("destroy", function() {
                if (this.toolbox) {
                    var o, e, t, s, a = 0;
                    for (o = this.toolbox.toolbars; a < o.length; a++)
                        for (t = o[a].items, e = 0; e < t.length; e++)(s = t[e]).clickFn && CKEDITOR.tools.removeFunction(s.clickFn), s.keyDownFn && CKEDITOR.tools.removeFunction(s.keyDownFn)
                }
            }), s.on("uiReady", function() {
                var o = s.ui.space("toolbox");
                o && s.focusManager.add(o, 1)
            }), s.addCommand("toolbarFocus", e.toolbarFocus), s.setKeystroke(CKEDITOR.ALT + 121, "toolbarFocus"), s.ui.add("-", CKEDITOR.UI_SEPARATOR, {}), s.ui.addHandler(CKEDITOR.UI_SEPARATOR, {
                create: function() {
                    return {
                        render: function(o, e) {
                            return e.push('<span class="cke_toolbar_separator" role="separator"></span>'), {}
                        }
                    }
                }
            })
        }
    }), CKEDITOR.ui.prototype.addToolbarGroup = function(o, e, s) {
        var a = t(this.editor),
            n = 0 === e,
            r = {
                name: o
            };
        if (s) {
            if (s = CKEDITOR.tools.search(a, function(o) {
                    return o.name == s
                })) return !s.groups && (s.groups = []), e && (e = CKEDITOR.tools.indexOf(s.groups, e)) >= 0 ? void s.groups.splice(e + 1, 0, o) : void(n ? s.groups.splice(0, 0, o) : s.groups.push(o));
            e = null
        }
        e && (e = CKEDITOR.tools.indexOf(a, function(o) {
            return o.name == e
        })), n ? a.splice(0, 0, o) : "number" == typeof e ? a.splice(e + 1, 0, r) : a.push(o)
    }
}(), CKEDITOR.UI_SEPARATOR = "separator", CKEDITOR.config.toolbarLocation = "top";