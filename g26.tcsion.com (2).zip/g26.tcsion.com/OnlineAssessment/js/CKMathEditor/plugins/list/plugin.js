! function() {
    var e = {
            ol: 1,
            ul: 1
        },
        t = CKEDITOR.dom.walker.whitespaces(),
        n = CKEDITOR.dom.walker.bookmark(),
        r = function(e) {
            return !(t(e) || n(e))
        },
        o = CKEDITOR.dom.walker.bogus();

    function a(e) {
        var t, n, r;
        if (t = e.getDirection()) {
            for (n = e.getParent(); n && !(r = n.getDirection());) n = n.getParent();
            t == r && e.removeAttribute("dir")
        }
    }

    function i(e, t) {
        var n = e.getAttribute("style");
        n && t.setAttribute("style", n.replace(/([^;])$/, "$1;") + (t.getAttribute("style") || ""))
    }

    function l(e, t, n, r) {
        for (var o = CKEDITOR.plugins.list.listToArray(t.root, n), a = [], i = 0; i < t.contents.length; i++) {
            var l = t.contents[i];
            (l = l.getAscendant("li", !0)) && !l.getCustomData("list_item_processed") && (a.push(l), CKEDITOR.dom.element.setMarker(n, l, "list_item_processed", !0))
        }
        var s, E, d = t.root.getDocument();
        for (i = 0; i < a.length; i++) {
            var c = a[i].getCustomData("listarray_index");
            (s = o[c].parent).is(this.type) || (E = d.createElement(this.type), s.copyAttributes(E, {
                start: 1,
                type: 1
            }), E.removeStyle("list-style-type"), o[c].parent = E)
        }
        var T, u = CKEDITOR.plugins.list.arrayToList(o, n, null, e.config.enterMode),
            g = u.listNode.getChildCount();
        for (i = 0; i < g && (T = u.listNode.getChild(i)); i++) T.getName() == this.type && r.push(T);
        u.listNode.replace(t.root), e.fire("contentDomInvalidated")
    }

    function s(e, t, n) {
        var r = t.contents,
            o = t.root.getDocument(),
            a = [];
        if (1 == r.length && r[0].equals(t.root)) {
            var i = o.createElement("div");
            r[0].moveChildren && r[0].moveChildren(i), r[0].append(i), r[0] = i
        }
        for (var l = t.contents[0].getParent(), s = 0; s < r.length; s++) l = l.getCommonAncestor(r[s].getParent());
        var E, c, T = e.config.useComputedState;
        for (T = void 0 === T || T, s = 0; s < r.length; s++)
            for (var u, g = r[s]; u = g.getParent();) {
                if (u.equals(l)) {
                    a.push(g), !c && g.getDirection() && (c = 1);
                    var m = g.getDirection(T);
                    null !== E && (E = E && E != m ? null : m);
                    break
                }
                g = u
            }
        if (!(a.length < 1)) {
            var O, D, p, C = a[a.length - 1].getNext(),
                I = o.createElement(this.type);
            for (n.push(I); a.length;) O = a.shift(), D = o.createElement("li"), (p = O).is("pre") || d.test(p.getName()) || "false" == p.getAttribute("contenteditable") ? O.appendTo(D) : (O.copyAttributes(D), E && O.getDirection() && (D.removeStyle("direction"), D.removeAttribute("dir")), O.moveChildren(D), O.remove()), D.appendTo(I);
            E && c && I.setAttribute("dir", E), C ? I.insertBefore(C) : I.appendTo(l)
        }
    }

    function E(e, t, n) {
        for (var r = CKEDITOR.plugins.list.listToArray(t.root, n), o = [], a = 0; a < t.contents.length; a++) {
            var i = t.contents[a];
            (i = i.getAscendant("li", !0)) && !i.getCustomData("list_item_processed") && (o.push(i), CKEDITOR.dom.element.setMarker(n, i, "list_item_processed", !0))
        }
        var l = null;
        for (a = 0; a < o.length; a++) {
            var s = o[a].getCustomData("listarray_index");
            r[s].indent = -1, l = s
        }
        for (a = l + 1; a < r.length; a++)
            if (r[a].indent > r[a - 1].indent + 1) {
                for (var E = r[a - 1].indent + 1 - r[a].indent, d = r[a].indent; r[a] && r[a].indent >= d;) r[a].indent += E, a++;
                a--
            }
        var c, T, u = CKEDITOR.plugins.list.arrayToList(r, n, null, e.config.enterMode, t.root.getAttribute("dir")).listNode;

        function g(n) {
            !(c = u[n ? "getFirst" : "getLast"]()) || c.is && c.isBlockBoundary() || !(T = t.root[n ? "getPrevious" : "getNext"](CKEDITOR.dom.walker.invisible(!0))) || T.is && T.isBlockBoundary({
                br: 1
            }) || e.document.createElement("br")[n ? "insertBefore" : "insertAfter"](c)
        }
        g(!0), g(), u.replace(t.root), e.fire("contentDomInvalidated")
    }
    CKEDITOR.plugins.list = {
        listToArray: function(t, n, r, o, a) {
            if (!e[t.getName()]) return [];
            o || (o = 0), r || (r = []);
            for (var i = 0, l = t.getChildCount(); i < l; i++) {
                var s = t.getChild(i);
                if (s.type == CKEDITOR.NODE_ELEMENT && s.getName() in CKEDITOR.dtd.$list && CKEDITOR.plugins.list.listToArray(s, n, r, o + 1), "li" == s.$.nodeName.toLowerCase()) {
                    var E = {
                        parent: t,
                        indent: o,
                        element: s,
                        contents: []
                    };
                    a ? E.grandparent = a : (E.grandparent = t.getParent(), E.grandparent && "li" == E.grandparent.$.nodeName.toLowerCase() && (E.grandparent = E.grandparent.getParent())), n && CKEDITOR.dom.element.setMarker(n, s, "listarray_index", r.length), r.push(E);
                    for (var d, c = 0, T = s.getChildCount(); c < T; c++)(d = s.getChild(c)).type == CKEDITOR.NODE_ELEMENT && e[d.getName()] ? CKEDITOR.plugins.list.listToArray(d, n, r, o + 1, E.grandparent) : E.contents.push(d)
                }
            }
            return r
        },
        arrayToList: function(t, o, l, s, E) {
            if (l || (l = 0), !t || t.length < l + 1) return null;
            for (var d, c, T, u = t[l].parent.getDocument(), g = new CKEDITOR.dom.documentFragment(u), m = null, O = l, D = Math.max(t[l].indent, 0), p = null, C = s == CKEDITOR.ENTER_P ? "p" : "div";;) {
                var I = t[O],
                    R = I.grandparent;
                if (c = I.element.getDirection(1), I.indent == D) {
                    for (m && t[O].parent.getName() == m.getName() || (m = t[O].parent.clone(!1, 1), E && m.setAttribute("dir", E), g.append(m)), p = m.append(I.element.clone(0, 1)), c != m.getDirection(1) && p.setAttribute("dir", c), d = 0; d < I.contents.length; d++) p.append(I.contents[d].clone(1, 1));
                    O++
                } else if (I.indent == Math.max(D, 0) + 1) {
                    var f = t[O - 1].element.getDirection(1),
                        N = CKEDITOR.plugins.list.arrayToList(t, null, O, s, f != c ? c : null);
                    !p.getChildCount() && CKEDITOR.env.needsNbspFiller && u.$.documentMode <= 7 && p.append(u.createText(" ")), p.append(N.listNode), O = N.nextIndex
                } else {
                    if (-1 != I.indent || l || !R) return null;
                    e[R.getName()] ? (p = I.element.clone(!1, !0), c != R.getDirection(1) && p.setAttribute("dir", c)) : p = new CKEDITOR.dom.documentFragment(u);
                    var v, h, K, _ = R.getDirection(1) != c,
                        b = I.element,
                        y = b.getAttribute("class"),
                        k = b.getAttribute("style"),
                        A = p.type == CKEDITOR.NODE_DOCUMENT_FRAGMENT && (s != CKEDITOR.ENTER_BR || _ || k || y),
                        S = I.contents.length;
                    for (d = 0; d < S; d++) v = I.contents[d], n(v) && S > 1 ? A ? h = v.clone(1, 1) : p.append(v.clone(1, 1)) : v.type == CKEDITOR.NODE_ELEMENT && v.isBlockBoundary() ? (_ && !v.getDirection() && v.setAttribute("dir", c), i(b, v), y && v.addClass(y), T = null, h && (p.append(h), h = null), p.append(v.clone(1, 1))) : A ? (T || (T = u.createElement(C), p.append(T), _ && T.setAttribute("dir", c)), k && T.setAttribute("style", k), y && T.setAttribute("class", y), h && (T.append(h), h = null), T.append(v.clone(1, 1))) : p.append(v.clone(1, 1));
                    h && ((T || p).append(h), h = null), p.type == CKEDITOR.NODE_DOCUMENT_FRAGMENT && O != t.length - 1 && (CKEDITOR.env.needsBrFiller && (K = p.getLast()) && K.type == CKEDITOR.NODE_ELEMENT && K.is("br") && K.remove(), (K = p.getLast(r)) && K.type == CKEDITOR.NODE_ELEMENT && K.is(CKEDITOR.dtd.$block) || p.append(u.createElement("br")));
                    var P = p.$.nodeName.toLowerCase();
                    "div" != P && "p" != P || p.appendBogus(), g.append(p), m = null, O++
                }
                if (T = null, t.length <= O || Math.max(t[O].indent, 0) < D) break
            }
            if (o)
                for (var B = g.getFirst(); B;) B.type == CKEDITOR.NODE_ELEMENT && (CKEDITOR.dom.element.clearMarkers(o, B), B.getName() in CKEDITOR.dtd.$listItem && a(B)), B = B.getNextSourceNode();
            return {
                listNode: g,
                nextIndex: O
            }
        }
    };
    var d = /^h[1-6]$/;

    function c(e, t) {
        this.name = e, this.type = t, this.context = t, this.allowedContent = t + " li", this.requiredContent = t
    }
    var T = CKEDITOR.dom.walker.nodeType(CKEDITOR.NODE_ELEMENT);

    function u(e, t, n, r) {
        for (var o, a; o = e[r ? "getLast" : "getFirst"](T);)(a = o.getDirection(1)) !== t.getDirection(1) && o.setAttribute("dir", a), o.remove(), n ? o[r ? "insertBefore" : "insertAfter"](n) : t.append(o, r)
    }

    function g(e) {
        function t(t) {
            var n = e[t ? "getPrevious" : "getNext"](r);
            n && n.type == CKEDITOR.NODE_ELEMENT && n.is(e.getName()) && (u(e, n, null, !t), e.remove(), e = n)
        }
        t(), t(1)
    }

    function m(e) {
        return e.type == CKEDITOR.NODE_ELEMENT && (e.getName() in CKEDITOR.dtd.$block || e.getName() in CKEDITOR.dtd.$listItem) && CKEDITOR.dtd[e.getName()]["#"]
    }

    function O(e, t, n) {
        e.fire("saveSnapshot"), n.enlarge(CKEDITOR.ENLARGE_LIST_ITEM_CONTENTS);
        var a = n.extractContents();
        t.trim(!1, !0);
        var i, l = t.createBookmark(),
            s = new CKEDITOR.dom.elementPath(t.startContainer),
            E = s.block,
            d = s.lastElement.getAscendant("li", 1) || E,
            c = new CKEDITOR.dom.elementPath(n.startContainer),
            T = c.contains(CKEDITOR.dtd.$listItem),
            m = c.contains(CKEDITOR.dtd.$list);
        if (E) {
            var O = E.getBogus();
            O && O.remove()
        } else m && (i = m.getPrevious(r)) && o(i) && i.remove();
        (i = a.getLast()) && i.type == CKEDITOR.NODE_ELEMENT && i.is("br") && i.remove();
        var p, C, I = t.startContainer.getChild(t.startOffset);
        if (I ? a.insertBefore(I) : t.startContainer.append(a), T) {
            var R = D(T);
            R && (d.contains(T) ? (u(R, T.getParent(), T), R.remove()) : d.append(R))
        }
        for (; n.checkStartOfBlock() && n.checkEndOfBlock() && (p = (c = n.startPath()).block);) p.is("li") && (C = p.getParent(), p.equals(C.getLast(r)) && p.equals(C.getFirst(r)) && (p = C)), n.moveToPosition(p, CKEDITOR.POSITION_BEFORE_START), p.remove();
        var f = n.clone(),
            N = e.editable();
        f.setEndAt(N, CKEDITOR.POSITION_BEFORE_END);
        var v = new CKEDITOR.dom.walker(f);
        v.evaluator = function(e) {
            return r(e) && !o(e)
        };
        var h = v.next();
        h && h.type == CKEDITOR.NODE_ELEMENT && h.getName() in CKEDITOR.dtd.$list && g(h), t.moveToBookmark(l), t.select(), e.fire("saveSnapshot")
    }

    function D(t) {
        var n = t.getLast(r);
        return n && n.type == CKEDITOR.NODE_ELEMENT && n.getName() in e ? n : null
    }
    c.prototype = {
        exec: function(t) {
            this.refresh(t, t.elementPath());
            var n = t.config,
                o = t.getSelection(),
                a = o && o.getRanges();
            if (this.state == CKEDITOR.TRISTATE_OFF) {
                var i = t.editable();
                if (i.getFirst(r)) {
                    var d = 1 == a.length && a[0],
                        c = d && d.getEnclosedNode();
                    c && c.is && this.type == c.getName() && this.setState(CKEDITOR.TRISTATE_ON)
                } else n.enterMode == CKEDITOR.ENTER_BR ? i.appendBogus() : a[0].fixBlock(1, n.enterMode == CKEDITOR.ENTER_P ? "p" : "div"), o.selectRanges(a)
            }
            for (var T = o.createBookmarks(!0), u = [], m = {}, O = a.createIterator(), D = 0;
                (d = O.getNextRange()) && ++D;) {
                var p = d.getBoundaryNodes(),
                    C = p.startNode,
                    I = p.endNode;
                C.type == CKEDITOR.NODE_ELEMENT && "td" == C.getName() && d.setStartAt(p.startNode, CKEDITOR.POSITION_AFTER_START), I.type == CKEDITOR.NODE_ELEMENT && "td" == I.getName() && d.setEndAt(p.endNode, CKEDITOR.POSITION_BEFORE_END);
                var R, f = d.createIterator();
                for (f.forceBrBreak = this.state == CKEDITOR.TRISTATE_OFF; R = f.getNextParagraph();)
                    if (!R.getCustomData("list_block") && !B(R)) {
                        CKEDITOR.dom.element.setMarker(m, R, "list_block", 1);
                        for (var N, v = t.elementPath(R), h = v.elements, K = h.length, _ = 0, b = v.blockLimit, y = K - 1; y >= 0 && (N = h[y]); y--)
                            if (e[N.getName()] && b.contains(N)) {
                                b.removeCustomData("list_group_object_" + D);
                                var k = N.getCustomData("list_group_object");
                                k ? k.contents.push(R) : (k = {
                                    root: N,
                                    contents: [R]
                                }, u.push(k), CKEDITOR.dom.element.setMarker(m, N, "list_group_object", k)), _ = 1;
                                break
                            }
                        if (!_) {
                            var A = b;
                            A.getCustomData("list_group_object_" + D) ? A.getCustomData("list_group_object_" + D).contents.push(R) : (k = {
                                root: A,
                                contents: [R]
                            }, CKEDITOR.dom.element.setMarker(m, A, "list_group_object_" + D, k), u.push(k))
                        }
                    }
            }
            for (var S = []; u.length > 0;)
                if (k = u.shift(), this.state == CKEDITOR.TRISTATE_OFF) {
                    if (P(k)) continue;
                    e[k.root.getName()] ? l.call(this, t, k, m, S) : s.call(this, t, k, S)
                } else this.state == CKEDITOR.TRISTATE_ON && e[k.root.getName()] && !P(k) && E.call(this, t, k, m);
            for (y = 0; y < S.length; y++) g(S[y]);

            function P(t) {
                return e[t.root.getName()] && (n = t.root, r = [CKEDITOR.NODE_COMMENT], !CKEDITOR.tools.array.filter(n.getChildren().toArray(), function(e) {
                    return -1 === CKEDITOR.tools.array.indexOf(r, e.type)
                }).length);
                var n, r
            }

            function B(e) {
                var t = !0;
                return 0 !== e.getChildCount() && (e.forEach(function(e) {
                    if (e.type !== CKEDITOR.NODE_COMMENT) return t = !1, !1
                }, null, !0), t)
            }
            CKEDITOR.dom.element.clearAllMarkers(m), o.selectBookmarks(T), t.focus()
        },
        refresh: function(t, n) {
            var r = n.contains(e, 1),
                o = n.blockLimit || n.root;
            r && o.contains(r) ? this.setState(r.is(this.type) ? CKEDITOR.TRISTATE_ON : CKEDITOR.TRISTATE_OFF) : this.setState(CKEDITOR.TRISTATE_OFF)
        }
    }, CKEDITOR.plugins.add("list", {
        lang: "af,ar,az,bg,bn,bs,ca,cs,cy,da,de,de-ch,el,en,en-au,en-ca,en-gb,eo,es,es-mx,et,eu,fa,fi,fo,fr,fr-ca,gl,gu,he,hi,hr,hu,id,is,it,ja,ka,km,ko,ku,lt,lv,mk,mn,ms,nb,nl,no,oc,pl,pt,pt-br,ro,ru,si,sk,sl,sq,sr,sr-latn,sv,th,tr,tt,ug,uk,vi,zh,zh-cn",
        icons: "bulletedlist,bulletedlist-rtl,numberedlist,numberedlist-rtl",
        hidpi: !0,
        requires: "",
        init: function(t) {
            t.blockless || (t.addCommand("numberedlist", new c("numberedlist", "ol")), t.addCommand("bulletedlist", new c("bulletedlist", "ul")), t.ui.addButton && (t.ui.addButton("NumberedList", {
                label: t.lang.list.numberedlist,
                command: "numberedlist",
                directional: !0,
                toolbar: "list,10"
            }), t.ui.addButton("BulletedList", {
                label: t.lang.list.bulletedlist,
                command: "bulletedlist",
                directional: !0,
                toolbar: "list,20"
            })), t.on("key", function(n) {
                var a, i = n.data.domEvent.getKey();
                if ("wysiwyg" == t.mode && i in {
                        8: 1,
                        46: 1
                    }) {
                    var l = t.getSelection().getRanges()[0],
                        s = l && l.startPath();
                    if (!l || !l.collapsed) return;
                    var E = 8 == i,
                        d = t.editable(),
                        c = new CKEDITOR.dom.walker(l.clone());
                    c.evaluator = function(e) {
                        return r(e) && !o(e)
                    }, c.guard = function(e, t) {
                        return !(t && e.type == CKEDITOR.NODE_ELEMENT && e.is("table"))
                    };
                    var T, u, g, p, C = l.clone();
                    if (E)
                        if ((T = s.contains(e)) && l.checkBoundaryOfElement(T, CKEDITOR.START) && (T = T.getParent()) && T.is("li") && (T = D(T)) ? (u = T, T = T.getPrevious(r), C.moveToPosition(T && o(T) ? T : u, CKEDITOR.POSITION_BEFORE_START)) : (c.range.setStartAt(d, CKEDITOR.POSITION_AFTER_START), c.range.setEnd(l.startContainer, l.startOffset), (T = c.previous()) && T.type == CKEDITOR.NODE_ELEMENT && (T.getName() in e || T.is("li")) && (T.is("li") || (c.range.selectNodeContents(T), c.reset(), c.evaluator = m, T = c.previous()), u = T, C.moveToElementEditEnd(u), C.moveToPosition(C.endPath().block, CKEDITOR.POSITION_BEFORE_END))), u) O(t, C, l), n.cancel();
                        else {
                            var I = s.contains(e);
                            I && l.checkBoundaryOfElement(I, CKEDITOR.START) && (a = I.getFirst(r), l.checkBoundaryOfElement(a, CKEDITOR.START) && (T = I.getPrevious(r), D(a) ? (T && (l.moveToElementEditEnd(T), l.select()), n.cancel()) : (t.execCommand("outdent"), n.cancel())))
                        }
                    else if (a = s.contains("li")) {
                        c.range.setEndAt(d, CKEDITOR.POSITION_BEFORE_END);
                        var R = a.getLast(r),
                            f = R && m(R) ? R : a,
                            N = 0;
                        if ((g = c.next()) && g.type == CKEDITOR.NODE_ELEMENT && g.getName() in e && g.equals(R) ? (N = 1, g = c.next()) : l.checkBoundaryOfElement(f, CKEDITOR.END) && (N = 2), N && g) {
                            if ((p = l.clone()).moveToElementEditStart(g), 1 == N && (C.optimize(), !C.startContainer.equals(a))) {
                                for (var v, h = C.startContainer; h.is(CKEDITOR.dtd.$inline);) v = h, h = h.getParent();
                                v && C.moveToPosition(v, CKEDITOR.POSITION_AFTER_END)
                            }
                            2 == N && (C.moveToPosition(C.endPath().block, CKEDITOR.POSITION_BEFORE_END), p.endPath().block && p.moveToPosition(p.endPath().block, CKEDITOR.POSITION_AFTER_START)), O(t, C, p), n.cancel()
                        }
                    } else c.range.setEndAt(d, CKEDITOR.POSITION_BEFORE_END), (g = c.next()) && g.type == CKEDITOR.NODE_ELEMENT && g.is(e) && (g = g.getFirst(r), s.block && l.checkStartOfBlock() && l.checkEndOfBlock() ? (s.block.remove(), l.moveToElementEditStart(g), l.select(), n.cancel()) : D(g) ? (l.moveToElementEditStart(g), l.select(), n.cancel()) : ((p = l.clone()).moveToElementEditStart(g), O(t, C, p), n.cancel()));
                    setTimeout(function() {
                        t.selectionChange(1)
                    })
                }
            }))
        }
    })
}();