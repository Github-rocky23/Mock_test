! function() {
    function e(e, n, i, a, s, l, o, r) {
        for (var f = e.config, c = new CKEDITOR.style(o), u = s.split(";"), m = [], T = {}, d = 0; d < u.length; d++) {
            var p = u[d];
            if (p) {
                p = p.split("/");
                var h = {},
                    g = u[d] = p[0];
                h[i] = m[d] = p[1] || g, T[g] = new CKEDITOR.style(o, h), T[g]._.definition.name = g
            } else u.splice(d--, 1)
        }
        e.ui.addRichCombo(n, {
            label: a.label,
            title: a.panelTitle,
            toolbar: "styles," + r,
            defaultValue: "cke-default",
            allowedContent: c,
            requiredContent: c,
            contentTransformations: "span" === o.element ? [
                [{
                    element: "font",
                    check: "span",
                    left: function(e) {
                        return !!e.attributes.size || !!e.attributes.align || !!e.attributes.face
                    },
                    right: function(e) {
                        e.name = "span", e.attributes.size && (e.styles["font-size"] = ["", "x-small", "small", "medium", "large", "x-large", "xx-large", "48px"][e.attributes.size], delete e.attributes.size), e.attributes.align && (e.styles["text-align"] = e.attributes.align, delete e.attributes.align), e.attributes.face && (e.styles["font-family"] = e.attributes.face, delete e.attributes.face)
                    }
                }]
            ] : null,
            panel: {
                css: [CKEDITOR.skin.getPath("editor")].concat(f.contentsCss),
                multiSelect: !1,
                attributes: {
                    "aria-label": a.panelTitle
                }
            },
            init: function() {
                var t, n = "(" + e.lang.common.optionDefault + ")";
                this.startGroup(a.panelTitle), this.add(this.defaultValue, n, n);
                for (var i = 0; i < u.length; i++) t = u[i], this.add(t, T[t].buildPreview(), t)
            },
            onClick: function(n) {
                e.focus(), e.fire("saveSnapshot");
                var i, a, s, l, o, r, f, c, u = this.getValue(),
                    m = T[n];
                if (u && n != u)
                    if (i = T[u], (a = e.getSelection().getRanges()[0]).collapsed) {
                        if (l = (s = e.elementPath()).contains(function(e) {
                                return i.checkElementRemovable(e)
                            })) {
                            if (o = a.checkBoundaryOfElement(l, CKEDITOR.START), r = a.checkBoundaryOfElement(l, CKEDITOR.END), o && r) {
                                for (c = a.createBookmark(); f = l.getFirst();) f.insertBefore(l);
                                l.remove(), a.moveToBookmark(c)
                            } else o || r ? (a.moveToPosition(l, o ? CKEDITOR.POSITION_BEFORE_START : CKEDITOR.POSITION_AFTER_END), t(a, s.elements.slice(), l)) : (a.splitElement(l), a.moveToPosition(l, CKEDITOR.POSITION_AFTER_END), t(a, s.elements.slice(), l));
                            e.getSelection().selectRanges([a])
                        }
                    } else e.removeStyle(i);
                n === this.defaultValue ? i && e.removeStyle(i) : e.applyStyle(m), e.fire("saveSnapshot")
            },
            onRender: function() {
                e.on("selectionChange", function(t) {
                    for (var n, i = this.getValue(), a = t.data.path.elements, s = 0; s < a.length; s++)
                        for (var o in n = a[s], T)
                            if (T[o].checkElementMatch(n, !0, e)) return void(o != i && this.setValue(o));
                    this.setValue("", l)
                }, this)
            },
            refresh: function() {
                e.activeFilter.check(c) || this.setState(CKEDITOR.TRISTATE_DISABLED)
            }
        })
    }

    function t(e, n, i) {
        var a = n.pop();
        if (a) {
            if (i) return t(e, n, a.equals(i) ? null : i);
            var s = a.clone();
            e.insertNode(s), e.moveToPosition(s, CKEDITOR.POSITION_AFTER_START), t(e, n)
        }
    }
    CKEDITOR.plugins.add("font", {
        requires: "richcombo",
        lang: "af,ar,az,bg,bn,bs,ca,cs,cy,da,de,de-ch,el,en,en-au,en-ca,en-gb,eo,es,es-mx,et,eu,fa,fi,fo,fr,fr-ca,gl,gu,he,hi,hr,hu,id,is,it,ja,ka,km,ko,ku,lt,lv,mk,mn,ms,nb,nl,no,oc,pl,pt,pt-br,ro,ru,si,sk,sl,sq,sr,sr-latn,sv,th,tr,tt,ug,uk,vi,zh,zh-cn",
        init: function(t) {
            var n = t.config;
            e(t, "Font", "family", t.lang.font, n.font_names, n.font_defaultLabel, n.font_style, 30), e(t, "FontSize", "size", t.lang.font.fontSize, n.fontSize_sizes, n.fontSize_defaultLabel, n.fontSize_style, 40)
        }
    })
}(), CKEDITOR.config.font_names = "Arial/Arial, Helvetica, sans-serif;Comic Sans MS/Comic Sans MS, cursive;Courier New/Courier New, Courier, monospace;Georgia/Georgia, serif;Lucida Sans Unicode/Lucida Sans Unicode, Lucida Grande, sans-serif;Tahoma/Tahoma, Geneva, sans-serif;Times New Roman/Times New Roman, Times, serif;Trebuchet MS/Trebuchet MS, Helvetica, sans-serif;Verdana/Verdana, Geneva, sans-serif", CKEDITOR.config.font_defaultLabel = "", CKEDITOR.config.font_style = {
    element: "span",
    styles: {
        "font-family": "#(family)"
    },
    overrides: [{
        element: "font",
        attributes: {
            face: null
        }
    }]
}, CKEDITOR.config.fontSize_sizes = "8/8px;9/9px;10/10px;11/11px;12/12px;14/14px;16/16px;18/18px;20/20px;22/22px;24/24px;26/26px;28/28px;36/36px;48/48px;72/72px", CKEDITOR.config.fontSize_defaultLabel = "", CKEDITOR.config.fontSize_style = {
    element: "span",
    styles: {
        "font-size": "#(size)"
    },
    overrides: [{
        element: "font",
        attributes: {
            size: null
        }
    }]
};