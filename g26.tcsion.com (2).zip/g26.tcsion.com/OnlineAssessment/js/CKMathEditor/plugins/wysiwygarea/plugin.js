! function() {
    var e;

    function t(e) {
        var t = this.editor,
            n = e.document,
            i = n.body,
            a = n.getElementById("cke_actscrpt");
        a && a.parentNode.removeChild(a), (a = n.getElementById("cke_shimscrpt")) && a.parentNode.removeChild(a), (a = n.getElementById("cke_basetagscrpt")) && a.parentNode.removeChild(a), i.contentEditable = !0, CKEDITOR.env.ie && (i.hideFocus = !0, i.disabled = !0, i.removeAttribute("disabled")), delete this._.isLoadingData, this.$ = i, n = new CKEDITOR.dom.document(n), this.setup(), this.fixInitialSelection();
        var o = this;
        CKEDITOR.env.ie && !CKEDITOR.env.edge && n.getDocumentElement().addClass(n.$.compatMode), CKEDITOR.env.ie && !CKEDITOR.env.edge && t.enterMode != CKEDITOR.ENTER_P ? r("p") : CKEDITOR.env.edge && CKEDITOR.env.version < 15 && t.enterMode != CKEDITOR.ENTER_DIV && r("div"), (CKEDITOR.env.webkit || CKEDITOR.env.ie && CKEDITOR.env.version > 10) && n.getDocumentElement().on("mousedown", function(e) {
                e.data.getTarget().is("html") && setTimeout(function() {
                    t.editable().focus()
                })
            }),
            function(e) {
                if (CKEDITOR.env.gecko) try {
                    var t = e.document.$;
                    t.execCommand("enableObjectResizing", !1, !e.config.disableObjectResizing), t.execCommand("enableInlineTableEditing", !1, !e.config.disableNativeTableHandles)
                } catch (e) {} else CKEDITOR.env.ie && CKEDITOR.env.version < 11 && e.config.disableObjectResizing && e.editable().attachListener(e, "selectionChange", function() {
                    var t = e.getSelection().getSelectedElement();
                    t && (n && (n.detachEvent("onresizestart", i), n = null), t.$.attachEvent("onresizestart", i), n = t.$)
                });
                var n;

                function i(e) {
                    e.returnValue = !1
                }
            }(t);
        try {
            t.document.$.execCommand("2D-position", !1, !0)
        } catch (e) {}(CKEDITOR.env.gecko || CKEDITOR.env.ie && "CSS1Compat" == t.document.$.compatMode) && this.attachListener(this, "keydown", function(e) {
            var n = e.data.getKeystroke();
            if (33 == n || 34 == n)
                if (CKEDITOR.env.ie) setTimeout(function() {
                    t.getSelection().scrollIntoView()
                }, 0);
                else if (t.window.$.innerHeight > this.$.offsetHeight) {
                var i = t.createRange();
                i[33 == n ? "moveToElementEditStart" : "moveToElementEditEnd"](this), i.select(), e.data.preventDefault()
            }
        }), CKEDITOR.env.ie && this.attachListener(n, "blur", function() {
            try {
                n.$.selection.empty()
            } catch (e) {}
        }), CKEDITOR.env.iOS && this.attachListener(n, "touchend", function() {
            e.focus()
        });
        var s = t.document.getElementsByTag("title").getItem(0);

        function r(e) {
            var t = !1;
            o.attachListener(o, "keydown", function() {
                var i = n.getBody().getElementsByTag(e);
                if (!t) {
                    for (var a = 0; a < i.count(); a++) i.getItem(a).setCustomData("retain", !0);
                    t = !0
                }
            }, null, null, 1), o.attachListener(o, "keyup", function() {
                var i = n.getElementsByTag(e);
                t && (1 == i.count() && !i.getItem(0).getCustomData("retain") && CKEDITOR.tools.isEmpty(i.getItem(0).getAttributes()) && i.getItem(0).remove(1), t = !1)
            })
        }
        s.data("cke-title", s.getText()), CKEDITOR.env.ie && (t.document.$.title = this._.docTitle), CKEDITOR.tools.setTimeout(function() {
            "unloaded" == this.status && (this.status = "ready"), t.fire("contentDom"), this._.isPendingFocus && (t.focus(), this._.isPendingFocus = !1), setTimeout(function() {
                t.fire("dataReady")
            }, 0)
        }, 0, this)
    }
    CKEDITOR.plugins.add("wysiwygarea", {
        init: function(t) {
            t.config.fullPage && t.addFeature({
                allowedContent: "html head title; style [media,type]; body (*)[id]; meta link [*]",
                requiredContent: "body"
            }), t.addMode("wysiwyg", function(n) {
                var i = "document.open();" + (CKEDITOR.env.ie ? "(" + CKEDITOR.tools.fixDomain + ")();" : "") + "document.close();";
                i = CKEDITOR.env.air ? "javascript:void(0)" : CKEDITOR.env.ie && !CKEDITOR.env.edge ? "javascript:void(function(){" + encodeURIComponent(i) + "}())" : "";
                var a = CKEDITOR.dom.element.createFromHtml('<iframe src="' + i + '" frameBorder="0"></iframe>');
                a.setStyles({
                    width: "100%",
                    height: "100%"
                }), a.addClass("cke_wysiwyg_frame").addClass("cke_reset");
                var o = t.ui.space("contents");
                o.append(a);
                var s = CKEDITOR.env.ie && !CKEDITOR.env.edge || CKEDITOR.env.gecko;
                s && a.on("load", m);
                var r = t.title,
                    d = t.fire("ariaEditorHelpLabel", {}).label;
                if (r && (CKEDITOR.env.ie && d && (r += ", " + d), a.setAttribute("title", r)), d) {
                    var c = CKEDITOR.tools.getNextId(),
                        l = CKEDITOR.dom.element.createFromHtml('<span id="' + c + '" class="cke_voice_label">' + d + "</span>");
                    o.append(l, 1), a.setAttribute("aria-describedby", c)
                }

                function m(i) {
                    i && i.removeListener(), t.editable(new e(t, a.$.contentWindow.document.body)), t.setData(t.getData(1), n)
                }
                t.on("beforeModeUnload", function(e) {
                    e.removeListener(), l && l.remove()
                }), a.setAttributes({
                    tabIndex: t.tabIndex,
                    allowTransparency: "true"
                }), !s && m(), t.fire("ariaWidget", a)
            })
        }
    }), CKEDITOR.editor.prototype.addContentsCss = function(e) {
        var t = this.config,
            n = t.contentsCss;
        CKEDITOR.tools.isArray(n) || (t.contentsCss = n ? [n] : []), t.contentsCss.push(e)
    }, e = CKEDITOR.tools.createClass({
        $: function() {
            this.base.apply(this, arguments), this._.frameLoadedHandler = CKEDITOR.tools.addFunction(function(e) {
                CKEDITOR.tools.setTimeout(t, 0, this, e)
            }, this), this._.docTitle = this.getWindow().getFrame().getAttribute("title")
        },
        base: CKEDITOR.editable,
        proto: {
            setData: function(e, t) {
                var n = this.editor;
                if (t) this.setHtml(e), this.fixInitialSelection(), n.fire("dataReady");
                else {
                    this._.isLoadingData = !0, n._.dataStore = {
                        id: 1
                    };
                    var i = n.config,
                        a = i.fullPage,
                        o = i.docType,
                        s = CKEDITOR.tools.buildStyleHtml(function() {
                            var e = [];
                            if (CKEDITOR.document.$.documentMode >= 8) {
                                e.push("html.CSS1Compat [contenteditable=false]{min-height:0 !important}");
                                var t = [];
                                for (var n in CKEDITOR.dtd.$removeEmpty) t.push("html.CSS1Compat " + n + "[contenteditable=false]");
                                e.push(t.join(",") + "{display:inline-block}")
                            } else CKEDITOR.env.gecko && (e.push("html{height:100% !important}"), e.push("img:-moz-broken{-moz-force-broken-image-icon:1;min-width:24px;min-height:24px}"));
                            return e.push("html{cursor:text;*cursor:auto}"), e.push("img,input,textarea{cursor:default}"), e.join("\n")
                        }()).replace(/<style>/, '<style data-cke-temp="1">');
                    a || (s += CKEDITOR.tools.buildStyleHtml(n.config.contentsCss));
                    var r = i.baseHref ? '<base href="' + i.baseHref + '" data-cke-temp="1" />' : "";
                    a && (e = e.replace(/<!DOCTYPE[^>]*>/i, function(e) {
                        return n.docType = o = e, ""
                    }).replace(/<\?xml\s[^\?]*\?>/i, function(e) {
                        return n.xmlDeclaration = e, ""
                    })), e = n.dataProcessor.toHtml(e), a ? (/<body[\s|>]/.test(e) || (e = "<body>" + e), /<html[\s|>]/.test(e) || (e = "<html>" + e + "</html>"), /<head[\s|>]/.test(e) ? /<title[\s|>]/.test(e) || (e = e.replace(/<head[^>]*>/, "$&<title></title>")) : e = e.replace(/<html[^>]*>/, "$&<head><title></title></head>"), r && (e = e.replace(/<head[^>]*?>/, "$&" + r)), e = e.replace(/<\/head\s*>/, s + "$&"), e = o + e) : e = i.docType + '<html dir="' + i.contentsLangDirection + '" lang="' + (i.contentsLanguage || n.langCode) + '"><head><title>' + this._.docTitle + "</title>" + r + s + "</head><body" + (i.bodyId ? ' id="' + i.bodyId + '"' : "") + (i.bodyClass ? ' class="' + i.bodyClass + '"' : "") + ">" + e + "</body></html>", CKEDITOR.env.gecko && (e = e.replace(/<body/, '<body contenteditable="true" '), CKEDITOR.env.version < 2e4 && (e = e.replace(/<body[^>]*>/, "$&\x3c!-- cke-content-start --\x3e")));
                    var d = '<script id="cke_actscrpt" type="text/javascript"' + (CKEDITOR.env.ie ? ' defer="defer" ' : "") + ">var wasLoaded=0;function onload(){if(!wasLoaded)window.parent.CKEDITOR.tools.callFunction(" + this._.frameLoadedHandler + ",window);wasLoaded=1;}" + (CKEDITOR.env.ie ? "onload();" : 'document.addEventListener("DOMContentLoaded", onload, false );') + "<\/script>";
                    CKEDITOR.env.ie && CKEDITOR.env.version < 9 && (d += '<script id="cke_shimscrpt">window.parent.CKEDITOR.tools.enableHtml5Elements(document)<\/script>'), r && CKEDITOR.env.ie && CKEDITOR.env.version < 10 && (d += '<script id="cke_basetagscrpt">var baseTag = document.querySelector( "base" );baseTag.href = baseTag.href;<\/script>'), e = e.replace(/(?=\s*<\/(:?head)>)/, d), this.clearCustomData(), this.clearListeners(), n.fire("contentDomUnload");
                    var c = this.getDocument();
                    try {
                        c.write(e)
                    } catch (t) {
                        setTimeout(function() {
                            c.write(e)
                        }, 0)
                    }
                }
            },
            getData: function(e) {
                if (e) return this.getHtml();
                var t = this.editor,
                    n = t.config,
                    i = n.fullPage,
                    a = i && t.docType,
                    o = i && t.xmlDeclaration,
                    s = this.getDocument(),
                    r = i ? s.getDocumentElement().getOuterHtml() : s.getBody().getHtml();
                return CKEDITOR.env.gecko && n.enterMode != CKEDITOR.ENTER_BR && (r = r.replace(/<br>(?=\s*(:?$|<\/body>))/, "")), r = t.dataProcessor.toDataFormat(r), o && (r = o + "\n" + r), a && (r = a + "\n" + r), r
            },
            focus: function() {
                this._.isLoadingData ? this._.isPendingFocus = !0 : e.baseProto.focus.call(this)
            },
            detach: function() {
                var t, n, i = this.editor,
                    a = i.document;
                try {
                    t = i.window.getFrame()
                } catch (e) {}
                e.baseProto.detach.call(this), this.clearCustomData(), a.getDocumentElement().clearCustomData(), CKEDITOR.tools.removeFunction(this._.frameLoadedHandler), t && t.getParent() ? (t.clearCustomData(), (n = t.removeCustomData("onResize")) && n.removeListener(), t.remove()) : CKEDITOR.warn("editor-destroy-iframe")
            }
        }
    })
}(), CKEDITOR.config.disableObjectResizing = !1, CKEDITOR.config.disableNativeTableHandles = !0, CKEDITOR.config.disableNativeSpellChecker = !0;