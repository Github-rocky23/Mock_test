CKEDITOR.plugins.setLang("newpage", "en", {
    toolbar: "Clear Response"
});