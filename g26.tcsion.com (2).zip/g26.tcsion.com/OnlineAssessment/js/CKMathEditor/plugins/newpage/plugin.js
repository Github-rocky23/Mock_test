CKEDITOR.plugins.add("newpage", {
    lang: "af,ar,az,bg,bn,bs,ca,cs,cy,da,de,de-ch,el,en,en-au,en-ca,en-gb,eo,es,es-mx,et,eu,fa,fi,fo,fr,fr-ca,gl,gu,he,hi,hr,hu,id,is,it,ja,ka,km,ko,ku,lt,lv,mk,mn,ms,nb,nl,no,oc,pl,pt,pt-br,ro,ru,si,sk,sl,sq,sr,sr-latn,sv,th,tr,tt,ug,uk,vi,zh,zh-cn",
    icons: "newpage,newpage-rtl",
    hidpi: !0,
    init: function(e) {
        e.addCommand("newpage", {
            modes: {
                wysiwyg: 1,
                source: 1
            },
            exec: function(e) {
                var n = this;
                e.setData(e.config.newpage_html || "", function() {
                    e.focus(), setTimeout(function() {
                        e.fire("afterCommandExec", {
                            name: "newpage",
                            command: n
                        }), e.selectionChange()
                    }, 200)
                })
            },
            async: !0
        }), e.ui.addButton && e.ui.addButton("NewPage", {
            label: e.lang.newpage.toolbar,
            command: "newpage",
            toolbar: "document,20"
        })
    }
});