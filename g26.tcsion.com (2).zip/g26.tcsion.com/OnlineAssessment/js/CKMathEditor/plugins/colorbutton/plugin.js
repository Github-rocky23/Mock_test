CKEDITOR.plugins.add("colorbutton", {
    requires: "panelbutton,floatpanel",
    lang: "af,ar,az,bg,bn,bs,ca,cs,cy,da,de,de-ch,el,en,en-au,en-ca,en-gb,eo,es,es-mx,et,eu,fa,fi,fo,fr,fr-ca,gl,gu,he,hi,hr,hu,id,is,it,ja,ka,km,ko,ku,lt,lv,mk,mn,ms,nb,nl,no,oc,pl,pt,pt-br,ro,ru,si,sk,sl,sq,sr,sr-latn,sv,th,tr,tt,ug,uk,vi,zh,zh-cn",
    icons: "bgcolor,textcolor",
    hidpi: !0,
    init: function(t) {
        var e = t.config,
            o = t.lang.colorbutton;
        if (!CKEDITOR.env.hc) {
            l("TextColor", "fore", o.textColorTitle, 10, {
                contentTransformations: [
                    [{
                        element: "font",
                        check: "span{color}",
                        left: function(t) {
                            return !!t.attributes.color
                        },
                        right: function(t) {
                            t.name = "span", t.attributes.color && (t.styles.color = t.attributes.color), delete t.attributes.color
                        }
                    }]
                ]
            });
            var r = {},
                n = t.config.colorButton_normalizeBackground;
            (void 0 === n || n) && (r.contentTransformations = [
                [{
                    element: "span",
                    left: function(t) {
                        var e = CKEDITOR.tools;
                        if ("span" != t.name || !t.styles || !t.styles.background) return !1;
                        var o = e.style.parse.background(t.styles.background);
                        return o.color && 1 === e.objectKeys(o).length
                    },
                    right: function(e) {
                        var o = new CKEDITOR.style(t.config.colorButton_backStyle, {
                            color: e.styles.background
                        }).getDefinition();
                        return e.name = o.element, e.styles = o.styles, e.attributes = o.attributes || {}, e
                    }
                }]
            ]), l("BGColor", "back", o.bgColorTitle, 20, r)
        }

        function l(r, n, l, s, i) {
            var u, f = new CKEDITOR.style(e["colorButton_" + n + "Style"]),
                d = CKEDITOR.tools.getNextId() + "_colorBox";
            i = i || {}, t.ui.add(r, CKEDITOR.UI_PANELBUTTON, {
                label: l,
                title: l,
                modes: {
                    wysiwyg: 1
                },
                editorFocus: 0,
                toolbar: "colors," + s,
                allowedContent: f,
                requiredContent: f,
                contentTransformations: i.contentTransformations,
                panel: {
                    css: CKEDITOR.skin.getPath("editor"),
                    attributes: {
                        role: "listbox",
                        "aria-label": o.panelTitle
                    }
                },
                onBlock: function(r, l) {
                    u = l, l.autoSize = !0, l.element.addClass("cke_colorblock"), l.element.setHtml(function(r, n, l) {
                        var c = [],
                            s = e.colorButton_colors.split(","),
                            i = e.colorButton_colorsPerRow || 6,
                            u = t.plugins.colordialog && !1 !== e.colorButton_enableMore,
                            f = s.length + (u ? 2 : 1),
                            d = CKEDITOR.tools.addFunction(function(o, r) {
                                if (t.focus(), t.fire("saveSnapshot"), "?" != o) return n(o);

                                function n(o) {
                                    var n = e["colorButton_" + r + "Style"];
                                    t.removeStyle(new CKEDITOR.style(n, {
                                        color: "inherit"
                                    })), n.childRule = "back" == r ? function(t) {
                                        return a(t)
                                    } : function(t) {
                                        return !(t.is("a") || t.getElementsByTag("a").count()) || a(t)
                                    }, t.focus(), o && t.applyStyle(new CKEDITOR.style(n, {
                                        color: o
                                    })), t.fire("saveSnapshot")
                                }
                                t.getColorFromDialog(function(t) {
                                    if (t) return n(t)
                                })
                            });
                        !1 !== e.colorButton_enableAutomatic && c.push('<a class="cke_colorauto" _cke_focus=1 hidefocus=true title="', o.auto, '" draggable="false" ondragstart="return false;" onclick="CKEDITOR.tools.callFunction(', d, ",null,'", n, "');return false;\" href=\"javascript:void('", o.auto, '\')" role="option" aria-posinset="1" aria-setsize="', f, '"><table role="presentation" cellspacing=0 cellpadding=0 width="100%"><tr><td colspan="' + i + '" align="center"><span class="cke_colorbox" id="', l, '"></span>', o.auto, "</td></tr></table></a>");
                        c.push('<table role="presentation" cellspacing=0 cellpadding=0 width="100%">');
                        for (var g = 0; g < s.length; g++) {
                            g % i == 0 && c.push("</tr><tr>");
                            var b, p = s[g].split("/"),
                                C = p[0],
                                m = p[1] || C;
                            p[1] ? b = C : (C = "#" + C.replace(/^(.)(.)(.)$/, "$1$1$2$2$3$3"), b = t.lang.colorbutton.colors[m] || m), c.push('<td><a class="cke_colorbox" _cke_focus=1 hidefocus=true title="', b, '" draggable="false" ondragstart="return false;" onclick="CKEDITOR.tools.callFunction(', d, ",'", C, "','", n, "'); return false;\" href=\"javascript:void('", b, '\')" data-value="' + m + '" role="option" aria-posinset="', g + 2, '" aria-setsize="', f, '"><span class="cke_colorbox" style="background-color:#', m, '"></span></a></td>')
                        }
                        u && c.push('</tr><tr><td colspan="' + i + '" align="center"><a class="cke_colormore" _cke_focus=1 hidefocus=true title="', o.more, '" draggable="false" ondragstart="return false;" onclick="CKEDITOR.tools.callFunction(', d, ",'?','", n, "');return false;\" href=\"javascript:void('", o.more, "')\"", ' role="option" aria-posinset="', f, '" aria-setsize="', f, '">', o.more, "</a></td>");
                        return c.push("</tr></table>"), c.join("")
                    }(0, n, d)), l.element.getDocument().getBody().setStyle("overflow", "hidden"), CKEDITOR.ui.fire("ready", this);
                    var c = l.keys,
                        s = "rtl" == t.lang.dir;
                    c[s ? 37 : 39] = "next", c[40] = "next", c[9] = "next", c[s ? 39 : 37] = "prev", c[38] = "prev", c[CKEDITOR.SHIFT + 9] = "prev", c[32] = "click"
                },
                refresh: function() {
                    t.activeFilter.check(f) || this.setState(CKEDITOR.TRISTATE_DISABLED)
                },
                onOpen: function() {
                    var o, r = t.getSelection(),
                        l = r && r.getStartElement(),
                        a = t.elementPath(l);
                    if (a) {
                        l = a.block || a.blockLimit || t.document.getBody();
                        do {
                            o = l && l.getComputedStyle("back" == n ? "background-color" : "color") || "transparent"
                        } while ("back" == n && "transparent" == o && l && (l = l.getParent()));
                        o && "transparent" != o || (o = "#ffffff"), !1 !== e.colorButton_enableAutomatic && this._.panel._.iframe.getFrameDocument().getById(d).setStyle("background-color", o);
                        var s = r && r.getRanges()[0];
                        if (s) {
                            for (var i, f = new CKEDITOR.dom.walker(s), g = s.collapsed ? s.startContainer : f.next(), b = ""; g;) {
                                if (g.type !== CKEDITOR.NODE_ELEMENT && (g = g.getParent()), i = c(g.getComputedStyle("back" == n ? "background-color" : "color")), (b = b || i) !== i) {
                                    b = "";
                                    break
                                }
                                g = f.next()
                            }! function(t, e) {
                                for (var o = t._.getItems(), r = 0; r < o.count(); r++) {
                                    var n = o.getItem(r);
                                    n.removeAttribute("aria-selected"), e && e == c(n.getAttribute("data-value")) && n.setAttribute("aria-selected", !0)
                                }
                            }(u, b)
                        }
                        return o
                    }
                }
            })
        }

        function a(t) {
            return "false" == t.getAttribute("contentEditable") || t.getAttribute("data-nostyle")
        }

        function c(t) {
            return CKEDITOR.tools.normalizeHex("#" + CKEDITOR.tools.convertRgbToHex(t || "")).replace(/#/g, "")
        }
    }
}), CKEDITOR.config.colorButton_colors = "1ABC9C,2ECC71,3498DB,9B59B6,4E5F70,F1C40F,16A085,27AE60,2980B9,8E44AD,2C3E50,F39C12,E67E22,E74C3C,ECF0F1,95A5A6,DDD,FFF,D35400,C0392B,BDC3C7,7F8C8D,999,000", CKEDITOR.config.colorButton_foreStyle = {
    element: "span",
    styles: {
        color: "#(color)"
    },
    overrides: [{
        element: "font",
        attributes: {
            color: null
        }
    }]
}, CKEDITOR.config.colorButton_backStyle = {
    element: "span",
    styles: {
        "background-color": "#(color)"
    }
};