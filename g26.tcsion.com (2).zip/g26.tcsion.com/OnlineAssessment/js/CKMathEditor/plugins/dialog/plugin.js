CKEDITOR.DIALOG_RESIZE_NONE = 0, CKEDITOR.DIALOG_RESIZE_WIDTH = 1, CKEDITOR.DIALOG_RESIZE_HEIGHT = 2, CKEDITOR.DIALOG_RESIZE_BOTH = 3, CKEDITOR.DIALOG_STATE_IDLE = 1, CKEDITOR.DIALOG_STATE_BUSY = 2,
    function() {
        var t = CKEDITOR.tools.cssLength;

        function e(t) {
            return !!this._.tabs[t][0].$.offsetHeight
        }

        function i() {
            for (var t = this._.currentTabId, i = this._.tabIdList.length, n = CKEDITOR.tools.indexOf(this._.tabIdList, t) + i, o = n - 1; o > n - i; o--)
                if (e.call(this, this._.tabIdList[o % i])) return this._.tabIdList[o % i];
            return null
        }

        function n(t, e) {
            for (var i = t.$.getElementsByTagName("input"), n = 0, o = i.length; n < o; n++) {
                var s = new CKEDITOR.dom.element(i[n]);
                "text" == s.getAttribute("type").toLowerCase() && (e ? (s.setAttribute("value", s.getCustomData("fake_value") || ""), s.removeCustomData("fake_value")) : (s.setCustomData("fake_value", s.getAttribute("value")), s.setAttribute("value", "")))
            }
        }
        var o, s, a = '<div class="cke_reset_all {editorId} {editorDialogClass} {hidpi}" dir="{langDir}" lang="{langCode}" role="dialog" aria-labelledby="cke_dialog_title_{id}"><table class="cke_dialog ' + CKEDITOR.env.cssClass + ' cke_{langDir}" style="position:absolute" role="presentation"><tr><td role="presentation"><div class="cke_dialog_body" role="presentation"><div id="cke_dialog_title_{id}" class="cke_dialog_title" role="presentation"></div><a id="cke_dialog_close_button_{id}" class="cke_dialog_close_button" href="javascript:void(0)" title="{closeTitle}" role="button"><span class="cke_label">X</span></a><div id="cke_dialog_tabs_{id}" class="cke_dialog_tabs" role="tablist"></div><table class="cke_dialog_contents" role="presentation"><tr><td id="cke_dialog_contents_{id}" class="cke_dialog_contents_body" role="presentation"></td></tr><tr><td id="cke_dialog_footer_{id}" class="cke_dialog_footer" role="presentation"></td></tr></table></div></td></tr></table></div>';

        function r(t, e, i) {
            this.element = e, this.focusIndex = i, this.tabIndex = 0, this.isFocusable = function() {
                return !e.getAttribute("disabled") && e.isVisible()
            }, this.focus = function() {
                t._.currentFocusIndex = this.focusIndex, this.element.focus()
            }, e.on("keydown", function(t) {
                t.data.getKeystroke() in {
                    32: 1,
                    13: 1
                } && this.fire("click")
            }), e.on("focus", function() {
                this.fire("mouseover")
            }), e.on("blur", function() {
                this.fire("mouseout")
            })
        }
        CKEDITOR.dialog = function(t, n) {
            var o, s, r, l = CKEDITOR.dialog._.dialogDefinitions[n],
                u = CKEDITOR.tools.clone(d),
                c = t.config.dialog_buttonsOrder || "OS",
                h = t.lang.dir,
                f = {};
            ("OS" == c && CKEDITOR.env.mac || "rtl" == c && "ltr" == h || "ltr" == c && "rtl" == h) && u.buttons.reverse(), l = CKEDITOR.tools.extend(l(t), u), l = CKEDITOR.tools.clone(l), l = new g(this, l);
            var _ = function(t) {
                var e = CKEDITOR.dom.element.createFromHtml(CKEDITOR.addTemplate("dialog", a).output({
                        id: CKEDITOR.tools.getNextNumber(),
                        editorId: t.id,
                        langDir: t.lang.dir,
                        langCode: t.langCode,
                        editorDialogClass: "cke_editor_" + t.name.replace(/\./g, "\\.") + "_dialog",
                        closeTitle: t.lang.common.close,
                        hidpi: CKEDITOR.env.hidpi ? "cke_hidpi" : ""
                    })),
                    i = e.getChild([0, 0, 0, 0, 0]),
                    n = i.getChild(0),
                    o = i.getChild(1);
                if (t.plugins.clipboard && CKEDITOR.plugins.clipboard.preventDefaultDropOnElement(i), CKEDITOR.env.ie && !CKEDITOR.env.quirks && !CKEDITOR.env.edge) {
                    var s = "javascript:void(function(){" + encodeURIComponent("document.open();(" + CKEDITOR.tools.fixDomain + ")();document.close();") + "}())";
                    CKEDITOR.dom.element.createFromHtml('<iframe frameBorder="0" class="cke_iframe_shim" src="' + s + '" tabIndex="-1"></iframe>').appendTo(i.getParent())
                }
                return n.unselectable(), o.unselectable(), {
                    element: e,
                    parts: {
                        dialog: e.getChild(0),
                        title: n,
                        close: o,
                        tabs: i.getChild(2),
                        contents: i.getChild([3, 0, 0, 0]),
                        footer: i.getChild([3, 0, 1, 0])
                    }
                }
            }(t);
            this._ = {
                editor: t,
                element: _.element,
                name: n,
                contentSize: {
                    width: 0,
                    height: 0
                },
                size: {
                    width: 0,
                    height: 0
                },
                contents: {},
                buttons: {},
                accessKeyMap: {},
                tabs: {},
                tabIdList: [],
                currentTabId: null,
                currentTabIndex: null,
                pageCount: 0,
                lastTab: null,
                tabBarMode: !1,
                focusList: [],
                currentFocusIndex: 0,
                hasFocus: !1
            }, this.parts = _.parts, CKEDITOR.tools.setTimeout(function() {
                t.fire("ariaWidget", this.parts.contents)
            }, 0, this);
            var I = {
                position: CKEDITOR.env.ie6Compat ? "absolute" : "fixed",
                top: 0,
                visibility: "hidden"
            };
            if (I["rtl" == h ? "right" : "left"] = 0, this.parts.dialog.setStyles(I), CKEDITOR.event.call(this), this.definition = l = CKEDITOR.fire("dialogDefinition", {
                    name: n,
                    definition: l
                }, t).definition, !("removeDialogTabs" in t._) && t.config.removeDialogTabs) {
                var m = t.config.removeDialogTabs.split(";");
                for (o = 0; o < m.length; o++) {
                    var v = m[o].split(":");
                    if (2 == v.length) {
                        var C = v[0];
                        f[C] || (f[C] = []), f[C].push(v[1])
                    }
                }
                t._.removeDialogTabs = f
            }
            if (t._.removeDialogTabs && (f = t._.removeDialogTabs[n]))
                for (o = 0; o < f.length; o++) l.removeContents(f[o]);
            l.onLoad && this.on("load", l.onLoad), l.onShow && this.on("show", l.onShow), l.onHide && this.on("hide", l.onHide), l.onOk && this.on("ok", function(e) {
                t.fire("saveSnapshot"), setTimeout(function() {
                    t.fire("saveSnapshot")
                }, 0), !1 === l.onOk.call(this, e) && (e.data.hide = !1)
            }), this.state = CKEDITOR.DIALOG_STATE_IDLE, l.onCancel && this.on("cancel", function(t) {
                !1 === l.onCancel.call(this, t) && (t.data.hide = !1)
            });
            var E = this,
                T = function(t) {
                    var e = E._.contents;
                    for (var i in e)
                        for (var n in e[i])
                            if (t.call(this, e[i][n])) return
                };

            function D(t) {
                var e = E._.focusList;
                if (t = t || 0, !(e.length < 1)) {
                    var i = E._.currentFocusIndex;
                    E._.tabBarMode && t < 0 && (i = 0);
                    try {
                        e[i].getInputElement().$.blur()
                    } catch (t) {}
                    var n = i,
                        o = E._.pageCount > 1;
                    do {
                        if (n += t, o && !E._.tabBarMode && (n == e.length || -1 == n)) return E._.tabBarMode = !0, E._.tabs[E._.currentTabId][0].focus(), void(E._.currentFocusIndex = -1);
                        if ((n = (n + e.length) % e.length) == i) break
                    } while (t && !e[n].isFocusable());
                    e[n].focus(), "text" == e[n].type && e[n].select()
                }
            }

            function b(n) {
                if (E == CKEDITOR.dialog._.currentTop) {
                    var o, a = n.data.getKeystroke(),
                        l = "rtl" == t.lang.dir;
                    if (s = r = 0, 9 == a || a == CKEDITOR.SHIFT + 9) D(a == CKEDITOR.SHIFT + 9 ? -1 : 1), s = 1;
                    else if (a == CKEDITOR.ALT + 121 && !E._.tabBarMode && E.getPageCount() > 1) E._.tabBarMode = !0, E._.tabs[E._.currentTabId][0].focus(), E._.currentFocusIndex = -1, s = 1;
                    else if (-1 != CKEDITOR.tools.indexOf([37, 38, 39, 40], a) && E._.tabBarMode) {
                        var d = [l ? 39 : 37, 38],
                            u = -1 != CKEDITOR.tools.indexOf(d, a) ? i.call(E) : function() {
                                for (var t = this._.currentTabId, i = this._.tabIdList.length, n = CKEDITOR.tools.indexOf(this._.tabIdList, t), o = n + 1; o < n + i; o++)
                                    if (e.call(this, this._.tabIdList[o % i])) return this._.tabIdList[o % i];
                                return null
                            }.call(E);
                        E.selectPage(u), E._.tabs[u][0].focus(), s = 1
                    } else if (13 != a && 32 != a || !E._.tabBarMode)
                        if (13 == a) {
                            var c = n.data.getTarget();
                            c.is("a", "button", "select", "textarea") || c.is("input") && "button" == c.$.type || ((o = this.getButton("ok")) && CKEDITOR.tools.setTimeout(o.click, 0, o), s = 1), r = 1
                        } else {
                            if (27 != a) return;
                            (o = this.getButton("cancel")) ? CKEDITOR.tools.setTimeout(o.click, 0, o): !1 !== this.fire("cancel", {
                                hide: !0
                            }).hide && this.hide(), r = 1
                        }
                    else this.selectPage(this._.currentTabId), this._.tabBarMode = !1, this._.currentFocusIndex = -1, D(1), s = 1;
                    O(n)
                }
            }

            function O(t) {
                s ? t.data.preventDefault(1) : r && t.data.stopPropagation()
            }
            this.on("ok", function(t) {
                T(function(e) {
                    if (e.validate) {
                        var i = e.validate(this),
                            n = "string" == typeof i || !1 === i;
                        return n && (t.data.hide = !1, t.stop()),
                            function(t, e) {
                                var i = this.getInputElement();
                                i && (t ? i.removeAttribute("aria-invalid") : i.setAttribute("aria-invalid", !0)), t || (this.select ? this.select() : this.focus()), e && alert(e), this.fire("validated", {
                                    valid: t,
                                    msg: e
                                })
                            }.call(e, !n, "string" == typeof i ? i : void 0), n
                    }
                })
            }, this, null, 0), this.on("cancel", function(e) {
                T(function(i) {
                    if (i.isChanged()) return t.config.dialog_noConfirmCancel || confirm(t.lang.common.confirmCancel) || (e.data.hide = !1), !0
                })
            }, this, null, 0), this.parts.close.on("click", function(t) {
                !1 !== this.fire("cancel", {
                    hide: !0
                }).hide && this.hide(), t.data.preventDefault()
            }, this), this.changeFocus = D;
            var K = this._.element;
            for (t.focusManager.add(K, 1), this.on("show", function() {
                    K.on("keydown", b, this), CKEDITOR.env.gecko && K.on("keypress", O, this)
                }), this.on("hide", function() {
                    K.removeListener("keydown", b), CKEDITOR.env.gecko && K.removeListener("keypress", O), T(function(t) {
                        (function() {
                            var t = this.getInputElement();
                            t && t.removeAttribute("aria-invalid")
                        }).apply(t)
                    })
                }), this.on("iframeAdded", function(t) {
                    new CKEDITOR.dom.document(t.data.iframe.$.contentWindow.document).on("keydown", b, this, null, 0)
                }), this.on("show", function() {
                    ! function() {
                        var t = E._.focusList;
                        t.sort(function(t, e) {
                            return t.tabIndex != e.tabIndex ? e.tabIndex - t.tabIndex : t.focusIndex - e.focusIndex
                        });
                        for (var e = t.length, i = 0; i < e; i++) t[i].focusIndex = i
                    }();
                    var e = E._.pageCount > 1;
                    if (t.config.dialog_startupFocusTab && e) E._.tabBarMode = !0, E._.tabs[E._.currentTabId][0].focus(), E._.currentFocusIndex = -1;
                    else if (!this._.hasFocus)
                        if (this._.currentFocusIndex = e ? -1 : this._.focusList.length - 1, l.onFocus) {
                            var i = l.onFocus.call(this);
                            i && i.focus()
                        } else D(1)
                }, this, null, 4294967295), CKEDITOR.env.ie6Compat && this.on("load", function() {
                    var t = this.getElement(),
                        e = t.getFirst();
                    e.remove(), e.appendTo(t)
                }, this), function(t) {
                    var e = null,
                        i = null,
                        n = t.getParentEditor(),
                        o = n.config.dialog_magnetDistance,
                        s = CKEDITOR.skin.margins || [0, 0, 0, 0];
                    void 0 === o && (o = 20);

                    function a(a) {
                        var r, l, d = t.getSize(),
                            u = CKEDITOR.document.getWindow().getViewPaneSize(),
                            c = a.data.$.screenX,
                            h = a.data.$.screenY,
                            g = c - e.x,
                            f = h - e.y;
                        e = {
                            x: c,
                            y: h
                        }, i.x += g, i.y += f, r = i.x + s[3] < o ? -s[3] : i.x - s[1] > u.width - d.width - o ? u.width - d.width + ("rtl" == n.lang.dir ? 0 : s[1]) : i.x, l = i.y + s[0] < o ? -s[0] : i.y - s[2] > u.height - d.height - o ? u.height - d.height + s[2] : i.y, t.move(r, l, 1), a.data.preventDefault()
                    }

                    function r() {
                        if (CKEDITOR.document.removeListener("mousemove", a), CKEDITOR.document.removeListener("mouseup", r), CKEDITOR.env.ie6Compat) {
                            var t = p.getChild(0).getFrameDocument();
                            t.removeListener("mousemove", a), t.removeListener("mouseup", r)
                        }
                    }
                    t.parts.title.on("mousedown", function(n) {
                        if (e = {
                                x: n.data.$.screenX,
                                y: n.data.$.screenY
                            }, CKEDITOR.document.on("mousemove", a), CKEDITOR.document.on("mouseup", r), i = t.getPosition(), CKEDITOR.env.ie6Compat) {
                            var o = p.getChild(0).getFrameDocument();
                            o.on("mousemove", a), o.on("mouseup", r)
                        }
                        n.data.preventDefault()
                    }, t)
                }(this), function(t) {
                    var e = t.definition,
                        i = e.resizable;
                    if (i == CKEDITOR.DIALOG_RESIZE_NONE) return;
                    var n, o, s, a, r, l, d = t.getParentEditor(),
                        u = CKEDITOR.tools.addFunction(function(e) {
                            r = t.getSize();
                            var i = t.parts.contents,
                                d = i.$.getElementsByTagName("iframe").length;
                            if (d && (l = CKEDITOR.dom.element.createFromHtml('<div class="cke_dialog_resize_cover" style="height: 100%; position: absolute; width: 100%;"></div>'), i.append(l)), o = r.height - t.parts.contents.getSize("height", !(CKEDITOR.env.gecko || CKEDITOR.env.ie && CKEDITOR.env.quirks)), n = r.width - t.parts.contents.getSize("width", 1), a = {
                                    x: e.screenX,
                                    y: e.screenY
                                }, s = CKEDITOR.document.getWindow().getViewPaneSize(), CKEDITOR.document.on("mousemove", c), CKEDITOR.document.on("mouseup", h), CKEDITOR.env.ie6Compat) {
                                var u = p.getChild(0).getFrameDocument();
                                u.on("mousemove", c), u.on("mouseup", h)
                            }
                            e.preventDefault && e.preventDefault()
                        });

                    function c(l) {
                        var u = "rtl" == d.lang.dir,
                            c = (l.data.$.screenX - a.x) * (u ? -1 : 1),
                            h = l.data.$.screenY - a.y,
                            g = r.width,
                            f = r.height,
                            p = g + c * (t._.moved ? 1 : 2),
                            _ = f + h * (t._.moved ? 1 : 2),
                            I = t._.element.getFirst(),
                            m = u && I.getComputedStyle("right"),
                            v = t.getPosition();
                        v.y + _ > s.height && (_ = s.height - v.y), (u ? m : v.x) + p > s.width && (p = s.width - (u ? m : v.x)), i != CKEDITOR.DIALOG_RESIZE_WIDTH && i != CKEDITOR.DIALOG_RESIZE_BOTH || (g = Math.max(e.minWidth || 0, p - n)), i != CKEDITOR.DIALOG_RESIZE_HEIGHT && i != CKEDITOR.DIALOG_RESIZE_BOTH || (f = Math.max(e.minHeight || 0, _ - o)), t.resize(g, f), t._.moved || t.layout(), l.data.preventDefault()
                    }

                    function h() {
                        if (CKEDITOR.document.removeListener("mouseup", h), CKEDITOR.document.removeListener("mousemove", c), l && (l.remove(), l = null), CKEDITOR.env.ie6Compat) {
                            var t = p.getChild(0).getFrameDocument();
                            t.removeListener("mouseup", h), t.removeListener("mousemove", c)
                        }
                    }
                    t.on("load", function() {
                        var e = "";
                        i == CKEDITOR.DIALOG_RESIZE_WIDTH ? e = " cke_resizer_horizontal" : i == CKEDITOR.DIALOG_RESIZE_HEIGHT && (e = " cke_resizer_vertical");
                        var n = CKEDITOR.dom.element.createFromHtml('<div class="cke_resizer' + e + " cke_resizer_" + d.lang.dir + '" title="' + CKEDITOR.tools.htmlEncode(d.lang.common.resize) + '" onmousedown="CKEDITOR.tools.callFunction(' + u + ', event )">' + ("ltr" == d.lang.dir ? "◢" : "◣") + "</div>");
                        t.parts.footer.append(n, 1)
                    }), d.on("destroy", function() {
                        CKEDITOR.tools.removeFunction(u)
                    })
                }(this), new CKEDITOR.dom.text(null == l.title ? "Select Special Charecter" : l.title, CKEDITOR.document).appendTo(this.parts.title), o = 0; o < l.contents.length; o++) {
                var R = l.contents[o];
                R && this.addPage(R)
            }
            this.parts.tabs.on("click", function(t) {
                var e = t.data.getTarget();
                if (e.hasClass("cke_dialog_tab")) {
                    var i = e.$.id;
                    this.selectPage(i.substring(4, i.lastIndexOf("_"))), this._.tabBarMode && (this._.tabBarMode = !1, this._.currentFocusIndex = -1, D(1)), t.data.preventDefault()
                }
            }, this);
            var y = [],
                x = CKEDITOR.dialog._.uiElementBuilders.hbox.build(this, {
                    type: "hbox",
                    className: "cke_dialog_footer_buttons",
                    widths: [],
                    children: l.buttons
                }, y).getChild();
            for (this.parts.footer.setHtml(y.join("")), o = 0; o < x.length; o++) this._.buttons[x[o].id] = x[o]
        }, CKEDITOR.dialog.prototype = {
            destroy: function() {
                this.hide(), this._.element.remove()
            },
            resize: function(t, e) {
                this._.contentSize && this._.contentSize.width == t && this._.contentSize.height == e || (CKEDITOR.dialog.fire("resize", {
                    dialog: this,
                    width: t,
                    height: e
                }, this._.editor), this.fire("resize", {
                    width: t,
                    height: e
                }, this._.editor), this.parts.contents.setStyles({
                    width: t + "px",
                    height: e + "px"
                }), "rtl" == this._.editor.lang.dir && this._.position && (this._.position.x = CKEDITOR.document.getWindow().getViewPaneSize().width - this._.contentSize.width - parseInt(this._.element.getFirst().getStyle("right"), 10)), this._.contentSize = {
                    width: t,
                    height: e
                })
            },
            getSize: function() {
                var t = this._.element.getFirst();
                return {
                    width: t.$.offsetWidth || 0,
                    height: t.$.offsetHeight || 0
                }
            },
            move: function(t, e, i) {
                var n = this._.element.getFirst(),
                    o = "rtl" == this._.editor.lang.dir,
                    s = "fixed" == n.getComputedStyle("position");
                if (CKEDITOR.env.ie && n.setStyle("zoom", "100%"), !s || !this._.position || this._.position.x != t || this._.position.y != e) {
                    if (this._.position = {
                            x: t,
                            y: e
                        }, !s) {
                        var a = CKEDITOR.document.getWindow().getScrollPosition();
                        t += a.x, e += a.y
                    }
                    if (o) {
                        var r = this.getSize();
                        t = CKEDITOR.document.getWindow().getViewPaneSize().width - r.width - t
                    }
                    var l = {
                        top: (e > 0 ? e : 0) + "px"
                    };
                    l[o ? "right" : "left"] = (t > 0 ? t : 0) + "px", n.setStyles(l), i && (this._.moved = 1)
                }
            },
            getPosition: function() {
                return CKEDITOR.tools.extend({}, this._.position)
            },
            show: function() {
                var t = this._.element,
                    e = this.definition;
                (t.getParent() && t.getParent().equals(CKEDITOR.document.getBody()) ? t.setStyle("display", "block") : t.appendTo(CKEDITOR.document.getBody()), this.resize(this._.contentSize && this._.contentSize.width || e.width || e.minWidth, this._.contentSize && this._.contentSize.height || e.height || e.minHeight), this.reset(), null === this._.currentTabId && this.selectPage(this.definition.contents[0].id), null === CKEDITOR.dialog._.currentZIndex && (CKEDITOR.dialog._.currentZIndex = this._.editor.config.baseFloatZIndex), this._.element.getFirst().setStyle("z-index", CKEDITOR.dialog._.currentZIndex += 10), null === CKEDITOR.dialog._.currentTop) ? (CKEDITOR.dialog._.currentTop = this, this._.parentDialog = null, m(this._.editor)) : (this._.parentDialog = CKEDITOR.dialog._.currentTop, this._.parentDialog.getElement().getFirst().$.style.zIndex -= Math.floor(this._.editor.config.baseFloatZIndex / 2), CKEDITOR.dialog._.currentTop = this);
                for (var i in t.on("keydown", y), t.on("keyup", x), this._.hasFocus = !1, e.contents)
                    if (e.contents[i]) {
                        var n = e.contents[i],
                            o = this._.tabs[n.id],
                            s = n.requiredContent,
                            a = 0;
                        if (o) {
                            for (var r in this._.contents[n.id]) {
                                var l = this._.contents[n.id][r];
                                "hbox" != l.type && "vbox" != l.type && l.getInputElement() && (l.requiredContent && !this._.editor.activeFilter.check(l.requiredContent) ? l.disable() : (l.enable(), a++))
                            }!a || s && !this._.editor.activeFilter.check(s) ? o[0].addClass("cke_dialog_tab_disabled") : o[0].removeClass("cke_dialog_tab_disabled")
                        }
                    }
                CKEDITOR.tools.setTimeout(function() {
                    this.layout(),
                        function(t) {
                            var e = CKEDITOR.document.getWindow();

                            function i() {
                                t.layout()
                            }
                            e.on("resize", i), t.on("hide", function() {
                                e.removeListener("resize", i)
                            })
                        }(this), this.parts.dialog.setStyle("visibility", ""), this.fireOnce("load", {}), CKEDITOR.ui.fire("ready", this), this.fire("show", {}), this._.editor.fire("dialogShow", this), this._.parentDialog || this._.editor.focusManager.lock(), this.foreach(function(t) {
                            t.setInitValue && t.setInitValue()
                        })
                }, 100, this)
            },
            layout: function() {
                var t = this.parts.dialog,
                    e = this.getSize(),
                    i = CKEDITOR.document.getWindow().getViewPaneSize(),
                    n = (i.width - e.width) / 2,
                    o = (i.height - e.height) / 2;
                CKEDITOR.env.ie6Compat || (e.height + (o > 0 ? o : 0) > i.height || e.width + (n > 0 ? n : 0) > i.width ? t.setStyle("position", "absolute") : t.setStyle("position", "fixed")), this.move(this._.moved ? this._.position.x : n, this._.moved ? this._.position.y : o)
            },
            foreach: function(t) {
                for (var e in this._.contents)
                    for (var i in this._.contents[e]) t.call(this, this._.contents[e][i]);
                return this
            },
            reset: (o = function(t) {
                t.reset && t.reset(1)
            }, function() {
                return this.foreach(o), this
            }),
            setupContent: function() {
                var t = arguments;
                this.foreach(function(e) {
                    e.setup && e.setup.apply(e, t)
                })
            },
            commitContent: function() {
                var t = arguments;
                this.foreach(function(e) {
                    CKEDITOR.env.ie && this._.currentFocusIndex == e.focusIndex && e.getInputElement().$.blur(), e.commit && e.commit.apply(e, t)
                })
            },
            hide: function() {
                if (this.parts.dialog.isVisible()) {
                    this.fire("hide", {}), this._.editor.fire("dialogHide", this), this.selectPage(this._.tabIdList[0]);
                    var t = this._.element;
                    for (t.setStyle("display", "none"), this.parts.dialog.setStyle("visibility", "hidden"), w(this); CKEDITOR.dialog._.currentTop != this;) CKEDITOR.dialog._.currentTop.hide();
                    if (this._.parentDialog) {
                        var e = this._.parentDialog.getElement().getFirst();
                        e.setStyle("z-index", parseInt(e.$.style.zIndex, 10) + Math.floor(this._.editor.config.baseFloatZIndex / 2))
                    } else v(this._.editor);
                    if (CKEDITOR.dialog._.currentTop = this._.parentDialog, this._.parentDialog) CKEDITOR.dialog._.currentZIndex -= 10;
                    else {
                        CKEDITOR.dialog._.currentZIndex = null, t.removeListener("keydown", y), t.removeListener("keyup", x);
                        var i = this._.editor;
                        i.focus(), setTimeout(function() {
                            i.focusManager.unlock(), CKEDITOR.env.iOS && i.window.focus()
                        }, 0)
                    }
                    delete this._.parentDialog, this.foreach(function(t) {
                        t.resetInitValue && t.resetInitValue()
                    }), this.setState(CKEDITOR.DIALOG_STATE_IDLE)
                }
            },
            addPage: function(t) {
                if (!t.requiredContent || this._.editor.filter.check(t.requiredContent)) {
                    for (var e, i = [], n = t.label ? ' title="' + CKEDITOR.tools.htmlEncode(t.label) + '"' : "", o = CKEDITOR.dialog._.uiElementBuilders.vbox.build(this, {
                            type: "vbox",
                            className: "cke_dialog_page_contents",
                            children: t.elements,
                            expand: !!t.expand,
                            padding: t.padding,
                            style: t.style || "width: 100%;"
                        }, i), s = this._.contents[t.id] = {}, a = o.getChild(), r = 0; e = a.shift();) e.notAllowed || "hbox" == e.type || "vbox" == e.type || r++, s[e.id] = e, "function" == typeof e.getChild && a.push.apply(a, e.getChild());
                    r || (t.hidden = !0);
                    var l = CKEDITOR.dom.element.createFromHtml(i.join(""));
                    l.setAttribute("role", "tabpanel");
                    var d = CKEDITOR.env,
                        u = "cke_" + t.id + "_" + CKEDITOR.tools.getNextNumber(),
                        c = CKEDITOR.dom.element.createFromHtml(['<a class="cke_dialog_tab"', this._.pageCount > 0 ? " cke_last" : "cke_first", n, t.hidden ? ' style="display:none"' : "", ' id="', u, '"', d.gecko && !d.hc ? "" : ' href="javascript:void(0)"', ' tabIndex="-1"', ' hidefocus="true"', ' role="tab">', t.label, "</a>"].join(""));
                    l.setAttribute("aria-labelledby", u), this._.tabs[t.id] = [c, l], this._.tabIdList.push(t.id), !t.hidden && this._.pageCount++, this._.lastTab = c, this.updateStyle(), l.setAttribute("name", t.id), l.appendTo(this.parts.contents), c.unselectable(), this.parts.tabs.append(c), t.accessKey && (k(this, this, "CTRL+" + t.accessKey, L, S), this._.accessKeyMap["CTRL+" + t.accessKey] = t.id)
                }
            },
            selectPage: function(t) {
                if (this._.currentTabId != t && !this._.tabs[t][0].hasClass("cke_dialog_tab_disabled") && !1 !== this.fire("selectPage", {
                        page: t,
                        currentPage: this._.currentTabId
                    })) {
                    for (var e in this._.tabs) {
                        var i = this._.tabs[e][0],
                            o = this._.tabs[e][1];
                        e != t && (i.removeClass("cke_dialog_tab_selected"), o.hide()), o.setAttribute("aria-hidden", e != t)
                    }
                    var s = this._.tabs[t];
                    s[0].addClass("cke_dialog_tab_selected"), CKEDITOR.env.ie6Compat || CKEDITOR.env.ie7Compat ? (n(s[1]), s[1].show(), setTimeout(function() {
                        n(s[1], 1)
                    }, 0)) : s[1].show(), this._.currentTabId = t, this._.currentTabIndex = CKEDITOR.tools.indexOf(this._.tabIdList, t)
                }
            },
            updateStyle: function() {
                this.parts.dialog[(1 === this._.pageCount ? "add" : "remove") + "Class"]("cke_single_page")
            },
            hidePage: function(t) {
                var e = this._.tabs[t] && this._.tabs[t][0];
                e && 1 != this._.pageCount && e.isVisible() && (t == this._.currentTabId && this.selectPage(i.call(this)), e.hide(), this._.pageCount--, this.updateStyle())
            },
            showPage: function(t) {
                var e = this._.tabs[t] && this._.tabs[t][0];
                e && (e.show(), this._.pageCount++, this.updateStyle())
            },
            getElement: function() {
                return this._.element
            },
            getName: function() {
                return this._.name
            },
            getContentElement: function(t, e) {
                var i = this._.contents[t];
                return i && i[e]
            },
            getValueOf: function(t, e) {
                return this.getContentElement(t, e).getValue()
            },
            setValueOf: function(t, e, i) {
                return this.getContentElement(t, e).setValue(i)
            },
            getButton: function(t) {
                return this._.buttons[t]
            },
            click: function(t) {
                return this._.buttons[t].click()
            },
            disableButton: function(t) {
                return this._.buttons[t].disable()
            },
            enableButton: function(t) {
                return this._.buttons[t].enable()
            },
            getPageCount: function() {
                return this._.pageCount
            },
            getParentEditor: function() {
                return this._.editor
            },
            getSelectedElement: function() {
                return this.getParentEditor().getSelection().getSelectedElement()
            },
            addFocusable: function(t, e) {
                if (void 0 === e) e = this._.focusList.length, this._.focusList.push(new r(this, t, e));
                else {
                    this._.focusList.splice(e, 0, new r(this, t, e));
                    for (var i = e + 1; i < this._.focusList.length; i++) this._.focusList[i].focusIndex++
                }
            },
            setState: function(t) {
                if (this.state != t) {
                    if (this.state = t, t == CKEDITOR.DIALOG_STATE_BUSY) {
                        if (!this.parts.spinner) {
                            var e = this.getParentEditor().lang.dir,
                                i = {
                                    attributes: {
                                        class: "cke_dialog_spinner"
                                    },
                                    styles: {
                                        float: "rtl" == e ? "right" : "left"
                                    }
                                };
                            i.styles["margin-" + ("rtl" == e ? "left" : "right")] = "8px", this.parts.spinner = CKEDITOR.document.createElement("div", i), this.parts.spinner.setHtml("&#8987;"), this.parts.spinner.appendTo(this.parts.title, 1)
                        }
                        this.parts.spinner.show(), this.getButton("ok").disable()
                    } else t == CKEDITOR.DIALOG_STATE_IDLE && (this.parts.spinner && this.parts.spinner.hide(), this.getButton("ok").enable());
                    this.fire("state", t)
                }
            }
        }, CKEDITOR.tools.extend(CKEDITOR.dialog, {
            add: function(t, e) {
                this._.dialogDefinitions[t] && "function" != typeof e || (this._.dialogDefinitions[t] = e)
            },
            exists: function(t) {
                return !!this._.dialogDefinitions[t]
            },
            getCurrent: function() {
                return CKEDITOR.dialog._.currentTop
            },
            isTabEnabled: function(t, e, i) {
                var n = t.config.removeDialogTabs;
                return !(n && n.match(new RegExp("(?:^|;)" + e + ":" + i + "(?:$|;)", "i")))
            },
            okButton: (s = function(t, e) {
                return e = e || {}, CKEDITOR.tools.extend({
                    id: "ok",
                    type: "button",
                    label: t.lang.common.ok,
                    class: "cke_dialog_ui_button_ok",
                    onClick: function(t) {
                        var e = t.data.dialog;
                        !1 !== e.fire("ok", {
                            hide: !0
                        }).hide && e.hide()
                    }
                }, e, !0)
            }, s.type = "button", s.override = function(t) {
                return CKEDITOR.tools.extend(function(e) {
                    return s(e, t)
                }, {
                    type: "button"
                }, !0)
            }, s),
            cancelButton: function() {
                var t = function(t, e) {
                    return e = e || {}, CKEDITOR.tools.extend({
                        id: "cancel",
                        type: "button",
                        label: t.lang.common.cancel,
                        class: "cke_dialog_ui_button_cancel",
                        onClick: function(t) {
                            var e = t.data.dialog;
                            !1 !== e.fire("cancel", {
                                hide: !0
                            }).hide && e.hide()
                        }
                    }, e, !0)
                };
                return t.type = "button", t.override = function(e) {
                    return CKEDITOR.tools.extend(function(i) {
                        return t(i, e)
                    }, {
                        type: "button"
                    }, !0)
                }, t
            }(),
            addUIElement: function(t, e) {
                this._.uiElementBuilders[t] = e
            }
        }), CKEDITOR.dialog._ = {
            uiElementBuilders: {},
            dialogDefinitions: {},
            currentTop: null,
            currentZIndex: null
        }, CKEDITOR.event.implementOn(CKEDITOR.dialog), CKEDITOR.event.implementOn(CKEDITOR.dialog.prototype);
        var l, d = {
                resizable: CKEDITOR.DIALOG_RESIZE_BOTH,
                minWidth: 600,
                minHeight: 400,
                buttons: [CKEDITOR.dialog.okButton, CKEDITOR.dialog.cancelButton]
            },
            u = function(t, e, i) {
                for (var n, o = 0; n = t[o]; o++) {
                    if (n.id == e) return n;
                    if (i && n[i]) {
                        var s = u(n[i], e, i);
                        if (s) return s
                    }
                }
                return null
            },
            c = function(t, e, i, n, o) {
                if (i) {
                    for (var s, a = 0; s = t[a]; a++) {
                        if (s.id == i) return t.splice(a, 0, e), e;
                        if (n && s[n]) {
                            var r = c(s[n], e, i, n, !0);
                            if (r) return r
                        }
                    }
                    if (o) return null
                }
                return t.push(e), e
            },
            h = function(t, e, i) {
                for (var n, o = 0; n = t[o]; o++) {
                    if (n.id == e) return t.splice(o, 1);
                    if (i && n[i]) {
                        var s = h(n[i], e, i);
                        if (s) return s
                    }
                }
                return null
            },
            g = function(t, e) {
                this.dialog = t;
                for (var i, n = e.contents, o = 0; i = n[o]; o++) n[o] = i && new f(t, i);
                CKEDITOR.tools.extend(this, e)
            };

        function f(t, e) {
            this._ = {
                dialog: t
            }, CKEDITOR.tools.extend(this, e)
        }
        g.prototype = {
            getContents: function(t) {
                return u(this.contents, t)
            },
            getButton: function(t) {
                return u(this.buttons, t)
            },
            addContents: function(t, e) {
                return c(this.contents, t, e)
            },
            addButton: function(t, e) {
                return c(this.buttons, t, e)
            },
            removeContents: function(t) {
                h(this.contents, t)
            },
            removeButton: function(t) {
                h(this.buttons, t)
            }
        }, f.prototype = {
            get: function(t) {
                return u(this.elements, t, "children")
            },
            add: function(t, e) {
                return c(this.elements, t, e, "children")
            },
            remove: function(t) {
                h(this.elements, t, "children")
            }
        };
        var p, _ = {};

        function I(t) {
            t.data.preventDefault(1)
        }

        function m(t) {
            var e = CKEDITOR.document.getWindow(),
                i = t.config,
                n = CKEDITOR.skinName || t.config.skin,
                o = i.dialog_backgroundCoverColor || ("moono-lisa" == n ? "black" : "white"),
                s = i.dialog_backgroundCoverOpacity,
                a = i.baseFloatZIndex,
                r = CKEDITOR.tools.genKey(o, s, a),
                d = _[r];
            if (d) d.show();
            else {
                var u = ['<div tabIndex="-1" style="position: ', CKEDITOR.env.ie6Compat ? "absolute" : "fixed", "; z-index: ", a, "; top: 0px; left: 0px; ", CKEDITOR.env.ie6Compat ? "" : "background-color: " + o, '" class="cke_dialog_background_cover">'];
                if (CKEDITOR.env.ie6Compat) {
                    var c = "<html><body style=\\'background-color:" + o + ";\\'></body></html>";
                    u.push('<iframe hidefocus="true" frameborder="0" id="cke_dialog_background_iframe" src="javascript:'), u.push("void((function(){" + encodeURIComponent("document.open();(" + CKEDITOR.tools.fixDomain + ")();document.write( '" + c + "' );document.close();") + "})())"), u.push('" style="position:absolute;left:0;top:0;width:100%;height: 100%;filter: progid:DXImageTransform.Microsoft.Alpha(opacity=0)"></iframe>')
                }
                u.push("</div>"), (d = CKEDITOR.dom.element.createFromHtml(u.join(""))).setOpacity(void 0 !== s ? s : .5), d.on("keydown", I), d.on("keypress", I), d.on("keyup", I), d.appendTo(CKEDITOR.document.getBody()), _[r] = d
            }
            t.focusManager.add(d), p = d;
            var h = function() {
                    var t = e.getViewPaneSize();
                    d.setStyles({
                        width: t.width + "px",
                        height: t.height + "px"
                    })
                },
                g = function() {
                    var t = e.getScrollPosition(),
                        i = CKEDITOR.dialog._.currentTop;
                    if (d.setStyles({
                            left: t.x + "px",
                            top: t.y + "px"
                        }), i)
                        do {
                            var n = i.getPosition();
                            i.move(n.x, n.y)
                        } while (i = i._.parentDialog)
                };
            if (l = h, e.on("resize", h), h(), CKEDITOR.env.mac && CKEDITOR.env.webkit || d.focus(), CKEDITOR.env.ie6Compat) {
                var f = function() {
                    g(), arguments.callee.prevScrollHandler.apply(this, arguments)
                };
                e.$.setTimeout(function() {
                    f.prevScrollHandler = window.onscroll || function() {}, window.onscroll = f
                }, 0), g()
            }
        }

        function v(t) {
            if (p) {
                t.focusManager.remove(p);
                var e = CKEDITOR.document.getWindow();
                p.hide(), e.removeListener("resize", l), CKEDITOR.env.ie6Compat && e.$.setTimeout(function() {
                    var t = window.onscroll && window.onscroll.prevScrollHandler;
                    window.onscroll = t || null
                }, 0), l = null
            }
        }
        var C, E, T, D, b, O, K, R = {},
            y = function(t) {
                var e = t.data.$.ctrlKey || t.data.$.metaKey,
                    i = t.data.$.altKey,
                    n = t.data.$.shiftKey,
                    o = String.fromCharCode(t.data.$.keyCode),
                    s = R[(e ? "CTRL+" : "") + (i ? "ALT+" : "") + (n ? "SHIFT+" : "") + o];
                s && s.length && ((s = s[s.length - 1]).keydown && s.keydown.call(s.uiElement, s.dialog, s.key), t.data.preventDefault())
            },
            x = function(t) {
                var e = t.data.$.ctrlKey || t.data.$.metaKey,
                    i = t.data.$.altKey,
                    n = t.data.$.shiftKey,
                    o = String.fromCharCode(t.data.$.keyCode),
                    s = R[(e ? "CTRL+" : "") + (i ? "ALT+" : "") + (n ? "SHIFT+" : "") + o];
                s && s.length && (s = s[s.length - 1]).keyup && (s.keyup.call(s.uiElement, s.dialog, s.key), t.data.preventDefault())
            },
            k = function(t, e, i, n, o) {
                (R[i] || (R[i] = [])).push({
                    uiElement: t,
                    dialog: e,
                    key: i,
                    keyup: o || t.accessKeyUp,
                    keydown: n || t.accessKeyDown
                })
            },
            w = function(t) {
                for (var e in R) {
                    for (var i = R[e], n = i.length - 1; n >= 0; n--) i[n].dialog != t && i[n].uiElement != t || i.splice(n, 1);
                    0 === i.length && delete R[e]
                }
            },
            S = function(t, e) {
                t._.accessKeyMap[e] && t.selectPage(t._.accessKeyMap[e])
            },
            L = function() {};
        CKEDITOR.ui.dialog = {
            uiElement: function(t, e, i, n, o, s, a) {
                if (!(arguments.length < 4)) {
                    var r, l = (n.call ? n(e) : n) || "div",
                        d = ["<", l, " "],
                        u = (o && o.call ? o(e) : o) || {},
                        c = (s && s.call ? s(e) : s) || {},
                        h = (a && a.call ? a.call(this, t, e) : a) || "",
                        g = this.domId = c.id || CKEDITOR.tools.getNextId() + "_uiElement";
                    e.requiredContent && !t.getParentEditor().filter.check(e.requiredContent) && (u.display = "none", this.notAllowed = !0), c.id = g;
                    var f = {};
                    e.type && (f["cke_dialog_ui_" + e.type] = 1), e.className && (f[e.className] = 1), e.disabled && (f.cke_disabled = 1);
                    var p = c.class && c.class.split ? c.class.split(" ") : [];
                    for (r = 0; r < p.length; r++) p[r] && (f[p[r]] = 1);
                    var _ = [];
                    for (r in f) _.push(r);
                    c.class = _.join(" "), e.title && (c.title = e.title);
                    var I = (e.style || "").split(";");
                    if (e.align) {
                        var m = e.align;
                        u["margin-left"] = "left" == m ? 0 : "auto", u["margin-right"] = "right" == m ? 0 : "auto"
                    }
                    for (r in u) I.push(r + ":" + u[r]);
                    for (e.hidden && I.push("display:none"), r = I.length - 1; r >= 0; r--) "" === I[r] && I.splice(r, 1);
                    for (r in I.length > 0 && (c.style = (c.style ? c.style + "; " : "") + I.join("; ")), c) d.push(r + '="' + CKEDITOR.tools.htmlEncode(c[r]) + '" ');
                    d.push(">", h, "</", l, ">"), i.push(d.join("")), (this._ || (this._ = {})).dialog = t, "boolean" == typeof e.isChanged && (this.isChanged = function() {
                        return e.isChanged
                    }), "function" == typeof e.isChanged && (this.isChanged = e.isChanged), "function" == typeof e.setValue && (this.setValue = CKEDITOR.tools.override(this.setValue, function(t) {
                        return function(i) {
                            t.call(this, e.setValue.call(this, i))
                        }
                    })), "function" == typeof e.getValue && (this.getValue = CKEDITOR.tools.override(this.getValue, function(t) {
                        return function() {
                            return e.getValue.call(this, t.call(this))
                        }
                    })), CKEDITOR.event.implementOn(this), this.registerEvents(e), this.accessKeyUp && this.accessKeyDown && e.accessKey && k(this, t, "CTRL+" + e.accessKey);
                    var v = this;
                    t.on("load", function() {
                        var e = v.getInputElement();
                        if (e) {
                            var i = v.type in {
                                checkbox: 1,
                                ratio: 1
                            } && CKEDITOR.env.ie && CKEDITOR.env.version < 8 ? "cke_dialog_ui_focused" : "";
                            e.on("focus", function() {
                                t._.tabBarMode = !1, t._.hasFocus = !0, v.fire("focus"), i && this.addClass(i)
                            }), e.on("blur", function() {
                                v.fire("blur"), i && this.removeClass(i)
                            })
                        }
                    }), CKEDITOR.tools.extend(this, e), this.keyboardFocusable && (this.tabIndex = e.tabIndex || 0, this.focusIndex = t._.focusList.push(this) - 1, this.on("focus", function() {
                        t._.currentFocusIndex = v.focusIndex
                    }))
                }
            },
            hbox: function(e, i, n, o, s) {
                if (!(arguments.length < 4)) {
                    this._ || (this._ = {});
                    var a, r = this._.children = i,
                        l = s && s.widths || null,
                        d = s && s.height || null,
                        u = {
                            role: "presentation"
                        };
                    s && s.align && (u.align = s.align), CKEDITOR.ui.dialog.uiElement.call(this, e, s || {
                        type: "hbox"
                    }, o, "table", {}, u, function() {
                        var e = ['<tbody><tr class="cke_dialog_ui_hbox">'];
                        for (a = 0; a < n.length; a++) {
                            var i = "cke_dialog_ui_hbox_child",
                                o = [];
                            0 === a && (i = "cke_dialog_ui_hbox_first"), a == n.length - 1 && (i = "cke_dialog_ui_hbox_last"), e.push('<td class="', i, '" role="presentation" '), l ? l[a] && o.push("width:" + t(l[a])) : o.push("width:" + Math.floor(100 / n.length) + "%"), d && o.push("height:" + t(d)), s && void 0 !== s.padding && o.push("padding:" + t(s.padding)), CKEDITOR.env.ie && CKEDITOR.env.quirks && r[a].align && o.push("text-align:" + r[a].align), o.length > 0 && e.push('style="' + o.join("; ") + '" '), e.push(">", n[a], "</td>")
                        }
                        return e.push("</tr></tbody>"), e.join("")
                    })
                }
            },
            vbox: function(e, i, n, o, s) {
                if (!(arguments.length < 3)) {
                    this._ || (this._ = {});
                    var a = this._.children = i,
                        r = s && s.width || null,
                        l = s && s.heights || null;
                    CKEDITOR.ui.dialog.uiElement.call(this, e, s || {
                        type: "vbox"
                    }, o, "div", null, {
                        role: "presentation"
                    }, function() {
                        var i = ['<table role="presentation" cellspacing="0" border="0" '];
                        i.push('style="'), s && s.expand && i.push("height:100%;"), i.push("width:" + t(r || "100%"), ";"), CKEDITOR.env.webkit && i.push("float:none;"), i.push('"'), i.push('align="', CKEDITOR.tools.htmlEncode(s && s.align || ("ltr" == e.getParentEditor().lang.dir ? "left" : "right")), '" '), i.push("><tbody>");
                        for (var o = 0; o < n.length; o++) {
                            var d = [];
                            i.push('<tr><td role="presentation" '), r && d.push("width:" + t(r || "100%")), l ? d.push("height:" + t(l[o])) : s && s.expand && d.push("height:" + Math.floor(100 / n.length) + "%"), s && void 0 !== s.padding && d.push("padding:" + t(s.padding)), CKEDITOR.env.ie && CKEDITOR.env.quirks && a[o].align && d.push("text-align:" + a[o].align), d.length > 0 && i.push('style="', d.join("; "), '" '), i.push(' class="cke_dialog_ui_vbox_child">', n[o], "</td></tr>")
                        }
                        return i.push("</tbody></table>"), i.join("")
                    })
                }
            }
        }, CKEDITOR.ui.dialog.uiElement.prototype = {
            getElement: function() {
                return CKEDITOR.document.getById(this.domId)
            },
            getInputElement: function() {
                return this.getElement()
            },
            getDialog: function() {
                return this._.dialog
            },
            setValue: function(t, e) {
                return this.getInputElement().setValue(t), !e && this.fire("change", {
                    value: t
                }), this
            },
            getValue: function() {
                return this.getInputElement().getValue()
            },
            isChanged: function() {
                return !1
            },
            selectParentTab: function() {
                for (var t, e = this.getInputElement();
                    (e = e.getParent()) && -1 == e.$.className.search("cke_dialog_page_contents"););
                return e ? (t = e.getAttribute("name"), this._.dialog._.currentTabId != t && this._.dialog.selectPage(t), this) : this
            },
            focus: function() {
                return this.selectParentTab().getInputElement().focus(), this
            },
            registerEvents: function(t) {
                var e, i = /^on([A-Z]\w+)/,
                    n = function(t, e, i, n) {
                        e.on("load", function() {
                            t.getInputElement().on(i, n, t)
                        })
                    };
                for (var o in t)(e = o.match(i)) && (this.eventProcessors[o] ? this.eventProcessors[o].call(this, this._.dialog, t[o]) : n(this, this._.dialog, e[1].toLowerCase(), t[o]));
                return this
            },
            eventProcessors: {
                onLoad: function(t, e) {
                    t.on("load", e, this)
                },
                onShow: function(t, e) {
                    t.on("show", e, this)
                },
                onHide: function(t, e) {
                    t.on("hide", e, this)
                }
            },
            accessKeyDown: function() {
                this.focus()
            },
            accessKeyUp: function() {},
            disable: function() {
                var t = this.getElement();
                this.getInputElement().setAttribute("disabled", "true"), t.addClass("cke_disabled")
            },
            enable: function() {
                var t = this.getElement();
                this.getInputElement().removeAttribute("disabled"), t.removeClass("cke_disabled")
            },
            isEnabled: function() {
                return !this.getElement().hasClass("cke_disabled")
            },
            isVisible: function() {
                return this.getInputElement().isVisible()
            },
            isFocusable: function() {
                return !(!this.isEnabled() || !this.isVisible())
            }
        }, CKEDITOR.ui.dialog.hbox.prototype = CKEDITOR.tools.extend(new CKEDITOR.ui.dialog.uiElement, {
            getChild: function(t) {
                return arguments.length < 1 ? this._.children.concat() : (t.splice || (t = [t]), t.length < 2 ? this._.children[t[0]] : this._.children[t[0]] && this._.children[t[0]].getChild ? this._.children[t[0]].getChild(t.slice(1, t.length)) : null)
            }
        }, !0), CKEDITOR.ui.dialog.vbox.prototype = new CKEDITOR.ui.dialog.hbox, C = {
            build: function(t, e, i) {
                for (var n, o = e.children, s = [], a = [], r = 0; r < o.length && (n = o[r]); r++) {
                    var l = [];
                    s.push(l), a.push(CKEDITOR.dialog._.uiElementBuilders[n.type].build(t, n, l))
                }
                return new CKEDITOR.ui.dialog[e.type](t, a, s, i, e)
            }
        }, CKEDITOR.dialog.addUIElement("hbox", C), CKEDITOR.dialog.addUIElement("vbox", C), CKEDITOR.dialogCommand = function(t, e) {
            this.dialogName = t, CKEDITOR.tools.extend(this, e, !0)
        }, CKEDITOR.dialogCommand.prototype = {
            exec: function(t) {
                var e = this.tabId;
                t.openDialog(this.dialogName, function(t) {
                    e && t.selectPage(e)
                })
            },
            canUndo: !1,
            editorFocus: 1
        }, E = /^([a]|[^a])+$/, T = /^\d*$/, D = /^\d*(?:\.\d+)?$/, b = /^(((\d*(\.\d+))|(\d*))(px|\%)?)?$/, O = /^(((\d*(\.\d+))|(\d*))(px|em|ex|in|cm|mm|pt|pc|\%)?)?$/i, K = /^(\s*[\w-]+\s*:\s*[^:;]+(?:;|$))*$/, CKEDITOR.VALIDATE_OR = 1, CKEDITOR.VALIDATE_AND = 2, CKEDITOR.dialog.validate = {
            functions: function() {
                var t = arguments;
                return function() {
                    var e, i, n = this && this.getValue ? this.getValue() : t[0],
                        o = CKEDITOR.VALIDATE_AND,
                        s = [];
                    for (i = 0; i < t.length && "function" == typeof t[i]; i++) s.push(t[i]);
                    i < t.length && "string" == typeof t[i] && (e = t[i], i++), i < t.length && "number" == typeof t[i] && (o = t[i]);
                    var a = o == CKEDITOR.VALIDATE_AND;
                    for (i = 0; i < s.length; i++) a = o == CKEDITOR.VALIDATE_AND ? a && s[i](n) : a || s[i](n);
                    return !!a || e
                }
            },
            regex: function(t, e) {
                return function() {
                    var i = this && this.getValue ? this.getValue() : arguments[0];
                    return !!t.test(i) || e
                }
            },
            notEmpty: function(t) {
                return this.regex(E, t)
            },
            integer: function(t) {
                return this.regex(T, t)
            },
            number: function(t) {
                return this.regex(D, t)
            },
            cssLength: function(t) {
                return this.functions(function(t) {
                    return O.test(CKEDITOR.tools.trim(t))
                }, t)
            },
            htmlLength: function(t) {
                return this.functions(function(t) {
                    return b.test(CKEDITOR.tools.trim(t))
                }, t)
            },
            inlineStyle: function(t) {
                return this.functions(function(t) {
                    return K.test(CKEDITOR.tools.trim(t))
                }, t)
            },
            equals: function(t, e) {
                return this.functions(function(e) {
                    return e == t
                }, e)
            },
            notEqual: function(t, e) {
                return this.functions(function(e) {
                    return e != t
                }, e)
            }
        }, CKEDITOR.on("instanceDestroyed", function(t) {
            if (CKEDITOR.tools.isEmpty(CKEDITOR.instances)) {
                for (var e; e = CKEDITOR.dialog._.currentTop;) e.hide();
                ! function() {
                    for (var t in _) _[t].remove();
                    _ = {}
                }()
            }
            var i = t.editor._.storedDialogs;
            for (var n in i) i[n].destroy()
        }), CKEDITOR.tools.extend(CKEDITOR.editor.prototype, {
            openDialog: function(t, e) {
                var i = null,
                    n = CKEDITOR.dialog._.dialogDefinitions[t];
                if (null === CKEDITOR.dialog._.currentTop && m(this), "function" == typeof n) {
                    var o = this._.storedDialogs || (this._.storedDialogs = {});
                    i = o[t] || (o[t] = new CKEDITOR.dialog(this, t)), e && e.call(i, i), i.show()
                } else {
                    if ("failed" == n) throw v(this), new Error('[CKEDITOR.dialog.openDialog] Dialog "' + t + '" failed when loading definition.');
                    "string" == typeof n && CKEDITOR.scriptLoader.load(CKEDITOR.getUrl(n), function() {
                        "function" != typeof CKEDITOR.dialog._.dialogDefinitions[t] && (CKEDITOR.dialog._.dialogDefinitions[t] = "failed"), this.openDialog(t, e)
                    }, this, 0, 1)
                }
                return CKEDITOR.skin.loadPart("dialog"), i
            }
        })
    }(), CKEDITOR.plugins.add("dialog", {
        requires: "dialogui",
        init: function(t) {
            t.on("doubleclick", function(e) {
                e.data.dialog && t.openDialog(e.data.dialog)
            }, null, null, 999)
        }
    });