CKEDITOR.plugins.add("table", {
    requires: "dialog",
    init: function(a) {
        function f(c) {
            return CKEDITOR.tools.extend(c || {}, {
                contextSensitive: 1,
                refresh: function(c, b) {
                    this.setState(b.contains("table", 1) ? CKEDITOR.TRISTATE_OFF : CKEDITOR.TRISTATE_DISABLED)
                }
            })
        }
        if (!a.blockless) {
            var e = a.lang.table;
            a.addCommand("table", new CKEDITOR.dialogCommand("table", {
                context: "table",
                allowedContent: "table{width,height,border-collapse}[align,border,cellpadding,cellspacing,summary];caption tbody thead tfoot;th td tr[scope];td{border*,background-color,vertical-align,width,height}[colspan,rowspan];" +
                    (a.plugins.dialogadvtab ? "table" + a.plugins.dialogadvtab.allowedContent() : ""),
                requiredContent: "table",
                contentTransformations: [
                    ["table{width}: sizeToStyle", "table[width]: sizeToAttribute"],
                    ["td: splitBorderShorthand"],
                    [{
                        element: "table",
                        right: function(c) {
                            if (c.styles) {
                                var a;
                                if (c.styles.border) a = CKEDITOR.tools.style.parse.border(c.styles.border);
                                else if (CKEDITOR.env.ie && 8 === CKEDITOR.env.version) {
                                    var b = c.styles;
                                    b["border-left"] && b["border-left"] === b["border-right"] && b["border-right"] === b["border-top"] &&
                                        b["border-top"] === b["border-bottom"] && (a = CKEDITOR.tools.style.parse.border(b["border-top"]))
                                }
                                a && a.style && "solid" === a.style && a.width && 0 !== parseFloat(a.width) && (c.attributes.border = 1);
                                "collapse" == c.styles["border-collapse"] && (c.attributes.cellspacing = 0)
                            }
                        }
                    }]
                ]
            }));
            a.addCommand("tableProperties", new CKEDITOR.dialogCommand("tableProperties", f()));
            a.addCommand("tableDelete", f({
                exec: function(a) {
                    var d = a.elementPath().contains("table", 1);
                    if (d) {
                        var b = d.getParent(),
                            e = a.editable();
                        1 != b.getChildCount() || b.is("td",
                            "th") || b.equals(e) || (d = b);
                        a = a.createRange();
                        a.moveToPosition(d, CKEDITOR.POSITION_BEFORE_START);
                        d.remove();
                        a.select()
                    }
                }
            }));
            a.ui.addButton && a.ui.addButton("Table", {
                label: e.toolbar,
                command: "table",
                toolbar: "insert,30"
            });
            CKEDITOR.dialog.add("table", this.path + "dialogs/table.js");
            CKEDITOR.dialog.add("tableProperties", this.path + "dialogs/table.js");
            a.addMenuItems && a.addMenuItems({
                table: {
                    label: e.menu,
                    command: "tableProperties",
                    group: "table",
                    order: 5
                },
                tabledelete: {
                    label: e.deleteTable,
                    command: "tableDelete",
                    group: "table",
                    order: 1
                }
            });
            a.on("doubleclick", function(a) {
                a.data.element.is("table") && (a.data.dialog = "tableProperties")
            });
            a.contextMenu && a.contextMenu.addListener(function() {
                return {
                    tabledelete: CKEDITOR.TRISTATE_OFF,
                    table: CKEDITOR.TRISTATE_OFF
                }
            })
        }
    }
});