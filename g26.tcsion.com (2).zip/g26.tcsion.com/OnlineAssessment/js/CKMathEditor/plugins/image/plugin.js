! function() {
    CKEDITOR.plugins.add("image", {
        requires: "dialog",
        lang: "en",
        icons: "image",
        hidpi: !1,
        init: function(e) {
            if (!e.plugins.detectConflict("image", ["easyimage", "image2"])) {
                CKEDITOR.dialog.add("image", this.path + "dialogs/image.js");
                var i = "img[alt,!src]{border-style,border-width,float,height,margin,margin-bottom,margin-left,margin-right,margin-top,width}";
                CKEDITOR.dialog.isTabEnabled(e, "image", "advanced") && (i = "img[alt,dir,id,lang,longdesc,!src,title]{*}(*)"), e.addCommand("image", new CKEDITOR.dialogCommand("image", {
                    allowedContent: i,
                    requiredContent: "img[alt,src]",
                    contentTransformations: [
                        ["img{width}: sizeToStyle", "img[width]: sizeToAttribute"],
                        ["img{float}: alignmentToStyle", "img[align]: alignmentToAttribute"]
                    ]
                })), e.ui.addButton && e.ui.addButton("Image", {
                    label: e.lang.common.image,
                    command: "image",
                    toolbar: "insert,10"
                }), e.on("doubleclick", function(e) {}), e.addMenuItems && e.addMenuItems({
                    image: {
                        label: e.lang.image.menu,
                        command: "image",
                        group: "image"
                    }
                })
            }
        },
        afterInit: function(e) {
            function i(i) {
                var t = e.getCommand("justify" + i);
                t && ("left" != i && "right" != i || t.on("exec", function(e) {}), t.on("refresh", function(t) {
                    var n, a = function(e, i) {
                        if (!i) {
                            var t = e.getSelection();
                            i = t.getSelectedElement()
                        }
                        if (i && i.is("img") && !i.data("cke-realelement") && !i.isReadOnly()) return i
                    }(e);
                    a && (n = function(e) {
                        var i = e.getStyle("float");
                        "inherit" != i && "none" != i || (i = 0);
                        i || (i = e.getAttribute("align"));
                        return i
                    }(a), this.setState(n == i ? CKEDITOR.TRISTATE_ON : "right" == i || "left" == i ? CKEDITOR.TRISTATE_OFF : CKEDITOR.TRISTATE_DISABLED), t.cancel())
                }))
            }
            e.plugins.image2 || (i("left"), i("right"), i("center"), i("block"))
        }
    })
}(), CKEDITOR.config.image_removeLinkByEmptyURL = !0;