CKEDITOR.plugins.add("contextmenu", {
    requires: "menu",
    lang: "af,ar,az,bg,bn,bs,ca,cs,cy,da,de,de-ch,el,en,en-au,en-ca,en-gb,eo,es,es-mx,et,eu,fa,fi,fo,fr,fr-ca,gl,gu,he,hi,hr,hu,id,is,it,ja,ka,km,ko,ku,lt,lv,mk,mn,ms,nb,nl,no,oc,pl,pt,pt-br,ro,ru,si,sk,sl,sq,sr,sr-latn,sv,th,tr,tt,ug,uk,vi,zh,zh-cn",
    onLoad: function() {
        CKEDITOR.plugins.contextMenu = CKEDITOR.tools.createClass({
            base: CKEDITOR.menu,
            $: function(e) {
                this.base.call(this, e, {
                    panel: {
                        css: e.config.contextmenu_contentsCss,
                        className: "cke_menu_panel",
                        attributes: {
                            "aria-label": e.lang.contextmenu.options
                        }
                    }
                })
            },
            proto: {
                addTarget: function(e, t) {
                    var n, o;
                    if (e.on("contextmenu", function(e) {
                            var i = e.data,
                                a = CKEDITOR.env.webkit ? n : CKEDITOR.env.mac ? i.$.metaKey : i.$.ctrlKey;
                            if (!(t && a || (i.preventDefault(), o))) {
                                if (CKEDITOR.env.mac && CKEDITOR.env.webkit) {
                                    var c = this.editor,
                                        u = new CKEDITOR.dom.elementPath(i.getTarget(), c.editable()).contains(function(e) {
                                            return e.hasAttribute("contenteditable")
                                        }, !0);
                                    u && "false" == u.getAttribute("contenteditable") && c.getSelection().fake(u)
                                }
                                var l = i.getTarget().getDocument(),
                                    s = i.getTarget().getDocument().getDocumentElement(),
                                    r = !l.equals(CKEDITOR.document),
                                    g = l.getWindow().getScrollPosition(),
                                    d = r ? i.$.clientX : i.$.pageX || g.x + i.$.clientX,
                                    m = r ? i.$.clientY : i.$.pageY || g.y + i.$.clientY;
                                CKEDITOR.tools.setTimeout(function() {
                                    this.open(s, null, d, m)
                                }, CKEDITOR.env.ie ? 200 : 0, this)
                            }
                        }, this), CKEDITOR.env.webkit) {
                        var i = function() {
                            n = 0
                        };
                        e.on("keydown", function(e) {
                            n = CKEDITOR.env.mac ? e.data.$.metaKey : e.data.$.ctrlKey
                        }), e.on("keyup", i), e.on("contextmenu", i)
                    }

                    function a() {
                        o = !1
                    }
                    CKEDITOR.env.gecko && !CKEDITOR.env.mac && (e.on("keydown", function(e) {
                        e.data.$.shiftKey && 121 === e.data.$.keyCode && (o = !0)
                    }, null, null, 0), e.on("keyup", a), e.on("contextmenu", a))
                },
                open: function(e, t, n, o) {
                    !1 !== this.editor.config.enableContextMenu && this.editor.getSelection().getType() !== CKEDITOR.SELECTION_NONE && (this.editor.focus(), e = e || CKEDITOR.document.getDocumentElement(), this.editor.selectionChange(1), this.show(e, t, n, o))
                }
            }
        })
    },
    beforeInit: function(e) {
        var t = e.contextMenu = new CKEDITOR.plugins.contextMenu(e);
        e.on("contentDom", function() {
            t.addTarget(e.editable(), !1 !== e.config.browserContextMenuOnCtrl)
        }), e.addCommand("contextMenu", {
            exec: function(e) {
                var t, n, o = 0,
                    i = 0,
                    a = e.getSelection().getRanges();
                (n = (t = a[a.length - 1].getClientRects(e.editable().isInline()))[t.length - 1]) && (o = n["rtl" === e.lang.dir ? "left" : "right"], i = n.bottom), e.contextMenu.open(e.document.getBody().getParent(), null, o, i)
            }
        }), e.setKeystroke(CKEDITOR.SHIFT + 121, "contextMenu"), e.setKeystroke(CKEDITOR.CTRL + CKEDITOR.SHIFT + 121, "contextMenu")
    }
});