"use strict";
! function() {
    var e = [CKEDITOR.CTRL + 90, CKEDITOR.CTRL + 89, CKEDITOR.CTRL + CKEDITOR.SHIFT + 90],
        t = {
            8: 1,
            46: 1
        };
    CKEDITOR.plugins.add("undo", {
        lang: "en",
        icons: "redo,redo-rtl,undo,undo-rtl",
        hidpi: !0,
        init: function(t) {
            var i = t.undoManager = new n(t),
                s = i.editingHandler = new o(i),
                a = t.addCommand("undo", {
                    exec: function() {
                        i.undo() && (t.selectionChange(), this.fire("afterUndo"))
                    },
                    startDisabled: !0,
                    canUndo: !1
                }),
                r = t.addCommand("redo", {
                    exec: function() {
                        i.redo() && (t.selectionChange(), this.fire("afterRedo"))
                    },
                    startDisabled: !0,
                    canUndo: !1
                });

            function u(e) {
                i.enabled && !1 !== e.data.command.canUndo && i.save()
            }

            function h() {
                i.enabled = !t.readOnly && "wysiwyg" == t.mode, i.onChange()
            }
            t.setKeystroke([
                [e[0], "undo"],
                [e[1], "redo"],
                [e[2], "redo"]
            ]), i.onChange = function() {
                a.setState(i.undoable() ? CKEDITOR.TRISTATE_OFF : CKEDITOR.TRISTATE_DISABLED), r.setState(i.redoable() ? CKEDITOR.TRISTATE_OFF : CKEDITOR.TRISTATE_DISABLED)
            }, t.on("beforeCommandExec", u), t.on("afterCommandExec", u), t.on("saveSnapshot", function(e) {
                i.save(e.data && e.data.contentOnly)
            }), t.on("contentDom", s.attachListeners, s), t.on("instanceReady", function() {
                t.fire("saveSnapshot")
            }), t.on("beforeModeUnload", function() {
                "wysiwyg" == t.mode && i.save(!0)
            }), t.on("mode", h), t.on("readOnly", h), t.ui.addButton && (t.ui.addButton("Undo", {
                label: t.lang.undo.undo,
                command: "undo",
                toolbar: "undo,10"
            }), t.ui.addButton("Redo", {
                label: t.lang.undo.redo,
                command: "redo",
                toolbar: "undo,20"
            })), t.resetUndo = function() {
                i.reset(), t.fire("saveSnapshot")
            }, t.on("updateSnapshot", function() {
                i.currentImage && i.update()
            }), t.on("lockSnapshot", function(e) {
                var t = e.data;
                i.lock(t && t.dontUpdate, t && t.forceUpdate)
            }), t.on("unlockSnapshot", i.unlock, i)
        }
    }), CKEDITOR.plugins.undo = {};
    var n = CKEDITOR.plugins.undo.UndoManager = function(e) {
        this.strokesRecorded = [0, 0], this.locked = null, this.previousKeyGroup = -1, this.limit = e.config.undoStackSize || 20, this.strokesLimit = 25, this.editor = e, this.reset()
    };
    n.prototype = {
        type: function(e, t) {
            var i, s = n.getKeyGroup(e),
                o = this.strokesRecorded[s] + 1;
            t = t || o >= this.strokesLimit, this.typing || ((i = this).typing = !0, i.hasUndo = !0, i.hasRedo = !1, i.onChange()), t ? (o = 0, this.editor.fire("saveSnapshot")) : this.editor.fire("change"), this.strokesRecorded[s] = o, this.previousKeyGroup = s
        },
        keyGroupChanged: function(e) {
            return n.getKeyGroup(e) != this.previousKeyGroup
        },
        reset: function() {
            this.snapshots = [], this.index = -1, this.currentImage = null, this.hasUndo = !1, this.hasRedo = !1, this.locked = null, this.resetType()
        },
        resetType: function() {
            this.strokesRecorded = [0, 0], this.typing = !1, this.previousKeyGroup = -1
        },
        refreshState: function() {
            this.hasUndo = !!this.getNextImage(!0), this.hasRedo = !!this.getNextImage(!1), this.resetType(), this.onChange()
        },
        save: function(e, t, n) {
            var s = this.editor;
            if (this.locked || "ready" != s.status || "wysiwyg" != s.mode) return !1;
            var o = s.editable();
            if (!o || "ready" != o.status) return !1;
            var a = this.snapshots;
            if (t || (t = new i(s)), !1 === t.contents) return !1;
            if (this.currentImage)
                if (t.equalsContent(this.currentImage)) {
                    if (e) return !1;
                    if (t.equalsSelection(this.currentImage)) return !1
                } else !1 !== n && s.fire("change");
            return a.splice(this.index + 1, a.length - this.index - 1), a.length == this.limit && a.shift(), this.index = a.push(t) - 1, this.currentImage = t, !1 !== n && this.refreshState(), !0
        },
        restoreImage: function(e) {
            var t, n = this.editor;
            if (e.bookmarks && (n.focus(), t = n.getSelection()), this.locked = {
                    level: 999
                }, this.editor.loadSnapshot(e.contents), e.bookmarks) t.selectBookmarks(e.bookmarks);
            else if (CKEDITOR.env.ie) {
                var i = this.editor.document.getBody().$.createTextRange();
                i.collapse(!0), i.select()
            }
            this.locked = null, this.index = e.index, this.currentImage = this.snapshots[this.index], this.update(), this.refreshState(), n.fire("change")
        },
        getNextImage: function(e) {
            var t, n, i = this.snapshots,
                s = this.currentImage;
            if (s)
                if (e) {
                    for (n = this.index - 1; n >= 0; n--)
                        if (t = i[n], !s.equalsContent(t)) return t.index = n, t
                } else
                    for (n = this.index + 1; n < i.length; n++)
                        if (t = i[n], !s.equalsContent(t)) return t.index = n, t;
            return null
        },
        redoable: function() {
            return this.enabled && this.hasRedo
        },
        undoable: function() {
            return this.enabled && this.hasUndo
        },
        undo: function() {
            if (this.undoable()) {
                this.save(!0);
                var e = this.getNextImage(!0);
                if (e) return this.restoreImage(e), !0
            }
            return !1
        },
        redo: function() {
            if (this.redoable() && (this.save(!0), this.redoable())) {
                var e = this.getNextImage(!1);
                if (e) return this.restoreImage(e), !0
            }
            return !1
        },
        update: function(e) {
            if (!this.locked) {
                e || (e = new i(this.editor));
                for (var t = this.index, n = this.snapshots; t > 0 && this.currentImage.equalsContent(n[t - 1]);) t -= 1;
                n.splice(t, this.index - t + 1, e), this.index = t, this.currentImage = e
            }
        },
        updateSelection: function(e) {
            if (!this.snapshots.length) return !1;
            var t = this.snapshots,
                n = t[t.length - 1];
            return !(!n.equalsContent(e) || n.equalsSelection(e)) && (t[t.length - 1] = e, this.currentImage = e, !0)
        },
        lock: function(e, t) {
            if (this.locked) this.locked.level++;
            else if (e) this.locked = {
                level: 1
            };
            else {
                var n = null;
                if (t) n = !0;
                else {
                    var s = new i(this.editor, !0);
                    this.currentImage && this.currentImage.equalsContent(s) && (n = s)
                }
                this.locked = {
                    update: n,
                    level: 1
                }
            }
        },
        unlock: function() {
            if (this.locked && !--this.locked.level) {
                var e = this.locked.update;
                if (this.locked = null, !0 === e) this.update();
                else if (e) {
                    var t = new i(this.editor, !0);
                    e.equalsContent(t) || this.update()
                }
            }
        }
    }, n.navigationKeyCodes = {
        37: 1,
        38: 1,
        39: 1,
        40: 1,
        36: 1,
        35: 1,
        33: 1,
        34: 1
    }, n.keyGroups = {
        PRINTABLE: 0,
        FUNCTIONAL: 1
    }, n.isNavigationKey = function(e) {
        return !!n.navigationKeyCodes[e]
    }, n.getKeyGroup = function(e) {
        var i = n.keyGroups;
        return t[e] ? i.FUNCTIONAL : i.PRINTABLE
    }, n.getOppositeKeyGroup = function(e) {
        var t = n.keyGroups;
        return e == t.FUNCTIONAL ? t.PRINTABLE : t.FUNCTIONAL
    }, n.ieFunctionalKeysBug = function(e) {
        return CKEDITOR.env.ie && n.getKeyGroup(e) == n.keyGroups.FUNCTIONAL
    };
    var i = CKEDITOR.plugins.undo.Image = function(e, t) {
            this.editor = e, e.fire("beforeUndoImage");
            var n = e.getSnapshot();
            if (CKEDITOR.env.ie && n && (n = n.replace(/\s+data-cke-expando=".*?"/g, "")), this.contents = n, !t) {
                var i = n && e.getSelection();
                this.bookmarks = i && i.createBookmarks2(!0)
            }
            e.fire("afterUndoImage")
        },
        s = /\b(?:href|src|name)="[^"]*?"/gi;
    i.prototype = {
        equalsContent: function(e) {
            var t = this.contents,
                n = e.contents;
            return CKEDITOR.env.ie && (CKEDITOR.env.ie7Compat || CKEDITOR.env.quirks) && (t = t.replace(s, ""), n = n.replace(s, "")), t == n
        },
        equalsSelection: function(e) {
            var t = this.bookmarks,
                n = e.bookmarks;
            if (t || n) {
                if (!t || !n || t.length != n.length) return !1;
                for (var i = 0; i < t.length; i++) {
                    var s = t[i],
                        o = n[i];
                    if (s.startOffset != o.startOffset || s.endOffset != o.endOffset || !CKEDITOR.tools.arrayCompare(s.start, o.start) || !CKEDITOR.tools.arrayCompare(s.end, o.end)) return !1
                }
            }
            return !0
        }
    };
    var o = CKEDITOR.plugins.undo.NativeEditingHandler = function(e) {
        this.undoManager = e, this.ignoreInputEvent = !1, this.keyEventsStack = new a, this.lastKeydownImage = null
    };
    o.prototype = {
        onKeydown: function(t) {
            var s = t.data.getKey();
            if (229 !== s)
                if (CKEDITOR.tools.indexOf(e, t.data.getKeystroke()) > -1) t.data.preventDefault();
                else {
                    this.keyEventsStack.cleanUp(t);
                    var o = this.undoManager;
                    this.keyEventsStack.getLast(s) || this.keyEventsStack.push(s), this.lastKeydownImage = new i(o.editor), (n.isNavigationKey(s) || this.undoManager.keyGroupChanged(s)) && (o.strokesRecorded[0] || o.strokesRecorded[1]) && (o.save(!1, this.lastKeydownImage, !1), o.resetType())
                }
        },
        onInput: function() {
            if (this.ignoreInputEvent) this.ignoreInputEvent = !1;
            else {
                var e = this.keyEventsStack.getLast();
                e || (e = this.keyEventsStack.push(0)), this.keyEventsStack.increment(e.keyCode), this.keyEventsStack.getTotalInputs() >= this.undoManager.strokesLimit && (this.undoManager.type(e.keyCode, !0), this.keyEventsStack.resetInputs())
            }
        },
        onKeyup: function(e) {
            var t = this.undoManager,
                s = e.data.getKey(),
                o = this.keyEventsStack.getTotalInputs();
            this.keyEventsStack.remove(s), n.ieFunctionalKeysBug(s) && this.lastKeydownImage && this.lastKeydownImage.equalsContent(new i(t.editor, !0)) || (o > 0 ? t.type(s) : n.isNavigationKey(s) && this.onNavigationKey(!0))
        },
        onNavigationKey: function(e) {
            var t = this.undoManager;
            !e && t.save(!0, null, !1) || t.updateSelection(new i(t.editor)), t.resetType()
        },
        ignoreInputEventListener: function() {
            this.ignoreInputEvent = !0
        },
        activateInputEventListener: function() {
            this.ignoreInputEvent = !1
        },
        attachListeners: function() {
            var e = this.undoManager.editor,
                t = e.editable(),
                i = this;
            t.attachListener(t, "keydown", function(e) {
                i.onKeydown(e), n.ieFunctionalKeysBug(e.data.getKey()) && i.onInput()
            }, null, null, 999), t.attachListener(t, CKEDITOR.env.ie ? "keypress" : "input", i.onInput, i, null, 999), t.attachListener(t, "keyup", i.onKeyup, i, null, 999), t.attachListener(t, "paste", i.ignoreInputEventListener, i, null, 999), t.attachListener(t, "drop", i.ignoreInputEventListener, i, null, 999), e.on("afterPaste", i.activateInputEventListener, i, null, 999), t.attachListener(t.isInline() ? t : e.document.getDocumentElement(), "click", function() {
                i.onNavigationKey()
            }, null, null, 999), t.attachListener(this.undoManager.editor, "blur", function() {
                i.keyEventsStack.remove(9)
            }, null, null, 999)
        }
    };
    var a = CKEDITOR.plugins.undo.KeyEventsStack = function() {
        this.stack = []
    };
    a.prototype = {
        push: function(e) {
            var t = this.stack.push({
                keyCode: e,
                inputs: 0
            });
            return this.stack[t - 1]
        },
        getLastIndex: function(e) {
            if ("number" != typeof e) return this.stack.length - 1;
            for (var t = this.stack.length; t--;)
                if (this.stack[t].keyCode == e) return t;
            return -1
        },
        getLast: function(e) {
            var t = this.getLastIndex(e);
            return -1 != t ? this.stack[t] : null
        },
        increment: function(e) {
            var t = this.getLast(e);
            if (!t) throw new Error("Trying to increment, but could not found by keyCode: " + e + ".");
            t.inputs++
        },
        remove: function(e) {
            var t = this.getLastIndex(e); - 1 != t && this.stack.splice(t, 1)
        },
        resetInputs: function(e) {
            if ("number" == typeof e) {
                var t = this.getLast(e);
                if (!t) throw new Error("Trying to reset inputs count, but could not found by keyCode: " + e + ".");
                t.inputs = 0
            } else
                for (var n = this.stack.length; n--;) this.stack[n].inputs = 0
        },
        getTotalInputs: function() {
            for (var e = this.stack.length, t = 0; e--;) t += this.stack[e].inputs;
            return t
        },
        cleanUp: function(e) {
            var t = e.data.$;
            t.ctrlKey || t.metaKey || this.remove(17), t.shiftKey || this.remove(16), t.altKey || this.remove(18)
        }
    }
}();