! function() {
    var e = "nbsp,gt,lt,amp";

    function i(e, i) {
        var a = {},
            r = [],
            t = {
                nbsp: " ",
                shy: "­",
                gt: ">",
                lt: "<",
                amp: "&",
                apos: "'",
                quot: '"'
            };
        if (e = (e = e.replace(/\b(nbsp|shy|gt|lt|amp|apos|quot)(?:,|$)/g, function(e, n) {
                var l = i ? "&" + n + ";" : t[n],
                    u = i ? t[n] : "&" + n + ";";
                return a[l] = u, r.push(l), ""
            })).replace(/,$/, ""), !i && e) {
            e = e.split(",");
            var n, l = document.createElement("div");
            l.innerHTML = "&" + e.join(";&") + ";", n = l.innerHTML, l = null;
            for (var u = 0; u < n.length; u++) {
                var s = n.charAt(u);
                a[s] = "&" + e[u] + ";", r.push(s)
            }
        }
        return a.regex = r.join(i ? "|" : ""), a
    }
    CKEDITOR.plugins.add("entities", {
        afterInit: function(a) {
            var r = a.config;

            function t(e) {
                return p[e]
            }

            function n(e) {
                return "force" != r.entities_processNumerical && c[e] ? c[e] : "&#" + e.charCodeAt(0) + ";"
            }
            var l = a.dataProcessor,
                u = l && l.htmlFilter;
            if (u) {
                var s = [];
                !1 !== r.basicEntities && s.push(e), r.entities && (s.length && s.push("quot,iexcl,cent,pound,curren,yen,brvbar,sect,uml,copy,ordf,laquo,not,shy,reg,macr,deg,plusmn,sup2,sup3,acute,micro,para,middot,cedil,sup1,ordm,raquo,frac14,frac12,frac34,iquest,times,divide,fnof,bull,hellip,prime,Prime,oline,frasl,weierp,image,real,trade,alefsym,larr,uarr,rarr,darr,harr,crarr,lArr,uArr,rArr,dArr,hArr,forall,part,exist,empty,nabla,isin,notin,ni,prod,sum,minus,lowast,radic,prop,infin,ang,and,or,cap,cup,int,there4,sim,cong,asymp,ne,equiv,le,ge,sub,sup,nsub,sube,supe,oplus,otimes,perp,sdot,lceil,rceil,lfloor,rfloor,lang,rang,loz,spades,clubs,hearts,diams,circ,tilde,ensp,emsp,thinsp,zwnj,zwj,lrm,rlm,ndash,mdash,lsquo,rsquo,sbquo,ldquo,rdquo,bdquo,dagger,Dagger,permil,lsaquo,rsaquo,euro"), r.entities_latin && s.push("Agrave,Aacute,Acirc,Atilde,Auml,Aring,AElig,Ccedil,Egrave,Eacute,Ecirc,Euml,Igrave,Iacute,Icirc,Iuml,ETH,Ntilde,Ograve,Oacute,Ocirc,Otilde,Ouml,Oslash,Ugrave,Uacute,Ucirc,Uuml,Yacute,THORN,szlig,agrave,aacute,acirc,atilde,auml,aring,aelig,ccedil,egrave,eacute,ecirc,euml,igrave,iacute,icirc,iuml,eth,ntilde,ograve,oacute,ocirc,otilde,ouml,oslash,ugrave,uacute,ucirc,uuml,yacute,thorn,yuml,OElig,oelig,Scaron,scaron,Yuml"), r.entities_greek && s.push("Alpha,Beta,Gamma,Delta,Epsilon,Zeta,Eta,Theta,Iota,Kappa,Lambda,Mu,Nu,Xi,Omicron,Pi,Rho,Sigma,Tau,Upsilon,Phi,Chi,Psi,Omega,alpha,beta,gamma,delta,epsilon,zeta,eta,theta,iota,kappa,lambda,mu,nu,xi,omicron,pi,rho,sigmaf,sigma,tau,upsilon,phi,chi,psi,omega,thetasym,upsih,piv"), r.entities_additional && s.push(r.entities_additional));
                var c = i(s.join(",")),
                    o = c.regex ? "[" + c.regex + "]" : "a^";
                delete c.regex, r.entities && r.entities_processNumerical && (o = "[^ -~]|" + o), o = new RegExp(o, "g");
                var p = i([e, "shy"].join(","), !0),
                    g = new RegExp(p.regex, "g");
                u.addRules({
                    text: function(e) {
                        return e.replace(g, t).replace(o, n)
                    }
                }, {
                    applyToAll: !0,
                    excludeNestedEditable: !0
                })
            }
        }
    })
}(), CKEDITOR.config.basicEntities = !0, CKEDITOR.config.entities = !0, CKEDITOR.config.entities_latin = !0, CKEDITOR.config.entities_greek = !0, CKEDITOR.config.entities_additional = "#39";