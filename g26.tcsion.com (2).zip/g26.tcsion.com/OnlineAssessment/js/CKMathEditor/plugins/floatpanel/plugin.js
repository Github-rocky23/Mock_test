CKEDITOR.plugins.add("floatpanel", {
        requires: "panel"
    }),
    function() {
        var e = {};
        CKEDITOR.ui.floatPanel = CKEDITOR.tools.createClass({
            $: function(t, i, o, s) {
                o.forceIFrame = 1, o.toolbarRelated && t.elementMode == CKEDITOR.ELEMENT_MODE_INLINE && (i = CKEDITOR.document.getById("cke_" + t.name));
                var n = i.getDocument(),
                    l = function(t, i, o, s, n) {
                        var l = CKEDITOR.tools.genKey(i.getUniqueId(), o.getUniqueId(), t.lang.dir, t.uiColor || "", s.css || "", n || ""),
                            h = e[l];
                        return h || ((h = e[l] = new CKEDITOR.ui.panel(i, s)).element = o.append(CKEDITOR.dom.element.createFromHtml(h.render(t), i)), h.element.setStyles({
                            display: "none",
                            position: "absolute"
                        })), h
                    }(t, n, i, o, s || 0),
                    h = l.element,
                    a = h.getFirst(),
                    r = this;

                function d() {
                    r.hide()
                }
                h.disableContextMenu(), this.element = h, this._ = {
                    editor: t,
                    panel: l,
                    parentElement: i,
                    definition: o,
                    document: n,
                    iframe: a,
                    children: [],
                    dir: t.lang.dir,
                    showBlockParams: null,
                    markFirst: void 0 === o.markFirst || o.markFirst
                }, t.on("mode", d), t.on("resize", d), n.getWindow().on("resize", function() {
                    this.reposition()
                }, this)
            },
            proto: {
                addBlock: function(e, t) {
                    return this._.panel.addBlock(e, t)
                },
                addListBlock: function(e, t) {
                    return this._.panel.addListBlock(e, t)
                },
                getBlock: function(e) {
                    return this._.panel.getBlock(e)
                },
                showBlock: function(e, t, i, o, s, n) {
                    var l = this._.panel,
                        h = l.showBlock(e);
                    this._.showBlockParams = [].slice.call(arguments), this.allowBlur(!1);
                    var a = this._.editor.editable();
                    this._.returnFocus = a.hasFocus ? a : new CKEDITOR.dom.element(CKEDITOR.document.$.activeElement), this._.hideTimeout = 0;
                    var r = this.element,
                        d = this._.iframe,
                        c = CKEDITOR.env.ie && !CKEDITOR.env.edge ? d : new CKEDITOR.dom.window(d.$.contentWindow),
                        u = r.getDocument(),
                        m = this._.parentElement.getPositionedAncestor(),
                        f = t.getDocumentPosition(u),
                        C = m ? m.getDocumentPosition(u) : {
                            x: 0,
                            y: 0
                        },
                        D = "rtl" == this._.dir,
                        v = f.x + (o || 0) - C.x,
                        T = f.y + (s || 0) - C.y;
                    !D || 1 != i && 4 != i ? D || 2 != i && 3 != i || (v += t.$.offsetWidth - 1) : v += t.$.offsetWidth, 3 != i && 4 != i || (T += t.$.offsetHeight - 1), this._.panel._.offsetParentId = t.getId(), r.setStyles({
                        top: T + "px",
                        left: 0,
                        display: ""
                    }), r.setOpacity(0), r.getFirst().removeStyle("width"), this._.editor.focusManager.add(c), this._.blurSet || (CKEDITOR.event.useCapture = !0, c.on("blur", function(e) {
                        function t() {
                            delete this._.returnFocus, this.hide()
                        }
                        this.allowBlur() && e.data.getPhase() == CKEDITOR.EVENT_PHASE_AT_TARGET && this.visible && !this._.activeChild && (CKEDITOR.env.iOS ? this._.hideTimeout || (this._.hideTimeout = CKEDITOR.tools.setTimeout(t, 0, this)) : t.call(this))
                    }, this), c.on("focus", function() {
                        this._.focused = !0, this.hideChild(), this.allowBlur(!0)
                    }, this), CKEDITOR.env.iOS && (c.on("touchstart", function() {
                        clearTimeout(this._.hideTimeout)
                    }, this), c.on("touchend", function() {
                        this._.hideTimeout = 0, this.focus()
                    }, this)), CKEDITOR.event.useCapture = !1, this._.blurSet = 1), l.onEscape = CKEDITOR.tools.bind(function(e) {
                        if (this.onEscape && !1 === this.onEscape(e)) return !1
                    }, this), CKEDITOR.tools.setTimeout(function() {
                        var e = CKEDITOR.tools.bind(function() {
                            var e = r;
                            if (e.removeStyle("width"), h.autoSize) {
                                var t = h.element.getDocument(),
                                    i = (CKEDITOR.env.webkit || CKEDITOR.env.edge ? h.element : t.getBody()).$.scrollWidth;
                                CKEDITOR.env.ie && CKEDITOR.env.quirks && i > 0 && (i += (e.$.offsetWidth || 0) - (e.$.clientWidth || 0) + 3), i += 10, e.setStyle("width", i + "px");
                                var o = h.element.$.scrollHeight;
                                CKEDITOR.env.ie && CKEDITOR.env.quirks && o > 0 && (o += (e.$.offsetHeight || 0) - (e.$.clientHeight || 0) + 3), e.setStyle("height", o + "px"), l._.currentBlock.element.setStyle("display", "none").removeStyle("display")
                            } else e.removeStyle("height");
                            D && (v -= r.$.offsetWidth), r.setStyle("left", v + "px");
                            var s = l.element.getWindow(),
                                a = r.$.getBoundingClientRect(),
                                d = s.getViewPaneSize(),
                                c = a.width || a.right - a.left,
                                u = a.height || a.bottom - a.top,
                                m = D ? a.right : d.width - a.left,
                                f = D ? d.width - a.right : a.left;
                            D ? m < c && (f > c ? v += c : d.width > c ? v -= a.left : v = v - a.right + d.width) : m < c && (f > c ? v -= c : d.width > c ? v = v - a.right + d.width : v -= a.left);
                            var C = d.height - a.top,
                                E = a.top;
                            if (C < u && (E > u ? T -= u : d.height > u ? T = T - a.bottom + d.height : T -= a.top), CKEDITOR.env.ie && !CKEDITOR.env.edge) {
                                var g = new CKEDITOR.dom.element(r.$.offsetParent),
                                    p = g;
                                "html" == p.getName() && (p = p.getDocument().getBody()), "rtl" == p.getComputedStyle("direction") && (CKEDITOR.env.ie8Compat ? v -= 2 * r.getDocument().getDocumentElement().$.scrollLeft : v -= g.$.scrollWidth - g.$.clientWidth)
                            }
                            var I, O = r.getFirst();
                            (I = O.getCustomData("activePanel")) && I.onHide && I.onHide.call(this, 1), O.setCustomData("activePanel", this), r.setStyles({
                                top: T + "px",
                                left: v + "px"
                            }), r.setOpacity(1), n && n()
                        }, this);
                        l.isLoaded ? e() : l.onLoad = e, CKEDITOR.tools.setTimeout(function() {
                            var e = CKEDITOR.env.webkit && CKEDITOR.document.getWindow().getScrollPosition().y;
                            this.focus(), h.element.focus(), CKEDITOR.env.webkit && (CKEDITOR.document.getBody().$.scrollTop = e), this.allowBlur(!0), this._.markFirst && (CKEDITOR.env.ie ? CKEDITOR.tools.setTimeout(function() {
                                h.markFirstDisplayed ? h.markFirstDisplayed() : h._.markFirstDisplayed()
                            }, 0) : h.markFirstDisplayed ? h.markFirstDisplayed() : h._.markFirstDisplayed()), this._.editor.fire("panelShow", this)
                        }, 0, this)
                    }, CKEDITOR.env.air ? 200 : 0, this), this.visible = 1, this.onShow && this.onShow.call(this)
                },
                reposition: function() {
                    var e = this._.showBlockParams;
                    this.visible && this._.showBlockParams && (this.hide(), this.showBlock.apply(this, e))
                },
                focus: function() {
                    if (CKEDITOR.env.webkit) {
                        var e = CKEDITOR.document.getActive();
                        e && !e.equals(this._.iframe) && e.$.blur()
                    }(this._.lastFocused || this._.iframe.getFrameDocument().getWindow()).focus()
                },
                blur: function() {
                    var e = this._.iframe.getFrameDocument().getActive();
                    e && e.is("a") && (this._.lastFocused = e)
                },
                hide: function(e) {
                    if (this.visible && (!this.onHide || !0 !== this.onHide.call(this))) {
                        this.hideChild(), CKEDITOR.env.gecko && this._.iframe.getFrameDocument().$.activeElement.blur(), this.element.setStyle("display", "none"), this.visible = 0, this.element.getFirst().removeCustomData("activePanel");
                        var t = e && this._.returnFocus;
                        t && (CKEDITOR.env.webkit && t.type && t.getWindow().$.focus(), t.focus()), delete this._.lastFocused, this._.showBlockParams = null, this._.editor.fire("panelHide", this)
                    }
                },
                allowBlur: function(e) {
                    var t = this._.panel;
                    return void 0 !== e && (t.allowBlur = e), t.allowBlur
                },
                showAsChild: function(e, t, i, o, s, n) {
                    this._.activeChild == e && e._.panel._.offsetParentId == i.getId() || (this.hideChild(), e.onHide = CKEDITOR.tools.bind(function() {
                        CKEDITOR.tools.setTimeout(function() {
                            this._.focused || this.hide()
                        }, 0, this)
                    }, this), this._.activeChild = e, this._.focused = !1, e.showBlock(t, i, o, s, n), this.blur(), (CKEDITOR.env.ie7Compat || CKEDITOR.env.ie6Compat) && setTimeout(function() {
                        e.element.getChild(0).$.style.cssText += ""
                    }, 100))
                },
                hideChild: function(e) {
                    var t = this._.activeChild;
                    t && (delete t.onHide, delete this._.activeChild, t.hide(), e && this.focus())
                }
            }
        }), CKEDITOR.on("instanceDestroyed", function() {
            var t = CKEDITOR.tools.isEmpty(CKEDITOR.instances);
            for (var i in e) {
                var o = e[i];
                t ? o.destroy() : o.element.hide()
            }
            t && (e = {})
        })
    }();