! function() {
    "use strict";

    function e(e) {
        return e.getName && !e.hasAttribute("data-cke-temp")
    }
    CKEDITOR.plugins.add("widgetselection", {
        init: function(e) {
            if (CKEDITOR.env.webkit) {
                var t = CKEDITOR.plugins.widgetselection;
                e.on("contentDom", function(e) {
                    var i = e.editor,
                        l = i.editable();
                    l.attachListener(l, "keydown", function(e) {
                        e.data.getKeystroke() == CKEDITOR.CTRL + 65 && CKEDITOR.tools.setTimeout(function() {
                            t.addFillers(l) || t.removeFillers(l)
                        }, 0)
                    }, null, null, -1), i.on("selectionCheck", function(e) {
                        t.removeFillers(e.editor.editable())
                    }), i.on("paste", function(e) {
                        e.data.dataValue = t.cleanPasteData(e.data.dataValue)
                    }), "selectall" in i.plugins && t.addSelectAllIntegration(i)
                })
            }
        }
    }), CKEDITOR.plugins.widgetselection = {
        startFiller: null,
        endFiller: null,
        fillerAttribute: "data-cke-filler-webkit",
        fillerContent: "&nbsp;",
        fillerTagName: "div",
        addFillers: function(t) {
            var i = t.editor;
            if (!this.isWholeContentSelected(t) && t.getChildCount() > 0) {
                var l = t.getFirst(e),
                    n = t.getLast(e);
                if (l && l.type == CKEDITOR.NODE_ELEMENT && !l.isEditable() && (this.startFiller = this.createFiller(), t.append(this.startFiller, 1)), n && n.type == CKEDITOR.NODE_ELEMENT && !n.isEditable() && (this.endFiller = this.createFiller(!0), t.append(this.endFiller, 0)), this.hasFiller(t)) {
                    var r = i.createRange();
                    return r.selectNodeContents(t), r.select(), !0
                }
            }
            return !1
        },
        removeFillers: function(e) {
            if (this.hasFiller(e) && !this.isWholeContentSelected(e)) {
                var t = e.findOne(this.fillerTagName + "[" + this.fillerAttribute + "=start]"),
                    i = e.findOne(this.fillerTagName + "[" + this.fillerAttribute + "=end]");
                this.startFiller && t && this.startFiller.equals(t) ? this.removeFiller(this.startFiller, e) : this.startFiller = t, this.endFiller && i && this.endFiller.equals(i) ? this.removeFiller(this.endFiller, e) : this.endFiller = i
            }
        },
        cleanPasteData: function(e) {
            return e && e.length && (e = e.replace(this.createFillerRegex(), "").replace(this.createFillerRegex(!0), "")), e
        },
        isWholeContentSelected: function(e) {
            var t = e.editor.getSelection().getRanges()[0];
            if (t) {
                if (t && t.collapsed) return !1;
                var i = t.clone();
                return i.enlarge(CKEDITOR.ENLARGE_ELEMENT), !!(i && e && i.startContainer && i.endContainer && 0 === i.startOffset && i.endOffset === e.getChildCount() && i.startContainer.equals(e) && i.endContainer.equals(e))
            }
            return !1
        },
        hasFiller: function(e) {
            return e.find(this.fillerTagName + "[" + this.fillerAttribute + "]").count() > 0
        },
        createFiller: function(e) {
            var t = new CKEDITOR.dom.element(this.fillerTagName);
            return t.setHtml(this.fillerContent), t.setAttribute(this.fillerAttribute, e ? "end" : "start"), t.setAttribute("data-cke-temp", 1), t.setStyles({
                display: "block",
                width: 0,
                height: 0,
                padding: 0,
                border: 0,
                margin: 0,
                position: "absolute",
                top: 0,
                left: "-9999px",
                opacity: 0,
                overflow: "hidden"
            }), t
        },
        removeFiller: function(e, t) {
            if (e) {
                var i, l, n, r = t.editor,
                    a = t.editor.getSelection().getRanges()[0].startPath(),
                    s = r.createRange();
                a.contains(e) && (i = e.getHtml(), n = !0), l = "start" == e.getAttribute(this.fillerAttribute), e.remove(), e = null, i && i.length > 0 && i != this.fillerContent ? (t.insertHtmlIntoRange(i, r.getSelection().getRanges()[0]), s.setStartAt(t.getChild(t.getChildCount() - 1), CKEDITOR.POSITION_BEFORE_END), r.getSelection().selectRanges([s])) : n && (l ? s.setStartAt(t.getFirst().getNext(), CKEDITOR.POSITION_AFTER_START) : s.setEndAt(t.getLast().getPrevious(), CKEDITOR.POSITION_BEFORE_END), t.editor.getSelection().selectRanges([s]))
            }
        },
        createFillerRegex: function(e) {
            var t = this.createFiller(e).getOuterHtml().replace(/style="[^"]*"/gi, 'style="[^"]*"').replace(/>[^<]*</gi, ">[^<]*<");
            return new RegExp((e ? "" : "^") + t + (e ? "$" : ""))
        },
        addSelectAllIntegration: function(e) {
            var t = this;
            e.editable().attachListener(e, "beforeCommandExec", function(i) {
                var l = e.editable();
                "selectAll" == i.data.name && l && t.addFillers(l)
            }, null, null, 9999)
        }
    }
}();