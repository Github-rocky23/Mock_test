"use strict";
! function() {
    var e = 15;

    function t(e) {
        var t;
        this.editor = e, this.registered = {}, this.instances = {}, this.selected = [], this.focused = null, this.widgetHoldingFocusedEditable = null, this._ = {
                nextId: 0,
                upcasts: [],
                upcastCallbacks: [],
                filters: {}
            },
            function(e) {
                var t, n, a = e.editor;
                a.on("toHtml", function(n) {
                    var a, r = function(e) {
                        var t = [],
                            n = e._.upcasts,
                            a = e._.upcastCallbacks;
                        return {
                            toBeWrapped: t,
                            iterator: function(e) {
                                var r, s, o, d, l, c;
                                if ("data-cke-widget-wrapper" in e.attributes) return (e = e.getFirst(i.isParserWidgetElement)) && t.push([e]), !1;
                                if ("data-widget" in e.attributes) return t.push([e]), !1;
                                if (l = n.length) {
                                    if (e.attributes["data-cke-widget-upcasted"]) return !1;
                                    for (d = 0, c = a.length; d < c; ++d)
                                        if (!1 === a[d](e)) return;
                                    for (d = 0; d < l; ++d)
                                        if (r = n[d], o = {}, s = r[0](e, o)) return s instanceof CKEDITOR.htmlParser.element && (e = s), e.attributes["data-cke-widget-data"] = encodeURIComponent(JSON.stringify(o)), e.attributes["data-cke-widget-upcasted"] = 1, t.push([e, r[1]]), !1
                                }
                            }
                        }
                    }(e);
                    for (n.data.dataValue.forEach(r.iterator, CKEDITOR.NODE_ELEMENT, !0); a = r.toBeWrapped.pop();) s(a[0]), e.wrapElement(a[0], a[1]);
                    t = n.data.protectedWhitespaces ? 3 == n.data.dataValue.children.length && i.isParserWidgetWrapper(n.data.dataValue.children[1]) : 1 == n.data.dataValue.children.length && i.isParserWidgetWrapper(n.data.dataValue.children[0])
                }, null, null, 8), a.on("dataReady", function() {
                    n && function(e, t) {
                        for (var n, a, r = t.find(".cke_widget_wrapper"), s = 0, o = r.count(); s < o; ++s) n = r.getItem(s), (a = n.getFirst(i.isDomWidgetElement)).type == CKEDITOR.NODE_ELEMENT && a.data("widget") ? (a.replace(n), e.wrapElement(a)) : n.remove()
                    }(e, a.editable()), n = 0, e.destroyAll(!0), e.initOnAll()
                }), a.on("loadSnapshot", function(t) {
                    /data-cke-widget/.test(t.data) && (n = 1), e.destroyAll(!0)
                }, null, null, 9), a.on("paste", function(e) {}), a.on("afterInsertHtml", function(i) {
                    i.data.intoRange ? e.checkWidgets({
                        initOnlyNew: !0
                    }) : (a.fire("lockSnapshot"), e.checkWidgets({
                        initOnlyNew: !0,
                        focusInited: t
                    }), a.fire("unlockSnapshot"))
                })
            }(t = this),
            function(e) {
                var t = e.editor,
                    n = {};
                t.on("toDataFormat", function(t) {
                    var a = CKEDITOR.tools.getNextNumber(),
                        r = [];
                    t.data.downcastingSessionId = a, n[a] = r, t.data.dataValue.forEach(function(t) {
                        var n, a, s = t.attributes;
                        if ("data-cke-widget-white-space" in s) {
                            var o = d(t),
                                c = l(t);
                            o.parent.attributes["data-cke-white-space-first"] && (o.value = o.value.replace(/^&nbsp;/g, " ")), c.parent.attributes["data-cke-white-space-last"] && (c.value = c.value.replace(/&nbsp;$/g, " "))
                        }
                        if ("data-cke-widget-id" in s)(n = e.instances[s["data-cke-widget-id"]]) && (a = t.getFirst(i.isParserWidgetElement), r.push({
                            wrapper: t,
                            element: a,
                            widget: n,
                            editables: {}
                        }), "1" != a.attributes["data-cke-widget-keep-attr"] && delete a.attributes["data-widget"]);
                        else if ("data-cke-widget-editable" in s) return r[r.length - 1].editables[s["data-cke-widget-editable"]] = t, !1
                    }, CKEDITOR.NODE_ELEMENT, !0)
                }, null, null, 8), t.on("toDataFormat", function(e) {
                    if (e.data.downcastingSessionId)
                        for (var t, i, a, r, s, o, d = n[e.data.downcastingSessionId]; t = d.shift();) {
                            for (o in i = t.widget, a = t.element, r = i._.downcastFn && i._.downcastFn.call(i, a), t.editables) delete(s = t.editables[o]).attributes.contenteditable, s.setHtml(i.editables[o].getData());
                            r || (r = a), t.wrapper.replaceWith(r)
                        }
                }, null, null, 13), t.on("contentDomUnload", function() {
                    e.destroyAll(!0)
                })
            }(t), t.on("checkWidgets", r), t.editor.on("contentDomInvalidated", t.checkWidgets, t),
            function(e) {
                var t = e.editor;
                t.on("selectionCheck", function() {
                    e.fire("checkSelection")
                }), e.on("checkSelection", e.checkSelection, e), t.on("selectionChange", function(n) {
                    var a = i.getNestedEditable(t.editable(), n.data.selection.getStartElement()),
                        r = a && e.getByElement(a),
                        s = e.widgetHoldingFocusedEditable;
                    s ? s === r && s.focusedEditable.equals(a) || (h(e, s, null), r && a && h(e, r, a)) : r && a && h(e, r, a)
                }), t.on("dataReady", function() {
                    m(e).commit()
                }), t.on("blur", function() {
                    var t;
                    (t = e.focused) && a(e, t), (t = e.widgetHoldingFocusedEditable) && h(e, t, null)
                })
            }(this),
            function(e) {
                var t = e.editor;
                t.on("contentDom", function() {
                    var n, a, r = t.editable(),
                        s = r.isInline() ? r : t.document;
                    r.attachListener(s, "mousedown", function(r) {
                        var s = r.data.getTarget();
                        if (n = s instanceof CKEDITOR.dom.element ? e.getByElement(s) : null, a = 0, n) {
                            if (n.inline && s.type == CKEDITOR.NODE_ELEMENT && s.hasAttribute("data-cke-widget-drag-handler")) return a = 1, void(e.focused != n && t.getSelection().removeAllRanges());
                            i.getNestedEditable(n.wrapper, s) ? n = null : (r.data.preventDefault(), CKEDITOR.env.ie || n.focus())
                        }
                    }), r.attachListener(s, "mouseup", function() {
                        a && n && n.wrapper && (a = 0, n.focus())
                    }), CKEDITOR.env.ie && r.attachListener(s, "mouseup", function() {
                        setTimeout(function() {
                            n && n.wrapper && r.contains(n.wrapper) && (n.focus(), n = null)
                        })
                    })
                }), t.on("doubleclick", function(t) {
                    var n = e.getByElement(t.data.element);
                    if (n && !i.getNestedEditable(n.wrapper, t.data.element)) return n.fire("doubleclick", {
                        element: t.data.element
                    })
                }, null, null, 1)
            }(this),
            function(e) {
                e.editor.on("key", function(t) {
                    var i, n = e.focused,
                        a = e.widgetHoldingFocusedEditable;
                    return n ? i = n.fire("key", {
                        keyCode: t.data.keyCode
                    }) : a && (i = function(e, t) {
                        var i, n = e.focusedEditable;
                        if (t == CKEDITOR.CTRL + 65) {
                            var a = n.getBogus();
                            return (i = e.editor.createRange()).selectNodeContents(n), a && i.setEndAt(a, CKEDITOR.POSITION_BEFORE_START), i.select(), !1
                        }
                        if (8 == t || 46 == t) {
                            var r = e.editor.getSelection().getRanges();
                            return i = r[0], !(1 == r.length && i.collapsed && i.checkBoundaryOfElement(n, CKEDITOR[8 == t ? "START" : "END"]))
                        }
                    }(a, t.data.keyCode)), i
                }, null, null, 1)
            }(this),
            function(e) {
                var t = e.editor,
                    n = CKEDITOR.plugins.lineutils;
                t.on("dragstart", function(n) {
                    var a = n.data.target;
                    if (i.isDomDragHandler(a)) {
                        var r = e.getByElement(a);
                        n.data.dataTransfer.setData("cke/widget-id", r.id), t.focus(), r.focus()
                    }
                }), t.on("drop", function(i) {
                    var n, a = i.data.dataTransfer,
                        r = a.getData("cke/widget-id"),
                        s = a.getTransferType(t),
                        o = t.createRange();
                    "" === r || s !== CKEDITOR.DATA_TRANSFER_CROSS_EDITORS ? "" !== r && s == CKEDITOR.DATA_TRANSFER_INTERNAL && (n = e.instances[r]) && (o.setStartBefore(n.wrapper), o.setEndAfter(n.wrapper), i.data.dragRange = o, i.data.dataTransfer.setData("text/html", t.editable().getHtmlFromRange(o).getHtml()), t.widgets.destroy(n, !0)) : i.cancel()
                }), t.on("contentDom", function() {
                    var a = t.editable();
                    CKEDITOR.tools.extend(e, {
                        finder: new n.finder(t, {
                            lookups: {
                                default: function(t) {
                                    if (!t.is(CKEDITOR.dtd.$listItem) && t.is(CKEDITOR.dtd.$block) && !i.isDomNestedEditable(t) && !e._.draggedWidget.wrapper.contains(t)) {
                                        var n = i.getNestedEditable(a, t);
                                        if (n) {
                                            var r = e._.draggedWidget;
                                            if (e.getByElement(n) == r) return;
                                            var s = CKEDITOR.filter.instances[n.data("cke-filter")],
                                                o = r.requiredContent;
                                            if (s && o && !s.check(o)) return
                                        }
                                        return CKEDITOR.LINEUTILS_BEFORE | CKEDITOR.LINEUTILS_AFTER
                                    }
                                }
                            }
                        }),
                        locator: new n.locator(t),
                        liner: new n.liner(t, {
                            lineStyle: {
                                cursor: "move !important",
                                "border-top-color": "#666"
                            },
                            tipLeftStyle: {
                                "border-left-color": "#666"
                            },
                            tipRightStyle: {
                                "border-right-color": "#666"
                            }
                        })
                    }, !0)
                })
            }(this),
            function(e) {
                var t = e.editor;

                function i(t) {
                    e.focused && k(e.focused, "cut" == t.name)
                }
                t.on("contentDom", function() {
                    var e = t.editable();
                    e.attachListener(e, "copy", i), e.attachListener(e, "cut", i)
                })
            }(this)
    }

    function i(t, n, a, r, s) {
        var o = t.editor;
        CKEDITOR.tools.extend(this, r, {
                editor: o,
                id: n,
                inline: "span" == a.getParent().getName(),
                element: a,
                data: CKEDITOR.tools.extend({}, "function" == typeof r.defaults ? r.defaults() : r.defaults),
                dataReady: !1,
                inited: !1,
                ready: !1,
                edit: i.prototype.edit,
                focusedEditable: null,
                definition: r,
                repository: t,
                draggable: !1 !== r.draggable,
                _: {
                    downcastFn: r.downcast && "string" == typeof r.downcast ? r.downcasts[r.downcast] : r.downcast
                }
            }, !0), t.fire("instanceCreated", this),
            function(t, n) {
                (function(e) {
                    (e.wrapper = e.element.getParent()).setAttribute("data-cke-widget-id", e.id)
                })(t),
                function(e) {
                    if (e.parts) {
                        var t, i, n = {};
                        for (i in e.parts) t = e.wrapper.findOne(e.parts[i]), n[i] = t;
                        e.parts = n
                    }
                }(t),
                function(e) {
                    var t, i, n = e.editables;
                    if (e.editables = {}, e.editables)
                        for (t in n) i = n[t], e.initEditable(t, "string" == typeof i ? {
                            selector: i
                        } : i)
                }(t),
                function(e) {
                    if (e.mask) {
                        var t = e.wrapper.findOne(".cke_widget_mask");
                        t || ((t = new CKEDITOR.dom.element("img", e.editor.document)).setAttributes({
                            src: CKEDITOR.tools.transparentImageData,
                            class: "cke_reset cke_widget_mask"
                        }), e.wrapper.append(t)), e.mask = t
                    }
                }(t),
                function(t) {
                    if (t.draggable) {
                        var n, a = t.editor,
                            r = t.wrapper.getLast(i.isDomDragHandlerContainer);
                        r ? n = r.findOne("img") : ((r = new CKEDITOR.dom.element("span", a.document)).setAttributes({
                            class: "cke_reset cke_widget_drag_handler_container",
                            style: "background:rgba(220,220,220,0.5);background-image:url(" + a.plugins.widget.path + "images/handle.png)"
                        }), (n = new CKEDITOR.dom.element("img", a.document)).setAttributes({
                            class: "cke_reset cke_widget_drag_handler",
                            "data-cke-widget-drag-handler": "1",
                            src: CKEDITOR.tools.transparentImageData,
                            width: e,
                            title: a.lang.widget.move,
                            height: e,
                            role: "presentation"
                        }), t.inline && n.setAttribute("draggable", "true"), r.append(n), t.wrapper.append(r)), t.wrapper.on("dragover", function(e) {
                            e.data.preventDefault()
                        }), t.wrapper.on("mouseenter", t.updateDragHandlerPosition, t), setTimeout(function() {
                            t.on("data", t.updateDragHandlerPosition, t)
                        }, 50), t.inline || (n.on("mousedown", _, t), CKEDITOR.env.ie && CKEDITOR.env.version < 9 && n.on("dragstart", function(e) {
                            e.data.preventDefault(!0)
                        })), t.dragHandlerContainer = r
                    }
                }(t),
                function(e) {
                    var t = null;
                    e.on("data", function() {
                        var e, i = this.data.classes;
                        if (t != i) {
                            for (e in t) i && i[e] || this.removeClass(e);
                            for (e in i) this.addClass(e);
                            t = i
                        }
                    })
                }(t),
                function(e) {
                    e.on("data", function() {
                        if (e.wrapper) {
                            var t = this.getLabel ? this.getLabel() : function() {
                                return this.editor.lang.widget.label.replace(/%1/, this.pathName || this.element.getName())
                            }.call(this);
                            e.wrapper.setAttribute("role", "region"), e.wrapper.setAttribute("aria-label", t)
                        }
                    }, null, null, 9999)
                }(t), CKEDITOR.env.ie && CKEDITOR.env.version < 9 && t.wrapper.on("dragstart", function(e) {
                    var n = e.data.getTarget();
                    i.getNestedEditable(t, n) || t.inline && i.isDomDragHandler(n) || e.data.preventDefault()
                });
                t.wrapper.removeClass("cke_widget_new"), t.element.addClass("cke_widget_element"), t.on("key", function(e) {
                    var i = e.data.keyCode;
                    if (13 == i) t.edit();
                    else {
                        if (i == CKEDITOR.CTRL + 67 || i == CKEDITOR.CTRL + 88) return void k(t, i == CKEDITOR.CTRL + 88);
                        if (i in E || CKEDITOR.CTRL & i || CKEDITOR.ALT & i) return
                    }
                    return !1
                }, null, null, 999), t.on("doubleclick", function(e) {
                    t.edit() && e.cancel()
                }), n.data && t.on("data", n.data);
                n.edit && t.on("edit", n.edit)
            }(this, r), this.init && this.init(), this.inited = !0,
            function(e, t) {
                var i = e.element.data("cke-widget-data");
                i && e.setData(JSON.parse(decodeURIComponent(i)));
                t && e.setData(t);
                e.data.classes || e.setData("classes", e.getClasses());
                e.dataReady = !0, y(e), e.fire("data", e.data)
            }(this, s), this.isInited() && o.editable().contains(this.wrapper) && (this.ready = !0, this.fire("ready"))
    }

    function n(e, t, i) {
        CKEDITOR.dom.element.call(this, t.$), this.editor = e, this._ = {};
        var n = this.filter = i.filter;
        CKEDITOR.dtd[this.getName()].p ? (this.enterMode = n ? n.getAllowedEnterMode(e.enterMode) : e.enterMode, this.shiftEnterMode = n ? n.getAllowedEnterMode(e.shiftEnterMode, !0) : e.shiftEnterMode) : this.enterMode = this.shiftEnterMode = CKEDITOR.ENTER_BR
    }

    function a(e, t) {
        if (e.focused = null, t.isInited()) {
            var i = t.editor.checkDirty();
            e.fire("widgetBlurred", {
                widget: t
            }), t.setFocused(!1), !i && t.editor.resetDirty()
        }
    }

    function r(e) {
        var t = e.data;
        if ("wysiwyg" == this.editor.mode) {
            var n, a, r, s, o = this.editor.editable(),
                d = this.instances;
            if (o) {
                for (a in d) d[a].isReady() && !o.contains(d[a].wrapper) && this.destroy(d[a], !0);
                if (t && t.initOnlyNew) n = this.initOnAll();
                else {
                    var l = o.find(".cke_widget_wrapper");
                    for (n = [], a = 0, r = l.count(); a < r; a++) s = l.getItem(a), !this.getByElement(s, !0) && !u(s, g) && o.contains(s) && (s.addClass("cke_widget_new"), n.push(this.initOn(s.getFirst(i.isDomWidgetElement))))
                }
                t && t.focusInited && 1 == n.length && n[0].focus()
            }
        }
    }

    function s(e) {
        var t = e.parent;
        t.type == CKEDITOR.NODE_ELEMENT && t.attributes["data-cke-widget-wrapper"] && t.replaceWith(e)
    }

    function o(e) {
        if (void 0 !== e.attributes && e.attributes["data-widget"]) {
            var t = d(e),
                i = l(e),
                n = !1;
            t && t.value && t.value.match(/^\s/g) && (t.parent.attributes["data-cke-white-space-first"] = 1, t.value = t.value.replace(/^\s/g, "&nbsp;"), n = !0), i && i.value && i.value.match(/\s$/g) && (i.parent.attributes["data-cke-white-space-last"] = 1, i.value = i.value.replace(/\s$/g, "&nbsp;"), n = !0), n && (e.attributes["data-cke-widget-white-space"] = 1)
        }
    }

    function d(e) {
        return e.find(function(e) {
            return 3 === e.type
        }, !0).shift()
    }

    function l(e) {
        return e.find(function(e) {
            return 3 === e.type
        }, !0).pop()
    }

    function c(e, t, i) {
        if (!i.allowedContent && !i.disallowedContent) return null;
        var n = this._.filters[e];
        n || (this._.filters[e] = n = {});
        var a = n[t];
        return a || (a = i.allowedContent ? new CKEDITOR.filter(i.allowedContent) : this.editor.filter.clone(), n[t] = a, i.disallowedContent && a.disallow(i.disallowedContent)), a
    }

    function u(e, t) {
        for (var i = e; i = i.getParent();)
            if (t(i)) return !0;
        return !1
    }

    function f(e, t) {
        return {
            tabindex: -1,
            contenteditable: "false",
            "data-cke-widget-wrapper": 1,
            "data-cke-filter": "off",
            class: "cke_widget_wrapper cke_widget_new cke_widget_" + (e ? "inline" : "block") + (t ? " cke_widget_" + t : "")
        }
    }

    function p(e, t) {
        return "boolean" == typeof e.inline ? e.inline : !!CKEDITOR.dtd.$inline[t]
    }

    function g(e) {
        return e.hasAttribute("data-cke-temp")
    }

    function h(e, t, i, n) {
        var a = e.editor;
        if (a.fire("lockSnapshot"), i) {
            var r = i.data("cke-widget-editable"),
                s = t.editables[r];
            e.widgetHoldingFocusedEditable = t, t.focusedEditable = s, i.addClass("cke_widget_editable_focused"), s.filter && a.setActiveFilter(s.filter), a.setActiveEnterMode(s.enterMode, s.shiftEnterMode)
        } else n || t.focusedEditable.removeClass("cke_widget_editable_focused"), t.focusedEditable = null, e.widgetHoldingFocusedEditable = null, a.setActiveFilter(null), a.setActiveEnterMode(null, null);
        a.fire("unlockSnapshot")
    }
    CKEDITOR.plugins.add("widget", {
        lang: "af,ar,az,bg,ca,cs,cy,da,de,de-ch,el,en,en-au,en-gb,eo,es,es-mx,et,eu,fa,fi,fr,gl,he,hr,hu,id,it,ja,km,ko,ku,lv,nb,nl,no,oc,pl,pt,pt-br,ro,ru,sk,sl,sq,sv,tr,tt,ug,uk,vi,zh,zh-cn",
        requires: "lineutils,widgetselection",
        onLoad: function() {
            void 0 !== CKEDITOR.document.$.querySelectorAll && (CKEDITOR.addCss(".cke_widget_wrapper{position:relative;outline:none}.cke_widget_inline{display:inline-block}.cke_widget_wrapper:hover>.cke_widget_element{outline:2px solid #ffd25c;cursor:default}.cke_widget_wrapper:hover .cke_widget_editable{outline:2px solid #ffd25c}.cke_widget_wrapper.cke_widget_focused>.cke_widget_element,.cke_widget_wrapper .cke_widget_editable.cke_widget_editable_focused{outline:2px solid #47a4f5}.cke_widget_editable{cursor:text}.cke_widget_drag_handler_container{position:absolute;width:" + e + "px;height:0;display:none;opacity:0.75;transition:height 0s 0.2s;line-height:0}.cke_widget_wrapper:hover>.cke_widget_drag_handler_container{height:" + e + "px;transition:none}.cke_widget_drag_handler_container:hover{opacity:1}img.cke_widget_drag_handler{cursor:move;width:" + e + "px;height:" + e + "px;display:inline-block}.cke_widget_mask{position:absolute;top:0;left:0;width:100%;height:100%;display:block}.cke_editable.cke_widget_dragging, .cke_editable.cke_widget_dragging *{cursor:move !important}"), function() {
                var e = {};

                function t() {}

                function n(e, t, i) {
                    if (!i) return !1;
                    if (!this.checkElement(e)) return !1;
                    var n = i.widgets.getByElement(e, !0);
                    return n && n.checkStyleActive(this)
                }
                CKEDITOR.style.addCustomHandler({
                    type: "widget",
                    setup: function(t) {
                        this.widget = t.widget, this.group = "string" == typeof t.group ? [t.group] : t.group, this.group && function(t) {
                            var i, n = t.widget;
                            e[n] || (e[n] = {});
                            for (var a = 0, r = t.group.length; a < r; a++) i = t.group[a], e[n][i] || (e[n][i] = []), e[n][i].push(t)
                        }(this)
                    },
                    apply: function(e) {
                        var t;
                        e instanceof CKEDITOR.editor && this.checkApplicable(e.elementPath(), e) && (t = e.widgets.focused, this.group && this.removeStylesFromSameGroup(e), t.applyStyle(this))
                    },
                    remove: function(e) {
                        e instanceof CKEDITOR.editor && this.checkApplicable(e.elementPath(), e) && e.widgets.focused.removeStyle(this)
                    },
                    removeStylesFromSameGroup: function(t) {
                        var i, n, a = !1;
                        if (!(t instanceof CKEDITOR.editor)) return !1;
                        if (n = t.elementPath(), this.checkApplicable(n, t))
                            for (var r = 0, s = this.group.length; r < s; r++) {
                                i = e[this.widget][this.group[r]];
                                for (var o = 0; o < i.length; o++) i[o] !== this && i[o].checkActive(n, t) && (t.widgets.focused.removeStyle(i[o]), a = !0)
                            }
                        return a
                    },
                    checkActive: function(e, t) {
                        return this.checkElementMatch(e.lastElement, 0, t)
                    },
                    checkApplicable: function(e, t) {
                        return t instanceof CKEDITOR.editor && this.checkElement(e.lastElement)
                    },
                    checkElementMatch: n,
                    checkElementRemovable: n,
                    checkElement: function(e) {
                        if (!i.isDomWidgetWrapper(e)) return !1;
                        var t = e.getFirst(i.isDomWidgetElement);
                        return t && t.data("widget") == this.widget
                    },
                    buildPreview: function(e) {
                        return e || this._.definition.name
                    },
                    toAllowedContentRules: function(e) {
                        if (!e) return null;
                        var t, i = e.widgets.registered[this.widget],
                            n = {};
                        return i ? i.styleableElements ? (t = this.getClassesArray()) ? (n[i.styleableElements] = {
                            classes: t,
                            propertiesOnly: !0
                        }, n) : null : i.styleToAllowedContentRules ? i.styleToAllowedContentRules(this) : null : null
                    },
                    getClassesArray: function() {
                        var e = this._.definition.attributes && this._.definition.attributes.class;
                        return e ? CKEDITOR.tools.trim(e).split(/\s+/) : null
                    },
                    applyToRange: t,
                    removeFromRange: t,
                    applyToObject: t
                })
            }())
        },
        beforeInit: function(e) {
            void 0 !== CKEDITOR.document.$.querySelectorAll && (e.widgets = new t(e))
        },
        afterInit: function(e) {
            void 0 !== CKEDITOR.document.$.querySelectorAll && (function(e) {
                var t, i, n, a = e.widgets.registered;
                for (i in a) t = a[i], (n = t.button) && e.ui.addButton && e.ui.addButton(CKEDITOR.tools.capitalize(t.name, !0), {
                    label: n,
                    command: t.name,
                    toolbar: "insert,10"
                })
            }(e), function(e) {
                if (!e.contextMenu) return;
                e.contextMenu.addListener(function(t) {
                    var i = e.widgets.getByElement(t, !0);
                    if (i) return i.fire("contextMenu", {})
                })
            }(e))
        }
    }), t.prototype = {
        MIN_SELECTION_CHECK_INTERVAL: 500,
        add: function(e, t) {
            return (t = CKEDITOR.tools.prototypedCopy(t)).name = e, t._ = t._ || {}, this.editor.fire("widgetDefinition", t), t.template && (t.template = new CKEDITOR.template(t.template)),
                function(e, t) {
                    e.addCommand(t.name, {
                        exec: function(e, i) {
                            var n = e.widgets.focused;
                            if (n && n.name == t.name) n.edit();
                            else if (t.insert) t.insert({
                                editor: e,
                                commandData: i
                            });
                            else if (t.template) {
                                var a, r = "function" == typeof t.defaults ? t.defaults() : t.defaults,
                                    s = CKEDITOR.dom.element.createFromHtml(t.template.output(r)),
                                    o = e.widgets.wrapElement(s, t.name),
                                    d = new CKEDITOR.dom.documentFragment(o.getDocument());
                                if (d.append(o), !(a = e.widgets.initOn(s, t, i && i.startupData))) return void c();
                                var l = a.once("edit", function(t) {
                                    t.data.dialog ? a.once("dialog", function(t) {
                                        var i, n, r = t.data;
                                        i = r.once("ok", c, null, null, 20), n = r.once("cancel", function(t) {
                                            t.data && !1 === t.data.hide || e.widgets.destroy(a, !0)
                                        }), r.once("hide", function() {
                                            i.removeListener(), n.removeListener()
                                        })
                                    }) : c()
                                }, null, null, 999);
                                a.edit(), l.removeListener()
                            }

                            function c() {
                                e.widgets.finalizeCreation(d)
                            }
                        },
                        allowedContent: t.allowedContent,
                        requiredContent: t.requiredContent,
                        contentForms: t.contentForms,
                        contentTransformations: t.contentTransformations
                    })
                }(this.editor, t),
                function(e, t) {
                    var i = t.upcast,
                        n = t.upcastPriority || 10;
                    if (!i) return;
                    a("string" == typeof i ? function(e, i) {
                        var n, a, r = t.upcast.split(",");
                        for (a = 0; a < r.length; a++)
                            if ((n = r[a]) === e.name) return t.upcasts[n].call(this, e, i);
                        return !1
                    } : i, t, n);

                    function a(t, i, n) {
                        var a = CKEDITOR.tools.getIndex(e._.upcasts, function(e) {
                            return e[2] > n
                        });
                        a < 0 && (a = e._.upcasts.length), e._.upcasts.splice(a, 0, [CKEDITOR.tools.bind(t, i), i.name, n])
                    }
                }(this, t), this.registered[e] = t, t
        },
        addUpcastCallback: function(e) {
            this._.upcastCallbacks.push(e)
        },
        checkSelection: function() {
            var e, t = this.editor.getSelection(),
                n = t.getSelectedElement(),
                a = m(this);
            if (n && (e = this.getByElement(n, !0))) return a.focus(e).select(e).commit();
            var r = t.getRanges()[0];
            if (!r || r.collapsed) return a.commit();
            var s, o = new CKEDITOR.dom.walker(r);
            for (o.evaluator = i.isDomWidgetWrapper; s = o.next();) a.select(this.getByElement(s));
            a.commit()
        },
        checkWidgets: function(e) {
            this.fire("checkWidgets", CKEDITOR.tools.copy(e || {}))
        },
        del: function(e) {
            if (this.focused === e) {
                var t, i = e.editor,
                    n = i.createRange();
                (t = n.moveToClosestEditablePosition(e.wrapper, !0)) || (t = n.moveToClosestEditablePosition(e.wrapper, !1)), t && i.getSelection().selectRanges([n])
            }
            e.wrapper.remove(), this.destroy(e, !0)
        },
        destroy: function(e, t) {
            this.widgetHoldingFocusedEditable === e && h(this, e, null, t), e.destroy(t), delete this.instances[e.id], this.fire("instanceDestroyed", e)
        },
        destroyAll: function(e, t) {
            var i, n, a = this.instances;
            if (!t || e)
                for (n in a) i = a[n], this.destroy(i, e);
            else
                for (var r = t.find(".cke_widget_wrapper"), s = r.count(), o = 0; o < s; ++o)(i = this.getByElement(r.getItem(o), !0)) && this.destroy(i)
        },
        finalizeCreation: function(e) {
            var t = e.getFirst();
            if (t && i.isDomWidgetWrapper(t)) {
                this.editor.insertElement(t);
                var n = this.getByElement(t);
                n.ready = !0, n.fire("ready"), n.focus()
            }
        },
        getByElement: function() {
            var e = {
                div: 1,
                span: 1
            };

            function t(t) {
                return t.is(e) && t.data("cke-widget-id")
            }
            return function(e, i) {
                if (!e) return null;
                var n = t(e);
                if (!i && !n) {
                    var a = this.editor.editable();
                    do {
                        e = e.getParent()
                    } while (e && !e.equals(a) && !(n = t(e)))
                }
                return this.instances[n] || null
            }
        }(),
        initOn: function(e, t, n) {
            if (t ? "string" == typeof t && (t = this.registered[t]) : t = this.registered[e.data("widget")], !t) return null;
            var a = this.wrapElement(e, t.name);
            if (a) {
                if (a.hasClass("cke_widget_new")) {
                    var r = new i(this, this._.nextId++, e, t, n);
                    return r.isInited() ? (this.instances[r.id] = r, r) : null
                }
                return this.getByElement(e)
            }
            return null
        },
        initOnAll: function(e) {
            for (var t, n = (e || this.editor.editable()).find(".cke_widget_new"), a = [], r = n.count(); r--;)(t = this.initOn(n.getItem(r).getFirst(i.isDomWidgetElement))) && a.push(t);
            return a
        },
        onWidget: function(e) {
            var t = Array.prototype.slice.call(arguments);
            for (var i in t.shift(), this.instances) {
                var n = this.instances[i];
                n.name == e && n.on.apply(n, t)
            }
            this.on("instanceCreated", function(i) {
                var n = i.data;
                n.name == e && n.on.apply(n, t)
            })
        },
        parseElementClasses: function(e) {
            if (!e) return null;
            e = CKEDITOR.tools.trim(e).split(/\s+/);
            for (var t, i = {}, n = 0; t = e.pop();) - 1 == t.indexOf("cke_") && (i[t] = n = 1);
            return n ? i : null
        },
        wrapElement: function(e, t) {
            var i, n, a = null;
            if (e instanceof CKEDITOR.dom.element) {
                if (t = t || e.data("widget"), !(i = this.registered[t])) return null;
                if ((a = e.getParent()) && a.type == CKEDITOR.NODE_ELEMENT && a.data("cke-widget-wrapper")) return a;
                e.hasAttribute("data-cke-widget-keep-attr") || e.data("cke-widget-keep-attr", e.data("widget") ? 1 : 0), e.data("widget", t), (n = p(i, e.getName())) && o(e), (a = new CKEDITOR.dom.element(n ? "span" : "div")).setAttributes(f(n, t)), a.data("cke-display-name", i.pathName ? i.pathName : e.getName()), e.getParent(!0) && a.replace(e), e.appendTo(a)
            } else if (e instanceof CKEDITOR.htmlParser.element) {
                if (t = t || e.attributes["data-widget"], !(i = this.registered[t])) return null;
                if ((a = e.parent) && a.type == CKEDITOR.NODE_ELEMENT && a.attributes["data-cke-widget-wrapper"]) return a;
                "data-cke-widget-keep-attr" in e.attributes || (e.attributes["data-cke-widget-keep-attr"] = e.attributes["data-widget"] ? 1 : 0), t && (e.attributes["data-widget"] = t), (n = p(i, e.name)) && o(e), (a = new CKEDITOR.htmlParser.element(n ? "span" : "div", f(n, t))).attributes["data-cke-display-name"] = i.pathName ? i.pathName : e.name;
                var r, s = e.parent;
                s && (r = e.getIndex(), e.remove()), a.add(e), s && function e(t, i, n) {
                    if (t.type == CKEDITOR.NODE_ELEMENT) {
                        var a = CKEDITOR.dtd[t.name];
                        if (a && !a[n.name]) {
                            var r = t.split(i),
                                s = t.parent;
                            return i = r.getIndex(), t.children.length || (i -= 1, t.remove()), r.children.length || r.remove(), e(s, i, n)
                        }
                    }
                    t.add(n, i)
                }(s, r, a)
            }
            return a
        },
        _tests_createEditableFilter: c
    }, CKEDITOR.event.implementOn(t.prototype), i.prototype = {
        addClass: function(e) {
            this.element.addClass(e), this.wrapper.addClass(i.WRAPPER_CLASS_PREFIX + e)
        },
        applyStyle: function(e) {
            w(this, e, 1)
        },
        checkStyleActive: function(e) {
            var t, i = b(e);
            if (!i) return !1;
            for (; t = i.pop();)
                if (!this.hasClass(t)) return !1;
            return !0
        },
        destroy: function(e) {
            if (this.fire("destroy"), this.editables)
                for (var t in this.editables) this.destroyEditable(t, e);
            e || ("0" == this.element.data("cke-widget-keep-attr") && this.element.removeAttribute("data-widget"), this.element.removeAttributes(["data-cke-widget-data", "data-cke-widget-keep-attr"]), this.element.removeClass("cke_widget_element"), this.element.replace(this.wrapper)), this.wrapper = null
        },
        destroyEditable: function(e, t) {
            var i = this.editables[e],
                n = !0;
            if (i.removeListener("focus", D), i.removeListener("blur", C), this.editor.focusManager.remove(i), i.filter) {
                for (var a in this.repository.instances) {
                    var r = this.repository.instances[a];
                    if (r.editables) {
                        var s = r.editables[e];
                        s && s !== i && i.filter === s.filter && (n = !1)
                    }
                }
                if (n) {
                    i.filter.destroy();
                    var o = this.repository._.filters[this.name];
                    o && delete o[e]
                }
            }
            t || (this.repository.destroyAll(!1, i), i.removeClass("cke_widget_editable"), i.removeClass("cke_widget_editable_focused"), i.removeAttributes(["contenteditable", "data-cke-widget-editable", "data-cke-enter-mode"])), delete this.editables[e]
        },
        edit: function() {
            var e = {
                    dialog: this.dialog
                },
                t = this;
            return !(!1 === this.fire("edit", e) || !e.dialog) && (this.editor.openDialog(e.dialog, function(e) {
                var i, n;
                !1 !== t.fire("dialog", e) && (i = e.on("show", function() {
                    e.setupContent(t)
                }), n = e.on("ok", function() {
                    var i, n = t.on("data", function(e) {
                        i = 1, e.cancel()
                    }, null, null, 0);
                    t.editor.fire("saveSnapshot"), e.commitContent(t), n.removeListener(), i && (t.fire("data", t.data), t.editor.fire("saveSnapshot"))
                }), e.once("hide", function() {
                    i.removeListener(), n.removeListener()
                }))
            }), !0)
        },
        getClasses: function() {
            return this.repository.parseElementClasses(this.element.getAttribute("class"))
        },
        hasClass: function(e) {
            return this.element.hasClass(e)
        },
        initEditable: function(e, t) {
            var i = this._findOneNotNested(t.selector);
            return !(!i || !i.is(CKEDITOR.dtd.$editable)) && (i = new n(this.editor, i, {
                filter: c.call(this.repository, this.name, e, t)
            }), this.editables[e] = i, i.setAttributes({
                contenteditable: "true",
                "data-cke-widget-editable": e,
                "data-cke-enter-mode": i.enterMode
            }), i.filter && i.data("cke-filter", i.filter.id), i.addClass("cke_widget_editable"), i.removeClass("cke_widget_editable_focused"), t.pathName && i.data("cke-display-name", t.pathName), this.editor.focusManager.add(i), i.on("focus", D, this), CKEDITOR.env.ie && i.on("blur", C, this), i._.initialSetData = !0, i.setData(i.getHtml()), !0)
        },
        _findOneNotNested: function(e) {
            for (var t, n, a = this.wrapper.find(e), r = 0; r < a.count(); r++)
                if (n = (t = a.getItem(r)).getAscendant(i.isDomWidgetWrapper), this.wrapper.equals(n)) return t;
            return null
        },
        isInited: function() {
            return !(!this.wrapper || !this.inited)
        },
        isReady: function() {
            return this.isInited() && this.ready
        },
        focus: function() {
            var e = this.editor.getSelection();
            if (e) {
                var t = this.editor.checkDirty();
                e.fake(this.wrapper), !t && this.editor.resetDirty()
            }
            this.editor.focus()
        },
        removeClass: function(e) {
            this.element.removeClass(e), this.wrapper.removeClass(i.WRAPPER_CLASS_PREFIX + e)
        },
        removeStyle: function(e) {
            w(this, e, 0)
        },
        setData: function(e, t) {
            var i = this.data,
                n = 0;
            if ("string" == typeof e) i[e] !== t && (i[e] = t, n = 1);
            else {
                var a = e;
                for (e in a) i[e] !== a[e] && (n = 1, i[e] = a[e])
            }
            return n && this.dataReady && (y(this), this.fire("data", i)), this
        },
        setFocused: function(e) {
            return this.wrapper[e ? "addClass" : "removeClass"]("cke_widget_focused"), this.fire(e ? "focus" : "blur"), this
        },
        setSelected: function(e) {
            return this.wrapper[e ? "addClass" : "removeClass"]("cke_widget_selected"), this.fire(e ? "select" : "deselect"), this
        },
        updateDragHandlerPosition: function() {
            var t = this.editor,
                i = this.element.$,
                n = this._.dragHandlerOffset,
                a = {
                    x: i.offsetLeft,
                    y: i.offsetTop - e
                };
            if (!n || a.x != n.x || a.y != n.y) {
                var r = t.checkDirty();
                t.fire("lockSnapshot"), this.dragHandlerContainer.setStyles({
                    top: a.y + "px",
                    left: a.x + "px",
                    display: "block"
                }), t.fire("unlockSnapshot"), !r && t.resetDirty(), this._.dragHandlerOffset = a
            }
        }
    }, CKEDITOR.event.implementOn(i.prototype), i.getNestedEditable = function(e, t) {
        return !t || t.equals(e) ? null : i.isDomNestedEditable(t) ? t : i.getNestedEditable(e, t.getParent())
    }, i.isDomDragHandler = function(e) {
        return e.type == CKEDITOR.NODE_ELEMENT && e.hasAttribute("data-cke-widget-drag-handler")
    }, i.isDomDragHandlerContainer = function(e) {
        return e.type == CKEDITOR.NODE_ELEMENT && e.hasClass("cke_widget_drag_handler_container")
    }, i.isDomNestedEditable = function(e) {
        return e.type == CKEDITOR.NODE_ELEMENT && e.hasAttribute("data-cke-widget-editable")
    }, i.isDomWidgetElement = function(e) {
        return e.type == CKEDITOR.NODE_ELEMENT && e.hasAttribute("data-widget")
    }, i.isDomWidgetWrapper = function(e) {
        return e.type == CKEDITOR.NODE_ELEMENT && e.hasAttribute("data-cke-widget-wrapper")
    }, i.isDomWidget = function(e) {
        return !!e && (this.isDomWidgetWrapper(e) || this.isDomWidgetElement(e))
    }, i.isParserWidgetElement = function(e) {
        return e.type == CKEDITOR.NODE_ELEMENT && !!e.attributes["data-widget"]
    }, i.isParserWidgetWrapper = function(e) {
        return e.type == CKEDITOR.NODE_ELEMENT && !!e.attributes["data-cke-widget-wrapper"]
    }, i.WRAPPER_CLASS_PREFIX = "cke_widget_wrapper_", n.prototype = CKEDITOR.tools.extend(CKEDITOR.tools.prototypedCopy(CKEDITOR.dom.element.prototype), {
        setData: function(e) {
            this._.initialSetData || this.editor.widgets.destroyAll(!1, this), this._.initialSetData = !1, e = this.editor.dataProcessor.toHtml(e, {
                context: this.getName(),
                filter: this.filter,
                enterMode: this.enterMode
            }), this.setHtml(e), this.editor.widgets.initOnAll(this)
        },
        getData: function() {
            return this.editor.dataProcessor.toDataFormat(this.getHtml(), {
                context: this.getName(),
                filter: this.filter,
                enterMode: this.enterMode
            })
        }
    });
    new RegExp('^(?:<(?:div|span)(?: data-cke-temp="1")?(?: id="cke_copybin")?(?: data-cke-temp="1")?>)?(?:<(?:div|span)(?: style="[^"]+")?>)?<span [^>]*data-cke-copybin-start="1"[^>]*>.?</span>([\\s\\S]+)<span [^>]*data-cke-copybin-end="1"[^>]*>.?</span>(?:</(?:div|span)>)?(?:</(?:div|span)>)?$', "i");

    function m(e) {
        var t = e.selected,
            i = [],
            n = t.slice(0),
            r = null;
        return {
            select: function(e) {
                CKEDITOR.tools.indexOf(t, e) < 0 && i.push(e);
                var a = CKEDITOR.tools.indexOf(n, e);
                return a >= 0 && n.splice(a, 1), this
            },
            focus: function(e) {
                return r = e, this
            },
            commit: function() {
                var s, o, d = e.focused !== r;
                for (e.editor.fire("lockSnapshot"), d && (s = e.focused) && a(e, s); s = n.pop();) t.splice(CKEDITOR.tools.indexOf(t, s), 1), s.isInited() && (o = s.editor.checkDirty(), s.setSelected(!1), !o && s.editor.resetDirty());
                for (d && r && (o = e.editor.checkDirty(), e.focused = r, e.fire("widgetFocused", {
                        widget: r
                    }), r.setFocused(!0), !o && e.editor.resetDirty()); s = i.pop();) t.push(s), s.setSelected(!0);
                e.editor.fire("unlockSnapshot")
            }
        }
    }
    var E = {
        37: 1,
        38: 1,
        39: 1,
        40: 1,
        8: 1,
        46: 1
    };

    function w(e, t, i) {
        var n, a = 0,
            r = b(t),
            s = e.data.classes || {};
        if (r) {
            for (s = CKEDITOR.tools.clone(s); n = r.pop();) i ? s[n] || (a = s[n] = 1) : s[n] && (delete s[n], a = 1);
            a && e.setData("classes", s)
        }
    }

    function v(e) {
        e.cancel()
    }

    function k(e, t) {
        var i = e.editor,
            n = i.document,
            a = CKEDITOR.env.edge && CKEDITOR.env.version >= 16;
        if (!n.getById("cke_copybin")) {
            var r = !i.blockless && !CKEDITOR.env.ie || a ? "div" : "span",
                s = n.createElement(r),
                o = n.createElement(r),
                d = CKEDITOR.env.ie && CKEDITOR.env.version < 9;
            o.setAttributes({
                id: "cke_copybin",
                "data-cke-temp": "1"
            }), s.setStyles({
                position: "absolute",
                width: "1px",
                height: "1px",
                overflow: "hidden"
            }), s.setStyle("ltr" == i.config.contentsLangDirection ? "left" : "right", "-5000px");
            var l = i.createRange();
            l.setStartBefore(e.wrapper), l.setEndAfter(e.wrapper), s.setHtml('<span data-cke-copybin-start="1">​</span>' + i.editable().getHtmlFromRange(l).getHtml() + '<span data-cke-copybin-end="1">​</span>'), i.fire("saveSnapshot"), i.fire("lockSnapshot"), o.append(s), i.editable().append(o);
            var c = i.on("selectionChange", v, null, null, 0),
                u = e.repository.on("checkSelection", v, null, null, 0);
            if (d) var f = n.getDocumentElement().$,
                p = f.scrollTop;
            (l = i.createRange()).selectNodeContents(s), l.select(), d && (f.scrollTop = p), setTimeout(function() {
                t || e.focus(), o.remove(), c.removeListener(), u.removeListener(), i.fire("unlockSnapshot"), t && !i.readOnly && (e.repository.del(e), i.fire("saveSnapshot"))
            }, 100)
        }
    }

    function b(e) {
        var t = e.getDefinition().attributes,
            i = t && t.class;
        return i ? i.split(/\s+/) : null
    }

    function C() {
        var e = CKEDITOR.document.getActive(),
            t = this.editor,
            i = t.editable();
        (i.isInline() ? i : t.document.getWindow().getFrame()).equals(e) && t.focusManager.focus(i)
    }

    function D() {
        CKEDITOR.env.gecko && this.editor.unlockSelection(), CKEDITOR.env.webkit || (this.editor.forceNextSelectionCheck(), this.editor.selectionChange(1))
    }

    function _(e) {
        if (CKEDITOR.tools.getMouseButton(e) === CKEDITOR.MOUSE_BUTTON_LEFT) {
            var t, i, n = this.repository.finder,
                a = this.repository.locator,
                r = this.repository.liner,
                s = this.editor,
                o = s.editable(),
                d = [],
                l = [];
            this.repository._.draggedWidget = this;
            var c = n.greedySearch(),
                u = CKEDITOR.tools.eventsBuffer(50, function() {
                    t = a.locate(c), (l = a.sort(i, 1)).length && (r.prepare(c, t), r.placeLine(l[0]), r.cleanup())
                });
            o.addClass("cke_widget_dragging"), d.push(o.on("mousemove", function(e) {
                i = e.data.$.clientY, u.input()
            })), s.fire("dragstart", {
                target: e.sender
            }), d.push(s.document.once("mouseup", f, this)), o.isInline() || d.push(CKEDITOR.document.once("mouseup", f, this))
        }

        function f() {
            var t;
            for (u.reset(); t = d.pop();) t.removeListener();
            (function(e, t) {
                var i = this.repository.finder,
                    n = this.repository.liner,
                    a = this.editor,
                    r = this.editor.editable();
                if (!CKEDITOR.tools.isEmpty(n.visible)) {
                    var s = i.getRange(e[0]);
                    this.focus(), a.fire("drop", {
                        dropRange: s,
                        target: s.startContainer
                    })
                }
                r.removeClass("cke_widget_dragging"), n.hideVisible(), a.fire("dragend", {
                    target: t
                })
            }).call(this, l, e.sender)
        }
    }

    function y(e) {
        e.element.data("cke-widget-data", encodeURIComponent(JSON.stringify(e.data)))
    }
    CKEDITOR.plugins.widget = i, i.repository = t, i.nestedEditable = n
}();