CKEDITOR.plugins.setLang("widget", "en", {
    move: "Click and drag to move",
    label: "%1 widget"
});