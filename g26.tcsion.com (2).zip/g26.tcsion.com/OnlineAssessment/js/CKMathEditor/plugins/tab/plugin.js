! function() {
    var e = {
            editorFocus: !1,
            modes: {
                wysiwyg: 1,
                source: 1
            }
        },
        t = {
            exec: function(e) {
                e.container.focusNext(!0, e.tabIndex)
            }
        },
        o = {
            exec: function(e) {
                e.container.focusPrevious(!0, e.tabIndex)
            }
        };

    function n(e) {
        return {
            editorFocus: !1,
            canUndo: !1,
            modes: {
                wysiwyg: 1
            },
            exec: function(t) {
                if (t.editable().hasFocus) {
                    var o, n = t.getSelection(),
                        i = new CKEDITOR.dom.elementPath(n.getCommonAncestor(), n.root);
                    if (o = i.contains({
                            td: 1,
                            th: 1
                        }, 1)) {
                        var a = t.createRange(),
                            c = CKEDITOR.tools.tryThese(function() {
                                var t = o.getParent().$.cells[o.$.cellIndex + (e ? -1 : 1)];
                                return t.parentNode.parentNode, t
                            }, function() {
                                var t = o.getParent(),
                                    n = t.getAscendant("table").$.rows[t.$.rowIndex + (e ? -1 : 1)];
                                return n.cells[e ? n.cells.length - 1 : 0]
                            });
                        if (c || e) {
                            if (!c) return !0;
                            c = new CKEDITOR.dom.element(c), a.moveToElementEditStart(c), a.checkStartOfBlock() && a.checkEndOfBlock() || a.selectNodeContents(c)
                        } else {
                            for (var s = o.getAscendant("table").$, r = o.getParent().$.cells, d = new CKEDITOR.dom.element(s.insertRow(-1), t.document), l = 0, u = r.length; l < u; l++) {
                                d.append(new CKEDITOR.dom.element(r[l], t.document).clone(!1, !1)).appendBogus()
                            }
                            a.moveToElementEditStart(d)
                        }
                        return a.select(!0), !0
                    }
                }
                return !1
            }
        }
    }
    CKEDITOR.plugins.add("tab", {
        init: function(i) {
            for (var a = !1 !== i.config.enableTabKeyTools, c = i.config.tabSpaces || 0, s = ""; c--;) s += " ";
            s && i.on("key", function(e) {
                9 == e.data.keyCode && (i.insertText(s), e.cancel())
            }), a && i.on("key", function(e) {
                (9 == e.data.keyCode && i.execCommand("selectNextCell") || e.data.keyCode == CKEDITOR.SHIFT + 9 && i.execCommand("selectPreviousCell")) && e.cancel()
            }), i.addCommand("blur", CKEDITOR.tools.extend(t, e)), i.addCommand("blurBack", CKEDITOR.tools.extend(o, e)), i.addCommand("selectNextCell", n()), i.addCommand("selectPreviousCell", n(!0))
        }
    })
}(), CKEDITOR.dom.element.prototype.focusNext = function(e, t) {
    var o, n, i, a, c, s, r = void 0 === t ? this.getTabIndex() : t;
    if (r <= 0)
        for (c = this.getNextSourceNode(e, CKEDITOR.NODE_ELEMENT); c;) {
            if (c.isVisible() && 0 === c.getTabIndex()) {
                i = c;
                break
            }
            c = c.getNextSourceNode(!1, CKEDITOR.NODE_ELEMENT)
        } else
            for (c = this.getDocument().getBody().getFirst(); c = c.getNextSourceNode(!1, CKEDITOR.NODE_ELEMENT);) {
                if (!o)
                    if (!n && c.equals(this)) {
                        if (n = !0, e) {
                            if (!(c = c.getNextSourceNode(!0, CKEDITOR.NODE_ELEMENT))) break;
                            o = 1
                        }
                    } else n && !this.contains(c) && (o = 1);
                if (c.isVisible() && !((s = c.getTabIndex()) < 0)) {
                    if (o && s == r) {
                        i = c;
                        break
                    }
                    s > r && (!i || !a || s < a) ? (i = c, a = s) : i || 0 !== s || (i = c, a = s)
                }
            }
    i && i.focus()
}, CKEDITOR.dom.element.prototype.focusPrevious = function(e, t) {
    for (var o, n, i, a, c = void 0 === t ? this.getTabIndex() : t, s = 0, r = this.getDocument().getBody().getLast(); r = r.getPreviousSourceNode(!1, CKEDITOR.NODE_ELEMENT);) {
        if (!o)
            if (!n && r.equals(this)) {
                if (n = !0, e) {
                    if (!(r = r.getPreviousSourceNode(!0, CKEDITOR.NODE_ELEMENT))) break;
                    o = 1
                }
            } else n && !this.contains(r) && (o = 1);
        if (r.isVisible() && !((a = r.getTabIndex()) < 0))
            if (c <= 0) {
                if (o && 0 === a) {
                    i = r;
                    break
                }
                a > s && (i = r, s = a)
            } else {
                if (o && a == c) {
                    i = r;
                    break
                }
                a < c && (!i || a > s) && (i = r, s = a)
            }
    }
    i && i.focus()
};